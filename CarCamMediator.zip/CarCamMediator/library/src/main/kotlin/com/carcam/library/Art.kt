package com.carcam.library

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** تحميل غلاف الألبوم من ملف الأغنية مع ذاكرة مؤقتة */
object Art {
    private val cache = LruCache<String, Bitmap>(120)
    private val misses = HashSet<String>()

    suspend fun load(ctx: Context, uri: Uri, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "$uri#$px"
        cache.get(key)?.let { return@withContext it }
        if (synchronized(misses) { key in misses }) return@withContext null
        val b = runCatching { ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()
        if (b != null) cache.put(key, b) else synchronized(misses) { misses.add(key) }
        b
    }
}

@Composable
fun ArtImage(uri: Uri?, modifier: Modifier, px: Int = 256) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = if (uri == null) null else Art.load(ctx, uri, px) }
    Box(modifier.background(Color(0xFF2A2340)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("♪", color = Color(0x99FFFFFF))
    }
}
