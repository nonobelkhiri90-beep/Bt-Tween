package com.carcam.library

import com.carcam.ui.OptionChip

import com.carcam.ui.CarCamTheme
import com.carcam.ui.Ltr

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import kotlin.math.ln
import kotlin.math.roundToInt

/** شاشة التشغيل الكاملة: تحكم + سرعة + نغمة + A-B + مؤقت نوم + معادل وأدوات صوت */
class NowPlayingActivity : ComponentActivity() {
    private lateinit var player: PlayerConnection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioFx.init(this)
        player = PlayerConnection(this).also { it.connect() }
        setContent { CarCamTheme { Screen() } }
    }

    override fun onDestroy() { player.release(); super.onDestroy() }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    @Composable
    private fun Screen() {
        val now by player.now.collectAsStateWithLifecycle()
        val ab by player.ab.collectAsStateWithLifecycle()
        val sleepEnd by player.sleepEnd.collectAsStateWithLifecycle()
        var pos by remember { mutableLongStateOf(0L) }
        var dur by remember { mutableLongStateOf(0L) }
        var dragging by remember { mutableStateOf(false) }
        var dragValue by remember { mutableFloatStateOf(0f) }
        var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }

        LaunchedEffect(Unit) {
            while (true) {
                if (!dragging) pos = player.positionMs()
                dur = player.durationMs()
                clock = System.currentTimeMillis()
                delay(300)
            }
        }

        val artUri = now.uri?.let { Uri.parse(it) }
        Box(Modifier.fillMaxSize()) {
            ArtImage(artUri, Modifier.fillMaxSize().blur(48.dp), px = 512)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xCC0F0B1E), Color(0xF20F0B1E)))))
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                ArtImage(artUri, Modifier.size(280.dp).clip(RoundedCornerShape(24.dp)), px = 800)
            }
            Text(now.title ?: "لا يوجد تشغيل", style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(now.artist ?: "", style = MaterialTheme.typography.bodyMedium)

            Slider(
                value = if (dragging) dragValue else if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = { player.seekTo((dragValue * dur).toLong()); pos = (dragValue * dur).toLong(); dragging = false }
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(if (dragging) (dragValue * dur).toLong() else pos)); Text(fmt(dur))
            }

            Ltr { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                TextButton({ player.toggleShuffle() }) { Text(if (now.shuffle) "🔀 ✓" else "🔀") }
                TextButton({ player.previous() }) { Text("⏮") }
                Button({ player.toggle() }) { Text(if (now.playing) "⏸" else "▶") }
                TextButton({ player.next() }) { Text("⏭") }
                TextButton({ player.cycleRepeat() }) {
                    Text(when (now.repeat) { Player.REPEAT_MODE_ALL -> "🔁 ✓"; Player.REPEAT_MODE_ONE -> "🔂"; else -> "🔁" })
                }
            } }

            Section("السرعة")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                    OptionChip("${s}x", now.speed == s) { player.setSpeed(s) }
                }
            }

            Section("النغمة (Pitch)")
            val semis = (12 * ln(now.pitch.toDouble()) / ln(2.0)).roundToInt()
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ player.setPitch(Math.pow(2.0, (semis - 1) / 12.0).toFloat()) }) { Text("−") }
                Text("${if (semis > 0) "+" else ""}$semis نصف نغمة")
                OutlinedButton({ player.setPitch(Math.pow(2.0, (semis + 1) / 12.0).toFloat()) }) { Text("+") }
                TextButton({ player.setPitch(1f) }) { Text("إعادة") }
            }

            Section("تكرار مقطع A-B")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton({ player.setA() }) { Text(if (ab.a >= 0) "A ${fmt(ab.a)}" else "تحديد A") }
                OutlinedButton({ player.setB() }, enabled = ab.a >= 0) { Text(if (ab.b >= 0) "B ${fmt(ab.b)}" else "تحديد B") }
                TextButton({ player.clearAb() }) { Text("إلغاء") }
            }

            Section(if (sleepEnd > 0) "مؤقت النوم (باقي ${((sleepEnd - clock) / 60000 + 1).coerceAtLeast(0)} د)" else "مؤقت النوم")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OptionChip("إيقاف", sleepEnd == 0L) { player.sleepIn(0) }
                listOf(15, 30, 60, 90).forEach { m -> OptionChip("$m د", false) { player.sleepIn(m) } }
            }

            Section("المعادل وأدوات الصوت")
            AudioTools()
            Spacer(Modifier.height(24.dp))
        }
        }
    }

    @Composable
    private fun Section(t: String) {
        HorizontalDivider()
        Text(t, style = MaterialTheme.typography.titleMedium)
    }

    @Composable
    private fun AudioTools() {
        val levels = remember { mutableStateMapOf<Int, Float>() }
        var bass by remember { mutableFloatStateOf(AudioFx.bass.toFloat()) }
        var virt by remember { mutableFloatStateOf(AudioFx.virt.toFloat()) }
        var boost by remember { mutableFloatStateOf(AudioFx.boostDb.toFloat()) }

        if (!AudioFx.available()) {
            Text("المعادل يعمل بعد بدء تشغيل أغنية. شغّل أغنية ثم ارجع لهذه الشاشة.", style = MaterialTheme.typography.bodySmall)
        }
        for (b in 0 until AudioFx.bandCount()) {
            Text("${AudioFx.bandFreqHz(b)} Hz", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = levels[b] ?: AudioFx.getBand(b).toFloat(),
                onValueChange = { levels[b] = it; AudioFx.setBand(b, it.toInt()) },
                valueRange = AudioFx.bandMin().toFloat()..AudioFx.bandMax().toFloat()
            )
        }
        Text("تعزيز الباص: ${bass.toInt() / 10}%", style = MaterialTheme.typography.bodySmall)
        Slider(bass, { bass = it; AudioFx.bass = it.toInt() }, valueRange = 0f..1000f)
        Text("الصوت المحيطي: ${virt.toInt() / 10}%", style = MaterialTheme.typography.bodySmall)
        Slider(virt, { virt = it; AudioFx.virt = it.toInt() }, valueRange = 0f..1000f)
        Text("رفع الصوت فوق 100%: +${boost.toInt()} dB", style = MaterialTheme.typography.bodySmall)
        Slider(boost, { boost = it; AudioFx.boostDb = it.toInt() }, valueRange = 0f..15f)
        OutlinedButton({
            AudioFx.reset(); levels.clear(); bass = 0f; virt = 0f; boost = 0f
        }) { Text("إعادة ضبط") }
    }
}
