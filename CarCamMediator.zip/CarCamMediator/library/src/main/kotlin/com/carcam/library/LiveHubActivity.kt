package com.carcam.library

import android.media.AudioManager
import com.carcam.audio.CalibStore
import com.carcam.audio.RoomCalibrator
import com.carcam.ui.DevCredit

import android.Manifest
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.carcam.audio.MicProbe
import com.carcam.ui.ActionCard
import com.carcam.ui.CarCamTheme
import com.carcam.ui.CcColors
import com.carcam.ui.Ltr
import com.carcam.ui.StatusRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * مركز البث المباشر: يجهّز الموسيقى لتعمل في الخلفية، ويفتح تيك توك/يوتيوب/فيسبوك/إنستغرام،
 * ويعرض لوحة تحكم عائمة، ويختبر وصول الموسيقى إلى ميكروفون البث.
 * ملاحظة: أندرويد لا يسمح بحقن الصوت داخل ميكروفون تطبيق آخر، فالموسيقى تصل عبر مكبر الهاتف.
 */
class LiveHubActivity : ComponentActivity() {
    private lateinit var player: PlayerConnection
    private lateinit var store: LibraryStore

    private class Platform(val name: String, val emoji: String, val pkgs: List<String>, val tip: String)

    private val platforms = listOf(
        Platform("TikTok", "🎵", listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
            "اضغط (+) ثم اختر «مباشر». يتطلب حساباً مؤهلاً للبث."),
        Platform("YouTube", "▶️", listOf("com.google.android.youtube"),
            "اضغط (+) ثم «بث مباشر». يتطلب تفعيل البث على قناتك."),
        Platform("Facebook", "👍", listOf("com.facebook.katana"),
            "من «ما الذي يدور في ذهنك؟» اختر «فيديو مباشر»."),
        Platform("Instagram", "📸", listOf("com.instagram.android"),
            "اضغط (+) ثم اختر «مباشر»."),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioFx.init(this)
        store = LibraryStore(this)
        player = PlayerConnection(this).also { it.connect() }
        setContent { CarCamTheme { Hub() } }
    }

    override fun onDestroy() { player.release(); super.onDestroy() }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun installedPkg(p: Platform): String? = p.pkgs.firstOrNull { pkg ->
        runCatching { packageManager.getPackageInfo(pkg, 0); true }.getOrDefault(false)
    }

    private fun verdict(mic: Float?, vc: Float?): String {
        if (mic == null) return "تعذّر فتح الميكروفون"
        val lvl = when {
            mic > -20f -> "قوية جداً (قد تتشوّه)"
            mic > -35f -> "جيدة ✅"
            mic > -50f -> "ضعيفة، ارفع صوت الموسيقى"
            else -> "لا تُسمع تقريباً ⚠️"
        }
        var s = "مستوى الموسيقى عند الميكروفون: ${mic.toInt()} dB ← $lvl"
        if (vc != null) {
            val d = mic - vc
            s += "\nبعد معالجة المكالمات (كما تفعل تطبيقات البث): ${vc.toInt()} dB"
            s += if (d > 10f) "\n⚠️ إلغاء الصدى يخفض الموسيقى بنحو ${d.toInt()} dB وقد تضعف في البث. ارفع الصوت أو جرّب بث الشاشة."
            else "\n✅ إلغاء الصدى لا يخفضها كثيراً."
        }
        return s
    }

    private fun startLive(p: Platform, now: NowPlaying) {
        val pkg = installedPkg(p)
        if (pkg == null) { toast("تطبيق ${p.name} غير مثبّت"); return }
        store.mixMode = true
        PlaybackService.applyMixMode(true)
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("امنح إذن «العرض فوق التطبيقات» ثم ارجع واضغط ابدأ")
            return
        }
        if (now.title == null) {
            toast("اختر أغنية وشغّلها أولاً")
            startActivity(Intent(this, LibraryActivity::class.java))
            return
        }
        if (!now.playing) player.toggle()
        startService(Intent(this, OverlayService::class.java))
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    @Composable
    private fun Hub() {
        val scope = rememberCoroutineScope()
        val now by player.now.collectAsStateWithLifecycle()
        var mix by remember { mutableStateOf(store.mixMode) }
        var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(this)) }
        var testing by remember { mutableStateOf(false) }
        var result by remember { mutableStateOf<String?>(null) }
        var selected by remember { mutableStateOf<Platform?>(null) }
        var pending by remember { mutableIntStateOf(0) }
        var calibrating by remember { mutableStateOf(false) }
        var calibText by remember { mutableStateOf<String?>(null) }
        var autoVolText by remember { mutableStateOf<String?>(null) }

        LaunchedEffect(Unit) {
            while (true) { overlayOk = Settings.canDrawOverlays(this@LiveHubActivity); delay(1000) }
        }

        fun runTest() {
            if (!now.playing) { toast("شغّل الموسيقى أولاً ثم أعد الاختبار"); return }
            scope.launch {
                testing = true; result = null
                val a = withContext(Dispatchers.IO) { MicProbe.measureDb(MediaRecorder.AudioSource.MIC) }
                val b = withContext(Dispatchers.IO) { MicProbe.measureDb(MediaRecorder.AudioSource.VOICE_COMMUNICATION) }
                result = verdict(a, b)
                testing = false
            }
        }
        fun runCalibration() {
            if (calibrating) return
            scope.launch {
                calibrating = true
                calibText = "يشغّل ضجيجاً وردياً ويسجّله لـ 8 ثوانٍ… ابقَ هادئاً"
                if (now.playing) player.toggle()
                val r = withContext(Dispatchers.IO) { RoomCalibrator.run(6) }
                if (r == null) {
                    calibText = "تعذّر القياس (تحقق من إذن الميكروفون)"
                } else {
                    CalibStore.set(this@LiveHubActivity, r.correctionDb)
                    AudioFx.applyCorrections(r.correctionDb)
                    calibText = buildString {
                        append("تمت المعايرة ✅ (إشارة/محيط ${r.snrDb.toInt()} dB)\n")
                        for ((i, fc) in RoomCalibrator.CENTERS.withIndex()) {
                            append("${fc}Hz: استجابة %+.1f ← تصحيح %+.1f dB\n".format(r.relativeDb[i], r.correctionDb[i]))
                        }
                        if (r.snrDb < 12f) append("⚠️ ضجيج المحيط عالٍ، النتيجة أقل دقة. أعد المعايرة في مكان أهدأ.")
                    }
                }
                calibrating = false
            }
        }

        fun runAutoVol() {
            if (!now.playing) { toast("شغّل الموسيقى أولاً"); return }
            scope.launch {
                autoVolText = "جارٍ الضبط…"
                val am = getSystemService(AudioManager::class.java)
                var info = ""
                for (i in 0 until 6) {
                    val db = withContext(Dispatchers.IO) { MicProbe.measureDb(MediaRecorder.AudioSource.MIC, 1500) } ?: break
                    info = "المستوى عند الميكروفون: ${db.toInt()} dB"
                    if (db < -34f) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                    else if (db > -22f) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                    else { info += " ✅ ضمن النطاق المثالي"; break }
                    delay(400)
                }
                autoVolText = info.ifEmpty { "تعذّر القياس" }
            }
        }

        val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (!ok) toast("هذه الميزة تحتاج إذن الميكروفون")
            else when (pending) { 1 -> runTest(); 2 -> runCalibration(); 3 -> runAutoVol(); else -> {} }
        }

        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📡 بث مباشر بالموسيقى", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                TextButton({ finish() }) { Text("رجوع") }
            }

            // الموسيقى
            Card(colors = CardDefaults.cardColors(containerColor = CcColors.Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الموسيقى", style = MaterialTheme.typography.titleMedium, color = CcColors.Primary)
                    Text(now.title ?: "لا توجد أغنية قيد التشغيل", style = MaterialTheme.typography.bodyLarge)
                    if (now.artist != null) Text(now.artist ?: "", style = MaterialTheme.typography.bodySmall, color = CcColors.Muted)
                    Ltr {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ player.previous() }) { Text("⏮") }
                            Button({ player.toggle() }) { Text(if (now.playing) "⏸" else "▶") }
                            TextButton({ player.next() }) { Text("⏭") }
                        }
                    }
                    OutlinedButton({ startActivity(Intent(this@LiveHubActivity, LibraryActivity::class.java)) }) { Text("اختيار من المكتبة") }
                }
            }

            // الجاهزية
            Card(colors = CardDefaults.cardColors(containerColor = CcColors.Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الجاهزية", style = MaterialTheme.typography.titleMedium, color = CcColors.Primary)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("وضع البث")
                            Text("تستمر الموسيقى عندما يفتح تطبيق البث", style = MaterialTheme.typography.bodySmall, color = CcColors.Muted)
                        }
                        Switch(mix, { mix = it; store.mixMode = it; PlaybackService.applyMixMode(it) })
                    }
                    StatusRow("لوحة التحكم العائمة", if (overlayOk) "مسموحة" else "تحتاج إذناً", overlayOk)
                    if (!overlayOk) {
                        TextButton({
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        }) { Text("منح إذن العرض فوق التطبيقات") }
                    }
                    StatusRow("الموسيقى", if (now.playing) "تعمل" else "متوقفة", now.playing)
                }
            }

            // اختبار الصوت
            Card(colors = CardDefaults.cardColors(containerColor = CcColors.Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("اختبار وصول الموسيقى للميكروفون", style = MaterialTheme.typography.titleMedium, color = CcColors.Primary)
                    Text(
                        "شغّل الموسيقى عبر مكبر الهاتف واضغط اختبار. يقيس المستوى كما تسمعه تطبيقات البث (قبل بدء البث).",
                        style = MaterialTheme.typography.bodySmall, color = CcColors.Muted
                    )
                    Button({ pending = 1; micPerm.launch(Manifest.permission.RECORD_AUDIO) }, enabled = !testing) {
                        Text(if (testing) "جاري القياس…" else "ابدأ الاختبار")
                    }
                    result?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                }
            }

            // ضبط تلقائي للمستوى + معايرة المقصورة
            Card(colors = CardDefaults.cardColors(containerColor = CcColors.Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🎧 الضبط التلقائي بالميكروفون", style = MaterialTheme.typography.titleMedium, color = CcColors.Primary)
                    Text(
                        "التطبيق يسمع الصوت عبر الميكروفون ويضبط المستوى والمعادل تلقائياً. اجعل الهاتف في مكانه المعتاد (على حامل السيارة).",
                        style = MaterialTheme.typography.bodySmall, color = CcColors.Muted
                    )
                    Button({ pending = 3; micPerm.launch(Manifest.permission.RECORD_AUDIO) }) { Text("ضبط مستوى الصوت تلقائياً") }
                    autoVolText?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                    Button({ pending = 2; micPerm.launch(Manifest.permission.RECORD_AUDIO) }, enabled = !calibrating) {
                        Text(if (calibrating) "جاري المعايرة…" else "معايرة المعادل (باص/حدة) لمقصورتك")
                    }
                    calibText?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    OutlinedButton({
                        CalibStore.set(this@LiveHubActivity, null); AudioFx.reset(); calibText = "أُعيد الضبط إلى الوضع المسطح"
                    }) { Text("إعادة ضبط المعايرة") }
                }
            }

            // المنصات
            Text("ابدأ البث على", style = MaterialTheme.typography.titleMedium)
            for (row in platforms.chunked(2)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (p in row) {
                        ActionCard(p.emoji, p.name, if (installedPkg(p) != null) "ابدأ البث" else "غير مثبّت", Modifier.weight(1f)) {
                            selected = p
                            startLive(p, now)
                        }
                    }
                }
            }
            selected?.let { Text("${it.name}: ${it.tip}", style = MaterialTheme.typography.bodySmall, color = CcColors.Muted) }

            // نصائح
            Card(colors = CardDefaults.cardColors(containerColor = CcColors.SurfaceHi), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("لتصل الموسيقى إلى المشاهدين", style = MaterialTheme.typography.titleSmall)
                    Text("• أندرويد لا يسمح بإدخال صوت داخل تطبيق آخر، لذا تصل الموسيقى عبر مكبر الهاتف إلى ميكروفون البث.", style = MaterialTheme.typography.bodySmall)
                    Text("• استعمل مكبر الهاتف أو سماعة خارجية، لا سماعات الأذن.", style = MaterialTheme.typography.bodySmall)
                    Text("• اجعل صوت الموسيقى بين 60% و80%، وتحكّم به من اللوحة العائمة دون مغادرة البث.", style = MaterialTheme.typography.bodySmall)
                    Text("• إن ضعفت الموسيقى في الاختبار: عطّل «تقليل الضوضاء» داخل تطبيق البث إن وُجد، أو استعمل بث الشاشة (يلتقط الصوت الداخلي).", style = MaterialTheme.typography.bodySmall)
                }
            }
            DevCredit()
        }
    }
}
