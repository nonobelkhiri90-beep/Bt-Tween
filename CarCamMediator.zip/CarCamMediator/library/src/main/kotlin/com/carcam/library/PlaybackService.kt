package com.carcam.library

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** المشغّل: إشعار التحكم وشاشة القفل وأزرار السيارة تلقائياً */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val mix = getSharedPreferences("library_store", MODE_PRIVATE).getBoolean("mix_mode", false)
        val p = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs(), /* handleAudioFocus = */ !mix)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = p
        session = MediaSession.Builder(this, p).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        player = null
        session?.run { this.player.release(); release() }
        session = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var player: ExoPlayer? = null

        private fun attrs() = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()

        /**
         * وضع البث: لا نطلب/نتنازل عن Audio Focus، فتستمر الموسيقى
         * حتى عندما يفتح تيك توك أو يوتيوب أو غيرهما ويطلب التركيز.
         * يُستدعى من الخيط الرئيسي.
         */
        fun applyMixMode(on: Boolean) { player?.setAudioAttributes(attrs(), !on) }
    }
}
