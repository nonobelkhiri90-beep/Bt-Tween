package com.carcam.library

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** المشغّل: إشعار التحكم وشاشة القفل وأزرار السيارة تلقائياً */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        AudioFx.init(this)
        val mix = getSharedPreferences("library_store", MODE_PRIVATE).getBoolean("mix_mode", false)
        val p = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs(), /* handleAudioFocus = */ !mix)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        p.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { AudioFx.attach(audioSessionId) }
        })
        AudioFx.attach(p.audioSessionId)
        player = p
        session = MediaSession.Builder(this, p).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        player = null
        AudioFx.release()
        session?.run { this.player.release(); release() }
        session = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var player: ExoPlayer? = null

        private fun attrs() = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()

        /** وضع البث: تستمر الموسيقى حتى عندما يطلب تطبيق آخر Audio Focus. من الخيط الرئيسي. */
        fun applyMixMode(on: Boolean) { player?.setAudioAttributes(attrs(), !on) }
    }
}
