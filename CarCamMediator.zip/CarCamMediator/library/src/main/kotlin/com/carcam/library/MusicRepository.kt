package com.carcam.library

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** يقرأ كل الأغاني الموجودة في الهاتف عبر MediaStore */
class MusicRepository(private val ctx: Context) {

    suspend fun loadAll(): List<Track> = withContext(Dispatchers.IO) {
        val out = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.RELATIVE_PATH,
        )
        ctx.contentResolver.query(
            collection, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iYear = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iPath = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out += Track(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    title = c.getString(iTitle) ?: "بدون عنوان",
                    artist = clean(c.getString(iArtist)),
                    album = clean(c.getString(iAlbum)),
                    durationMs = c.getLong(iDur),
                    year = c.getInt(iYear),
                    dateAdded = c.getLong(iAdded),
                    folder = (c.getString(iPath) ?: "غير معروف").trimEnd('/'),
                )
            }
        }
        out
    }

    private fun clean(s: String?) =
        if (s.isNullOrBlank() || s == "<unknown>") "غير معروف" else s
}

/** التصنيفات التلقائية */
object Classifier {
    fun byArtist(t: List<Track>) = t.groupBy { it.artist }.toSortedMap()
    fun byAlbum(t: List<Track>) = t.groupBy { it.album }.toSortedMap()
    fun byFolder(t: List<Track>) = t.groupBy { it.folder }.toSortedMap()
    fun recent(t: List<Track>, n: Int = 50) = t.sortedByDescending { it.dateAdded }.take(n)
}
