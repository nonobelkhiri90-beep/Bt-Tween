package com.carcam.library

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

val StellioDark = darkColorScheme(
    primary = Color(0xFFB388FF),
    secondary = Color(0xFF4FC3F7),
    background = Color(0xFF0F0B1E),
    surface = Color(0xFF17122B),
    surfaceVariant = Color(0xFF241C3F),
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Color(0xFFCFC7E8),
)
