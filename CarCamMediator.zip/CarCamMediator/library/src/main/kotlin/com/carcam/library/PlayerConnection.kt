package com.carcam.library

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NowPlaying(
    val title: String? = null, val artist: String? = null,
    val playing: Boolean = false, val uri: String? = null,
)

/** جسر بين الواجهة وخدمة التشغيل */
class PlayerConnection(private val ctx: Context) {
    private var controller: MediaController? = null
    private val _now = MutableStateFlow(NowPlaying())
    val now: StateFlow<NowPlaying> = _now.asStateFlow()

    fun connect() {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = refresh(player)
            })
            refresh(c)
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun refresh(p: Player) {
        _now.value = NowPlaying(
            p.mediaMetadata.title?.toString(),
            p.mediaMetadata.artist?.toString(),
            p.isPlaying,
            p.currentMediaItem?.localConfiguration?.uri?.toString()
        )
    }

    fun play(tracks: List<Track>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0)
        c.prepare(); c.play()
    }

    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun pause() { controller?.pause() }
    fun positionMs(): Long = controller?.currentPosition ?: 0L
    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun release() { controller?.release(); controller = null }
}
