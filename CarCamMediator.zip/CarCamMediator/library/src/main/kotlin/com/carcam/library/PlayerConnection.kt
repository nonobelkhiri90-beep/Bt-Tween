package com.carcam.library

import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NowPlaying(
    val title: String? = null,
    val artist: String? = null,
    val playing: Boolean = false,
    val uri: String? = null,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val pitch: Float = 1f,
)

/** مقطع تكرار A-B بالميلي ثانية (-1 = غير محدد) */
data class AbRange(val a: Long = -1, val b: Long = -1)

/** جسر بين الواجهة وخدمة التشغيل + أدوات: سرعة، نغمة، A-B، مؤقت نوم */
class PlayerConnection(private val ctx: Context) {
    private var controller: MediaController? = null
    private var pending: Pair<List<Track>, Int>? = null
    private val handler = Handler(Looper.getMainLooper())

    private val _now = MutableStateFlow(NowPlaying())
    val now: StateFlow<NowPlaying> = _now.asStateFlow()
    private val _ab = MutableStateFlow(AbRange())
    val ab: StateFlow<AbRange> = _ab.asStateFlow()
    /** وقت انتهاء مؤقت النوم (currentTimeMillis)، 0 = متوقف */
    private val _sleepEnd = MutableStateFlow(0L)
    val sleepEnd: StateFlow<Long> = _sleepEnd.asStateFlow()

    private var sleepTask: Runnable? = null
    private val abTick = object : Runnable {
        override fun run() {
            val c = controller
            val r = _ab.value
            if (c != null && r.a >= 0 && r.b > r.a && c.currentPosition >= r.b) c.seekTo(r.a)
            handler.postDelayed(this, 200)
        }
    }

    fun connect() {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            pending?.let { play(it.first, it.second); pending = null }
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = refresh(player)
            })
            refresh(c)
            handler.post(abTick)
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun refresh(p: Player) {
        _now.value = NowPlaying(
            title = p.mediaMetadata.title?.toString(),
            artist = p.mediaMetadata.artist?.toString(),
            playing = p.isPlaying,
            uri = p.currentMediaItem?.localConfiguration?.uri?.toString(),
            shuffle = p.shuffleModeEnabled,
            repeat = p.repeatMode,
            speed = p.playbackParameters.speed,
            pitch = p.playbackParameters.pitch,
        )
    }

    fun play(tracks: List<Track>, index: Int) {
        val c = controller ?: run { pending = tracks to index; return }
        c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0)
        c.prepare(); c.play()
    }

    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun pause() { controller?.pause() }
    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }

    fun positionMs(): Long = controller?.currentPosition ?: 0L
    fun durationMs(): Long {
        val d = controller?.duration ?: return 0L
        return if (d == C.TIME_UNSET || d < 0) 0L else d
    }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun setSpeed(v: Float) {
        controller?.let { it.playbackParameters = PlaybackParameters(v, it.playbackParameters.pitch) }
    }
    fun setPitch(v: Float) {
        controller?.let { it.playbackParameters = PlaybackParameters(it.playbackParameters.speed, v) }
    }

    fun setA() { _ab.value = AbRange(positionMs(), -1) }
    fun setB() {
        val a = _ab.value.a
        val pos = positionMs()
        if (a >= 0 && pos > a) _ab.value = AbRange(a, pos)
    }
    fun clearAb() { _ab.value = AbRange() }

    fun sleepIn(minutes: Int) {
        sleepTask?.let { handler.removeCallbacks(it) }
        sleepTask = null
        if (minutes <= 0) { _sleepEnd.value = 0L; return }
        val task = Runnable { controller?.pause(); _sleepEnd.value = 0L; sleepTask = null }
        sleepTask = task
        _sleepEnd.value = System.currentTimeMillis() + minutes * 60_000L
        handler.postDelayed(task, minutes * 60_000L)
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        controller?.release(); controller = null
    }
}
