package com.carcam.library

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** لوحة تحكم عائمة فوق أي تطبيق (تيك توك، يوتيوب...) للتحكم بالموسيقى دون مغادرة البث */
class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var bar: View? = null
    private var player: PlayerConnection? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val p = PlayerConnection(this).also { it.connect() }
        player = p
        val manager = getSystemService(WindowManager::class.java)
        wm = manager
        val audio = getSystemService(AudioManager::class.java)
        val d = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 28 * d }
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
        }
        fun btn(t: String, action: () -> Unit) = TextView(this).apply {
            text = t; textSize = 22f; setTextColor(Color.WHITE)
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            setOnClickListener { action() }
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (16 * d).toInt(); y = (240 * d).toInt() }

        val handle = btn("⠿") {}
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    manager.updateViewLayout(root, lp)
                }
            }
            true
        }

        root.addView(handle)
        root.addView(btn("⏮") { p.previous() })
        root.addView(btn("⏯") { p.toggle() })
        root.addView(btn("⏭") { p.next() })
        root.addView(btn("🔉") { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0) })
        root.addView(btn("🔊") { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0) })
        root.addView(btn("✕") { stopSelf() })

        manager.addView(root, lp)
        bar = root
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_NOT_STICKY

    override fun onDestroy() {
        bar?.let { runCatching { wm?.removeView(it) } }
        bar = null
        player?.release()
        super.onDestroy()
    }
}
