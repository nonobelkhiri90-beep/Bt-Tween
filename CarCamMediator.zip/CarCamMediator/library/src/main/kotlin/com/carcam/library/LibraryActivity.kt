package com.carcam.library

import com.carcam.ui.CarCamTheme
import com.carcam.ui.Ltr

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.content.Intent
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private enum class LibTab(val label: String) {
    ALL("الكل"), ARTISTS("الفنانون"), ALBUMS("الألبومات"),
    FOLDERS("المجلدات"), RECENT("الأحدث"), FAVS("المفضلة")
}

class LibraryActivity : ComponentActivity() {
    private lateinit var player: PlayerConnection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = PlayerConnection(this).also { it.connect() }
        setContent { CarCamTheme { Root() } }
    }

    override fun onDestroy() { player.release(); super.onDestroy() }

    @Composable
    private fun Root() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        var granted by remember {
            mutableStateOf(ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED)
        }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
        LaunchedEffect(Unit) { if (!granted) launcher.launch(perm) }

        if (!granted) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("نحتاج إذن قراءة الموسيقى") }
            return
        }
        Library()
    }

    @Composable
    private fun Library() {
        val repo = remember { MusicRepository(this) }
        val store = remember { LibraryStore(this) }
        var tracks by remember { mutableStateOf(listOf<Track>()) }
        var favs by remember { mutableStateOf(store.favorites()) }
        var tab by remember { mutableStateOf(LibTab.ALL) }
        var query by remember { mutableStateOf("") }
        var drillTitle by remember { mutableStateOf<String?>(null) }
        var drillTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
        val now by player.now.collectAsStateWithLifecycle()

        LaunchedEffect(Unit) { tracks = repo.loadAll() }
        BackHandler(drillTitle != null) { drillTitle = null }

        fun search(l: List<Track>) = if (query.isBlank()) l else l.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }

        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            OutlinedTextField(
                query, { query = it }, singleLine = true,
                label = { Text("بحث (${tracks.size} أغنية)") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            )
            var mix by remember { mutableStateOf(store.mixMode) }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("وضع البث: تستمر الموسيقى مع تيك توك/يوتيوب", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                Switch(mix, { mix = it; store.mixMode = it; PlaybackService.applyMixMode(it) })
                TextButton({ showOverlay() }) { Text("🎛 لوحة") }
            }
            ScrollableTabRow(selectedTabIndex = tab.ordinal, edgePadding = 8.dp) {
                LibTab.entries.forEach { t ->
                    Tab(tab == t, { tab = t; drillTitle = null }, text = { Text(t.label) })
                }
            }

            val visible = remember(tracks, query, tab, favs) {
                val base = when (tab) {
                    LibTab.ALL -> tracks
                    LibTab.RECENT -> Classifier.recent(tracks)
                    LibTab.FAVS -> tracks.filter { it.id in favs }
                    else -> tracks
                }
                if (query.isBlank()) base else base.filter {
                    it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
                }
            }
            val groups: Map<String, List<Track>> = remember(tracks, query, tab) {
                val f = if (query.isBlank()) tracks else tracks.filter {
                    it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
                }
                when (tab) {
                    LibTab.ARTISTS -> Classifier.byArtist(f)
                    LibTab.ALBUMS -> Classifier.byAlbum(f)
                    LibTab.FOLDERS -> Classifier.byFolder(f)
                    else -> emptyMap()
                }
            }

            Box(Modifier.weight(1f)) {
                if (drillTitle != null) {
                    Column {
                        Text(drillTitle!!, Modifier.padding(12.dp), style = MaterialTheme.typography.titleMedium)
                        TrackList(search(drillTracks), favs, { favs = store.toggleFavorite(it) })
                    }
                } else when (tab) {
                    LibTab.ARTISTS, LibTab.ALBUMS, LibTab.FOLDERS ->
                        Groups(groups) { n, l -> drillTitle = n; drillTracks = l }
                    else -> TrackList(visible, favs, { favs = store.toggleFavorite(it) })
                }
            }

            if (now.title != null) MiniPlayer(now)
        }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, OverlayService::class.java))
    }

    private fun launchCamera(now: NowPlaying) {
        val uri = now.uri ?: return
        val pos = player.positionMs()
        player.pause()
        startActivity(
            Intent().setClassName(packageName, "com.carcam.camera.CameraActivity")
                .putExtra("music_uri", uri).putExtra("music_start_ms", pos)
        )
    }

    @Composable
    private fun TrackList(list: List<Track>, favs: Set<Long>, onFav: (Long) -> Unit) {
        LazyColumn {
            itemsIndexed(list, key = { _, t -> t.id }) { i, t ->
                Row(
                    Modifier.fillMaxWidth().clickable { player.play(list, i) }.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtImage(t.uri, Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${t.artist} • ${t.durationMs / 60000}:%02d".format(t.durationMs / 1000 % 60),
                            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    TextButton({ onFav(t.id) }) { Text(if (t.id in favs) "★" else "☆") }
                }
                HorizontalDivider()
            }
        }
    }

    @Composable
    private fun Groups(map: Map<String, List<Track>>, onClick: (String, List<Track>) -> Unit) {
        LazyColumn {
            items(map.entries.toList(), key = { it.key }) { (name, list) ->
                Text(
                    "$name  (${list.size})",
                    Modifier.fillMaxWidth().clickable { onClick(name, list) }.padding(14.dp),
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                HorizontalDivider()
            }
        }
    }

    @Composable
    private fun MiniPlayer(now: NowPlaying) {
        Surface(tonalElevation = 6.dp) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtImage(now.uri?.let { Uri.parse(it) }, Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f).clickable { startActivity(Intent(this@LibraryActivity, NowPlayingActivity::class.java)) }) {
                    Text(now.title ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(now.artist ?: "", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
                Ltr { Row {
                TextButton({ launchCamera(now) }) { Text("🎬") }
                TextButton({ player.previous() }) { Text("⏮") }
                TextButton({ player.toggle() }) { Text(if (now.playing) "⏸" else "▶") }
                TextButton({ player.next() }) { Text("⏭") }
                } }
            }
        }
    }
}
