package com.carcam.library

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.carcam.ui.CcColors

/**
 * اختيار موسيقى أثناء التسجيل: الأغنية الحالية في المشغّل (من موضعها)، أو أي أغنية من المكتبة، أو ملف/فيديو.
 * onPick(uri, startMs, title)
 */
@Composable
fun MusicPickerDialog(
    onPick: (Uri, Long, String) -> Unit,
    onPickFile: () -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    val player = remember { PlayerConnection(ctx).also { it.connect() } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    val now by player.now.collectAsStateWithLifecycle()

    var tracks by remember { mutableStateOf(listOf<Track>()) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(granted) { if (granted) tracks = MusicRepository(ctx).loadAll() }
    val shown = remember(tracks, query) {
        (if (query.isBlank()) tracks else tracks.filter {
            it.title.contains(query, true) || it.artist.contains(query, true)
        }).take(150)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onDismiss) { Text("إغلاق") } },
        title = { Text("🎵 إضافة موسيقى") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val cur = now.uri
                if (cur != null && now.title != null) {
                    Text(
                        "▶ الأغنية الحالية: ${now.title}",
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                            val pos = player.positionMs()
                            player.pause()
                            onPick(Uri.parse(cur), pos, now.title ?: "")
                        }.padding(12.dp),
                        color = CcColors.Primary
                    )
                }
                Text(
                    "📂 ملف صوت أو فيديو…",
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPickFile() }.padding(12.dp)
                )
                if (!granted) {
                    TextButton({ launcher.launch(perm) }) { Text("منح إذن قراءة الموسيقى") }
                } else {
                    OutlinedTextField(
                        query, { query = it }, singleLine = true, label = { Text("بحث (${tracks.size} أغنية)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(shown, key = { it.id }) { t ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onPick(t.uri, 0L, t.title) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ArtImage(t.uri, Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)))
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(t.artist, style = MaterialTheme.typography.bodySmall, color = CcColors.Muted, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}
