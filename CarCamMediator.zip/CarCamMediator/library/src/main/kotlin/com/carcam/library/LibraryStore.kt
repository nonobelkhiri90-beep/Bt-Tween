package com.carcam.library

import android.content.Context

/** المفضلة (والقوائم لاحقاً) محفوظة محلياً */
class LibraryStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("library_store", Context.MODE_PRIVATE)

    var mixMode: Boolean
        get() = sp.getBoolean("mix_mode", false)
        set(v) = sp.edit().putBoolean("mix_mode", v).apply()

    fun favorites(): Set<Long> =
        sp.getStringSet("favs", emptySet())!!.mapNotNull { it.toLongOrNull() }.toSet()

    fun toggleFavorite(id: Long): Set<Long> {
        val cur = favorites().toMutableSet()
        if (!cur.add(id)) cur.remove(id)
        sp.edit().putStringSet("favs", cur.map { it.toString() }.toSet()).apply()
        return cur
    }
}
