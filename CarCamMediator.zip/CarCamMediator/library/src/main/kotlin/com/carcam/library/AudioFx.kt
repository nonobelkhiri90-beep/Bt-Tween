package com.carcam.library

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer

/** معادل + باص + ساوند محيطي + رفع الصوت فوق 100%، مرتبطة بجلسة صوت المشغّل */
object AudioFx {
    private var sp: SharedPreferences? = null
    private var eq: Equalizer? = null
    private var bassFx: BassBoost? = null
    private var virtFx: Virtualizer? = null
    private var loudFx: LoudnessEnhancer? = null

    fun init(ctx: Context) {
        if (sp == null) sp = ctx.applicationContext.getSharedPreferences("audiofx", Context.MODE_PRIVATE)
    }

    fun attach(session: Int) {
        release()
        if (session <= 0) return
        eq = runCatching { Equalizer(0, session).also { it.enabled = true } }.getOrNull()
        bassFx = runCatching { BassBoost(0, session).also { it.enabled = true } }.getOrNull()
        virtFx = runCatching { Virtualizer(0, session).also { it.enabled = true } }.getOrNull()
        loudFx = runCatching { LoudnessEnhancer(session).also { it.enabled = true } }.getOrNull()
        for (b in 0 until bandCount()) runCatching { eq?.setBandLevel(b.toShort(), getBand(b).toShort()) }
        runCatching { bassFx?.setStrength(bass.toShort()) }
        runCatching { virtFx?.setStrength(virt.toShort()) }
        runCatching { loudFx?.setTargetGain(boostDb * 100) }
    }

    fun release() {
        runCatching { eq?.release() }; runCatching { bassFx?.release() }
        runCatching { virtFx?.release() }; runCatching { loudFx?.release() }
        eq = null; bassFx = null; virtFx = null; loudFx = null
    }

    fun available() = eq != null
    fun bandCount(): Int = eq?.numberOfBands?.toInt() ?: 0
    fun bandFreqHz(b: Int): Int = (eq?.getCenterFreq(b.toShort()) ?: 0) / 1000
    fun bandMin(): Int = eq?.bandLevelRange?.get(0)?.toInt() ?: -1500
    fun bandMax(): Int = eq?.bandLevelRange?.get(1)?.toInt() ?: 1500

    fun getBand(b: Int): Int = sp?.getInt("band_$b", 0) ?: 0
    fun setBand(b: Int, level: Int) {
        sp?.edit()?.putInt("band_$b", level)?.apply()
        runCatching { eq?.setBandLevel(b.toShort(), level.toShort()) }
    }

    /** 0..1000 */
    var bass: Int
        get() = sp?.getInt("bass", 0) ?: 0
        set(v) { sp?.edit()?.putInt("bass", v)?.apply(); runCatching { bassFx?.setStrength(v.toShort()) } }

    /** 0..1000 */
    var virt: Int
        get() = sp?.getInt("virt", 0) ?: 0
        set(v) { sp?.edit()?.putInt("virt", v)?.apply(); runCatching { virtFx?.setStrength(v.toShort()) } }

    /** رفع الصوت بالديسيبل 0..15 */
    var boostDb: Int
        get() = sp?.getInt("boost", 0) ?: 0
        set(v) { sp?.edit()?.putInt("boost", v)?.apply(); runCatching { loudFx?.setTargetGain(v * 100) } }

    /** يطبّق تصحيح المعايرة (8 نطاقات أوكتاف dB) على نطاقات معادل الجهاز بالاستكمال اللوغاريتمي */
    fun applyCorrections(g: FloatArray) {
        val c = com.carcam.audio.RoomCalibrator.CENTERS
        for (b in 0 until bandCount()) {
            val f = bandFreqHz(b).coerceAtLeast(20).toDouble()
            var db = g[g.size - 1].toDouble()
            if (f <= c[0]) db = g[0].toDouble()
            else for (i in 0 until c.size - 1) {
                if (f <= c[i + 1]) {
                    val t = (Math.log(f) - Math.log(c[i].toDouble())) / (Math.log(c[i + 1].toDouble()) - Math.log(c[i].toDouble()))
                    db = g[i] + (g[i + 1] - g[i]) * t
                    break
                }
            }
            setBand(b, (db * 100).toInt().coerceIn(bandMin(), bandMax()))
        }
    }

    fun reset() {
        for (b in 0 until bandCount()) setBand(b, 0)
        bass = 0; virt = 0; boostDb = 0
    }
}
