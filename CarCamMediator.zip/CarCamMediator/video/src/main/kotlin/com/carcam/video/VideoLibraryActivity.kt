package com.carcam.video

import com.carcam.ui.CarCamTheme

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoItem(
    val id: Long, val uri: Uri, val title: String, val durationMs: Long,
    val size: Long, val folder: String, val path: String, val dateAdded: Long,
)

private object Thumbs {
    private val cache = LruCache<String, Bitmap>(80)
    private val misses = HashSet<String>()
    suspend fun load(ctx: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        val key = uri.toString()
        cache.get(key)?.let { return@withContext it }
        if (synchronized(misses) { key in misses }) return@withContext null
        val b = runCatching { ctx.contentResolver.loadThumbnail(uri, Size(320, 180), null) }.getOrNull()
        if (b != null) cache.put(key, b) else synchronized(misses) { misses.add(key) }
        b
    }
}

private enum class VTab(val label: String) { ALL("الكل"), FOLDERS("المجلدات"), MINE("تسجيلاتي"), RECENT("الأحدث") }

/** مكتبة الفيديو: كل فيديوهات الهاتف مع مصغرات وتصنيف بالمجلدات، وتبويب لتسجيلات التطبيق */
class VideoLibraryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CarCamTheme { Root() } }
    }

    private fun query(): List<VideoItem> {
        val out = mutableListOf<VideoItem>()
        val col = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE, MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.DATE_ADDED,
        )
        contentResolver.query(col, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val iBucket = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            val iPath = c.getColumnIndexOrThrow(MediaStore.Video.Media.RELATIVE_PATH)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out += VideoItem(
                    id, ContentUris.withAppendedId(col, id),
                    (c.getString(iName) ?: "فيديو").substringBeforeLast('.'),
                    c.getLong(iDur), c.getLong(iSize),
                    c.getString(iBucket) ?: "غير معروف", c.getString(iPath) ?: "", c.getLong(iAdded)
                )
            }
        }
        return out
    }

    private fun open(v: VideoItem) {
        startActivity(
            Intent(this, VideoPlayerActivity::class.java)
                .putExtra("uri", v.uri.toString()).putExtra("title", v.title)
        )
    }

    @Composable
    private fun Root() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        var granted by remember {
            mutableStateOf(ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED)
        }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
        LaunchedEffect(Unit) { if (!granted) launcher.launch(perm) }
        if (!granted) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { Text("نحتاج إذن قراءة الفيديو") }
            return
        }
        Library()
    }

    @Composable
    private fun Library() {
        var videos by remember { mutableStateOf(listOf<VideoItem>()) }
        var tab by remember { mutableStateOf(if (intent.getStringExtra("tab") == "mine") VTab.MINE else VTab.ALL) }
        var q by remember { mutableStateOf("") }
        var drillTitle by remember { mutableStateOf<String?>(null) }
        var drill by remember { mutableStateOf<List<VideoItem>>(emptyList()) }

        LaunchedEffect(Unit) { videos = withContext(Dispatchers.IO) { runCatching { query() }.getOrDefault(emptyList()) } }
        BackHandler(drillTitle != null) { drillTitle = null }

        fun search(l: List<VideoItem>) = if (q.isBlank()) l else l.filter { it.title.contains(q, true) }

        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            OutlinedTextField(
                q, { q = it }, singleLine = true, label = { Text("بحث (${videos.size} فيديو)") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            )
            ScrollableTabRow(selectedTabIndex = tab.ordinal, edgePadding = 8.dp) {
                VTab.entries.forEach { t -> Tab(tab == t, { tab = t; drillTitle = null }, text = { Text(t.label) }) }
            }
            Box(Modifier.weight(1f)) {
                if (drillTitle != null) {
                    Column {
                        Text(drillTitle!!, Modifier.padding(12.dp), style = MaterialTheme.typography.titleMedium)
                        VideoList(search(drill))
                    }
                } else when (tab) {
                    VTab.ALL -> VideoList(search(videos))
                    VTab.RECENT -> VideoList(search(videos.take(50)))
                    VTab.MINE -> VideoList(search(videos.filter { it.path.contains("CarCam") }))
                    VTab.FOLDERS -> {
                        val groups = search(videos).groupBy { it.folder }.toSortedMap()
                        LazyColumn {
                            items(groups.entries.toList(), key = { it.key }) { (name, list) ->
                                Text(
                                    "📁 $name  (${list.size})",
                                    Modifier.fillMaxWidth().clickable { drillTitle = name; drill = list }.padding(14.dp),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun VideoList(list: List<VideoItem>) {
        LazyColumn {
            items(list, key = { it.id }) { v ->
                Row(
                    Modifier.fillMaxWidth().clickable { open(v) }.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Thumb(v.uri, Modifier.width(112.dp).height(63.dp).clip(RoundedCornerShape(8.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        val s = v.durationMs / 1000
                        val dur = if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
                        Text("$dur • ${v.size / (1024 * 1024)} MB", style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider()
            }
        }
    }

    @Composable
    private fun Thumb(uri: Uri, modifier: Modifier) {
        val ctx = LocalContext.current
        val bmp by produceState<Bitmap?>(null, uri) { value = Thumbs.load(ctx, uri) }
        Box(modifier.background(Color(0xFF241C3F)), contentAlignment = Alignment.Center) {
            val b = bmp
            if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Text("▶", color = Color(0x88FFFFFF))
        }
    }
}
