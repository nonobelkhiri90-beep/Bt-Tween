package com.carcam.video

import com.carcam.ui.ShareDialog

import android.app.PictureInPictureParams
import android.util.Rational
import com.carcam.ui.CarCamTheme

import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

/**
 * مشغّل فيديو على نمط MX Player:
 * إيماءات (سحب أفقي للتقديم، يسار=سطوع، يمين=صوت، نقر مزدوج ±10ث)، سرعة، تكبير،
 * مسارات صوت وترجمة (داخلية وخارجية)، قفل، تدوير، A-B، مؤقت نوم، استئناف من آخر موضع.
 */
class VideoPlayerActivity : ComponentActivity() {
    private var exo: ExoPlayer? = null
    private var videoUri: Uri? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sleepTask: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val uri = intent.data ?: intent.getStringExtra("uri")?.let { Uri.parse(it) }
        if (uri == null) { finish(); return }
        videoUri = uri
        val title = intent.getStringExtra("title") ?: uri.lastPathSegment ?: "فيديو"

        val p = ExoPlayer.Builder(this).build()
        exo = p
        val saved = getSharedPreferences("video_pos", MODE_PRIVATE).getLong(uri.toString(), 0L)
        p.setMediaItem(MediaItem.fromUri(uri), saved.coerceAtLeast(0L))
        p.prepare()
        p.playWhenReady = true

        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())

        setContent { CarCamTheme(rtl = false) { PlayerScreen(p, title) } }
    }

    private fun savePosition() {
        val p = exo ?: return
        val u = videoUri ?: return
        val d = p.duration
        val pos = p.currentPosition
        val v = if (d > 0 && d - pos < 3000) 0L else pos
        getSharedPreferences("video_pos", MODE_PRIVATE).edit().putLong(u.toString(), v).apply()
    }

    override fun onPause() { savePosition(); super.onPause() }

    /** عند إغلاق الشاشة أو الخروج الكامل نوقف التشغيل (في وضع النافذة العائمة يبقى يعمل) */
    override fun onStop() { exo?.pause(); super.onStop() }

    private fun enterPip() {
        runCatching {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (exo?.isPlaying == true) enterPip()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        exo?.release(); exo = null
        super.onDestroy()
    }

    private fun brightness(): Float = window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
    private fun setBrightness(b: Float) {
        val lp = window.attributes
        lp.screenBrightness = b.coerceIn(0.02f, 1f)
        window.attributes = lp
    }

    private fun addSubtitle(p: ExoPlayer, sub: Uri) {
        val video = videoUri ?: return
        val pos = p.currentPosition
        val was = p.playWhenReady
        val name = (sub.lastPathSegment ?: "").lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val cfg = MediaItem.SubtitleConfiguration.Builder(sub)
            .setMimeType(mime).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        val item = MediaItem.Builder().setUri(video).setSubtitleConfigurations(listOf(cfg)).build()
        p.setMediaItem(item, pos)
        p.prepare()
        p.playWhenReady = was
    }

    private fun filmWithThisAudio(p: ExoPlayer) {
        val u = videoUri ?: return
        val pos = p.currentPosition
        p.pause()
        startActivity(
            Intent().setClassName(packageName, "com.carcam.camera.CameraActivity")
                .setData(u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .putExtra("music_uri", u.toString()).putExtra("music_start_ms", pos)
        )
    }

    @Composable
    private fun PlayerScreen(p: ExoPlayer, title: String) {
        val audio = remember { getSystemService(AudioManager::class.java) }
        var showControls by remember { mutableStateOf(true) }
        var locked by remember { mutableStateOf(false) }
        var playing by remember { mutableStateOf(p.isPlaying) }
        var pos by remember { mutableLongStateOf(0L) }
        var dur by remember { mutableLongStateOf(0L) }
        var dragging by remember { mutableStateOf(false) }
        var dragValue by remember { mutableFloatStateOf(0f) }
        var speed by remember { mutableFloatStateOf(1f) }
        var resize by remember { mutableIntStateOf(0) }
        var orient by remember { mutableIntStateOf(0) }
        var hud by remember { mutableStateOf<String?>(null) }
        var tracks by remember { mutableStateOf(p.currentTracks) }
        var dialog by remember { mutableIntStateOf(0) }
        var abA by remember { mutableLongStateOf(-1L) }
        var abB by remember { mutableLongStateOf(-1L) }
        var sleepMin by remember { mutableIntStateOf(0) }
        var tick by remember { mutableIntStateOf(0) }
        var inPip by remember { mutableStateOf(false) }
        var showShare by remember { mutableStateOf(false) }

        val subPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
            if (u != null) addSubtitle(p, u)
        }

        DisposableEffect(p) {
            val l = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                override fun onTracksChanged(t: Tracks) { tracks = t }
            }
            p.addListener(l)
            onDispose { p.removeListener(l) }
        }
        LaunchedEffect(p) {
            while (true) {
                if (!dragging) pos = p.currentPosition
                inPip = isInPictureInPictureMode
                dur = p.duration.takeIf { it > 0 } ?: 0L
                if (abA >= 0 && abB > abA && p.currentPosition >= abB) p.seekTo(abA)
                delay(250)
            }
        }
        LaunchedEffect(orient) {
            requestedOrientation = when (orient) {
                1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                2 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
        LaunchedEffect(showControls, playing, tick) {
            if (showControls && playing) { delay(4000); showControls = false }
        }
        LaunchedEffect(hud) { if (hud != null) { delay(800); hud = null } }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c -> PlayerView(c).apply { player = p; useController = false } },
                update = { it.resizeMode = listOf(0, 3, 4)[resize] }, // احتواء / ملء / تكبير
                modifier = Modifier.fillMaxSize()
            )

            // طبقة الإيماءات
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(locked) {
                        detectTapGestures(
                            onTap = { showControls = !showControls; tick++ },
                            onDoubleTap = { off ->
                                if (locked) return@detectTapGestures
                                val w = size.width
                                when {
                                    off.x < w / 3f -> { p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0)); hud = "⏪ −10 ث" }
                                    off.x > w * 2f / 3f -> { p.seekTo(p.currentPosition + 10_000); hud = "+10 ث ⏩" }
                                    else -> if (p.isPlaying) p.pause() else p.play()
                                }
                            }
                        )
                    }
                    .pointerInput(locked) {
                        if (locked) return@pointerInput
                        var mode = 0 // 1 تقديم، 2 سطوع، 3 صوت
                        var tx = 0f; var ty = 0f; var startX = 0f
                        var startPos = 0L; var startBright = 0.5f; var startVol = 0f
                        var target = 0L
                        detectDragGestures(
                            onDragStart = { off -> mode = 0; tx = 0f; ty = 0f; startX = off.x; startPos = p.currentPosition },
                            onDragEnd = { if (mode == 1) p.seekTo(target); mode = 0 },
                            onDragCancel = { mode = 0 },
                            onDrag = { change, amount ->
                                change.consume()
                                tx += amount.x; ty += amount.y
                                if (mode == 0 && max(abs(tx), abs(ty)) > 24f) {
                                    mode = if (abs(tx) > abs(ty)) 1 else if (startX < size.width / 2f) 2 else 3
                                    startBright = brightness()
                                    startVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                                        audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                }
                                when (mode) {
                                    1 -> {
                                        val d = p.duration.takeIf { it > 0 } ?: Long.MAX_VALUE / 4
                                        target = (startPos + (tx / size.width * 90_000).toLong()).coerceIn(0, d)
                                        val delta = (target - startPos) / 1000
                                        hud = "${if (delta >= 0) "+" else ""}$delta ث  (${fmt(target)})"
                                    }
                                    2 -> {
                                        val b = (startBright - ty / size.height * 1.2f).coerceIn(0.02f, 1f)
                                        setBrightness(b); hud = "☀ ${(b * 100).toInt()}%"
                                    }
                                    3 -> {
                                        val f = (startVol - ty / size.height * 1.2f).coerceIn(0f, 1f)
                                        val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (f * mx).toInt(), 0)
                                        hud = "🔊 ${(f * 100).toInt()}%"
                                    }
                                }
                            }
                        )
                    }
            )

            hud?.let {
                Text(
                    it, color = Color.White, fontSize = 22.sp,
                    modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp))
                        .background(Color(0xAA000000)).padding(14.dp)
                )
            }

            if (inPip) {
                // النافذة العائمة: بلا أزرار
            } else if (locked) {
                if (showControls) Chip("🔓 فتح القفل", Modifier.align(Alignment.CenterStart).padding(12.dp)) { locked = false }
            } else if (showControls) {
                // الشريط العلوي
                Row(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().background(Color(0x99000000)).statusBarsPadding().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Chip("←") { finish() }
                    Text(title, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
                    Chip("🔒") { locked = true; tick++ }
                    Chip("⧉") { enterPip() }
                    Chip("📤") { showShare = true; tick++ }
                    Chip(listOf("احتواء", "ملء", "تكبير")[resize]) { resize = (resize + 1) % 3; tick++ }
                    Chip(listOf("↻ تلقائي", "↔ أفقي", "📱 طولي")[orient]) { orient = (orient + 1) % 3; tick++ }
                }
                // الوسط
                Row(
                    Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Round("⏪") { p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0)); tick++ }
                    Box(
                        Modifier.size(72.dp).clip(CircleShape).background(Color(0xAA000000))
                            .clickable { if (p.isPlaying) p.pause() else p.play(); tick++ },
                        contentAlignment = Alignment.Center
                    ) { Text(if (playing) "⏸" else "▶", color = Color.White, fontSize = 30.sp) }
                    Round("⏩") { p.seekTo(p.currentPosition + 10_000); tick++ }
                }
                // الشريط السفلي
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x99000000))
                        .navigationBarsPadding().padding(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fmt(if (dragging) (dragValue * dur).toLong() else pos), color = Color.White, fontSize = 12.sp)
                        Slider(
                            value = if (dragging) dragValue else if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                            onValueChange = { dragging = true; dragValue = it; tick++ },
                            onValueChangeFinished = { p.seekTo((dragValue * dur).toLong()); pos = (dragValue * dur).toLong(); dragging = false },
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                        Text(fmt(dur), color = Color.White, fontSize = 12.sp)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("${speed}x") {
                            val l = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
                            speed = l[(l.indexOf(speed) + 1) % l.size]; p.setPlaybackSpeed(speed); tick++
                        }
                        Chip("🔊 مسار الصوت") { dialog = 1 }
                        Chip("💬 ترجمة") { dialog = 2 }
                        Chip(if (abA < 0) "A-B" else if (abB < 0) "A ${fmt(abA)}" else "A-B ✓") {
                            when {
                                abA < 0 -> abA = p.currentPosition
                                abB < 0 -> { if (p.currentPosition > abA) abB = p.currentPosition }
                                else -> { abA = -1; abB = -1 }
                            }
                            tick++
                        }
                        Chip(if (sleepMin == 0) "⏲ نوم" else "⏲ $sleepMin د") {
                            sleepMin = when (sleepMin) { 0 -> 15; 15 -> 30; 30 -> 60; else -> 0 }
                            sleepTask?.let { handler.removeCallbacks(it) }; sleepTask = null
                            if (sleepMin > 0) {
                                val t = Runnable { p.pause(); sleepMin = 0 }
                                sleepTask = t
                                handler.postDelayed(t, sleepMin * 60_000L)
                            }
                            tick++
                        }
                        Chip("🎬 صوّر بصوته") { filmWithThisAudio(p) }
                    }
                }
            }
        }

        if (showShare) videoUri?.let { ShareDialog(it) { showShare = false } }

        if (dialog != 0) {
            val type = if (dialog == 1) C.TRACK_TYPE_AUDIO else C.TRACK_TYPE_TEXT
            AlertDialog(
                onDismissRequest = { dialog = 0 },
                confirmButton = { TextButton({ dialog = 0 }) { Text("إغلاق") } },
                title = { Text(if (dialog == 1) "مسار الصوت" else "الترجمة") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        if (type == C.TRACK_TYPE_TEXT) {
                            Text(
                                "⛔ إيقاف الترجمة",
                                Modifier.fillMaxWidth().clickable {
                                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                                }.padding(12.dp)
                            )
                        }
                        val groups = tracks.groups.filter { it.type == type }
                        if (groups.isEmpty()) Text("لا توجد مسارات", Modifier.padding(12.dp))
                        groups.forEach { g ->
                            for (i in 0 until g.length) {
                                val f = g.getTrackFormat(i)
                                val label = listOfNotNull(
                                    f.label, f.language?.takeIf { it != "und" },
                                    if (type == C.TRACK_TYPE_AUDIO && f.channelCount > 0) "${f.channelCount}ch" else null
                                ).joinToString(" · ").ifBlank { "مسار ${i + 1}" }
                                Text(
                                    (if (g.isTrackSelected(i)) "✓ " else "") + label,
                                    Modifier.fillMaxWidth().clickable {
                                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                                            .setTrackTypeDisabled(type, false)
                                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                                    }.padding(12.dp)
                                )
                            }
                        }
                        if (type == C.TRACK_TYPE_TEXT) {
                            TextButton({ dialog = 0; subPicker.launch(arrayOf("*/*")) }) { Text("➕ إضافة ملف ترجمة (srt / vtt / ass)") }
                        }
                    }
                }
            )
        }
    }

    @Composable
    private fun Chip(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
        Text(
            text, color = Color.White,
            modifier = modifier.clip(RoundedCornerShape(16.dp)).background(Color(0x55FFFFFF))
                .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }

    @Composable
    private fun Round(text: String, onClick: () -> Unit) {
        Box(
            Modifier.size(52.dp).clip(CircleShape).background(Color(0xAA000000)).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Text(text, color = Color.White, fontSize = 20.sp) }
    }
}
