plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.carcam.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.carcam.mediator"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
    signingConfigs {
        // مفتاح ثابت داخل المشروع: يسمح بتحديث التطبيق فوق النسخة المثبّتة دون حذفها
        getByName("debug") {
            storeFile = rootProject.file("carcam-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(project(":ui"))
    implementation(project(":audio-engine"))
    implementation(project(":core"))
    implementation(project(":camera"))
    implementation(project(":library"))
    implementation(project(":video"))
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
}
