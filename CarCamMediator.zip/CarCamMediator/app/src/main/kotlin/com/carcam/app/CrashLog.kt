package com.carcam.app

import android.content.Context
import android.util.Log

/** يحفظ آخر انهيار ليعرضه التطبيق عند الفتح التالي (للتشخيص دون Android Studio) */
object CrashLog {
    private const val PREF = "crash_log"

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                app.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString("last", "[${t.name}]\n" + Log.getStackTraceString(e).take(3500)).commit()
            }
            prev?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("last", null)

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("last").apply()
    }
}
