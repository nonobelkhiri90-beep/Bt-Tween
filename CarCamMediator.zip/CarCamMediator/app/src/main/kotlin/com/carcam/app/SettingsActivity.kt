package com.carcam.app

import com.carcam.ui.DevCredit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.carcam.audio.NOTE_NAMES
import com.carcam.audio.Preset
import com.carcam.audio.Scale
import com.carcam.camera.Res
import com.carcam.core.AppSettings
import com.carcam.core.CarPrefs
import com.carcam.ui.CarCamTheme
import com.carcam.ui.CcColors
import com.carcam.ui.OptionChip

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CarCamTheme { Screen() } }
    }

    @Composable
    private fun Screen() {
        val st = remember { AppSettings(this) }
        val car = remember { CarPrefs(this) }

        var res by remember { mutableStateOf(st.resolution) }
        var portrait by remember { mutableStateOf(st.portraitDefault) }
        var grid by remember { mutableStateOf(st.gridDefault) }
        var timer by remember { mutableIntStateOf(st.timerDefault) }
        var keys by remember { mutableStateOf(st.shutterKeys) }

        var engine by remember { mutableStateOf(st.engineDefaultOn) }
        var preset by remember { mutableStateOf(st.preset) }
        var vKey by remember { mutableIntStateOf(st.voiceKey) }
        var vScale by remember { mutableStateOf(st.voiceScale) }
        var denoise by remember { mutableIntStateOf(st.denoise) }
        var autoAudio by remember { mutableStateOf(st.autoAudio) }
        var useCalib by remember { mutableStateOf(st.useCalibration) }
        var fps by remember { mutableIntStateOf(st.fps) }
        var codec by remember { mutableStateOf(st.codec) }
        var tier by remember { mutableIntStateOf(st.qualityTier) }
        var stab by remember { mutableIntStateOf(st.stabilization) }
        var isp by remember { mutableStateOf(st.ispHigh) }
        var sharp by remember { mutableIntStateOf(st.sharpness) }
        var musicScale by remember { mutableFloatStateOf(st.musicGainScale) }
        var micScale by remember { mutableFloatStateOf(st.micGainScale) }
        var monitor by remember { mutableStateOf(st.monitorMusic) }

        var share by remember { mutableStateOf(st.shareAfterSave) }
        var auto by remember { mutableStateOf(car.autoMonitor) }

        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("الإعدادات", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                TextButton({ finish() }) { Text("رجوع") }
            }

            Section("📷 الكاميرا") {
                ChipRow("الدقة الافتراضية", Res.entries.map { it.label }, Res.entries.indexOfFirst { it.name == res }) {
                    res = Res.entries[it].name; st.resolution = res
                }
                ChipRow("الاتجاه الافتراضي", listOf("أفقي", "طولي"), if (portrait) 1 else 0) {
                    portrait = it == 1; st.portraitDefault = portrait
                }
                ChipRow("مؤقت التصوير", listOf("بلا", "3 ثوانٍ", "10 ثوانٍ"), when (timer) { 3 -> 1; 10 -> 2; else -> 0 }) {
                    timer = when (it) { 1 -> 3; 2 -> 10; else -> 0 }; st.timerDefault = timer
                }
                SwitchRow("شبكة التكوين", "تظهر عند فتح الكاميرا", grid) { grid = it; st.gridDefault = it }
                SwitchRow("مفاتيح الصوت كزر تصوير", "مفتاح الصوت أو زر سماعة البلوتوث يبدأ ويوقف التسجيل", keys) {
                    keys = it; st.shutterKeys = it
                }
            }

            Section("🎥 جودة الفيديو (كاميرا لايف)") {
                ChipRow("معدل الإطارات", listOf("24", "30", "60"), when (fps) { 24 -> 0; 60 -> 2; else -> 1 }) {
                    fps = when (it) { 0 -> 24; 2 -> 60; else -> 30 }; st.fps = fps
                }
                ChipRow("الترميز", listOf("H.264", "HEVC (أصغر حجماً)"), if (codec == "HEVC") 1 else 0) {
                    codec = if (it == 1) "HEVC" else "AVC"; st.codec = codec
                }
                ChipRow("الجودة", listOf("عادية", "عالية", "قصوى"), tier) { tier = it; st.qualityTier = it }
                ChipRow("التثبيت", listOf("بلا", "قياسي", "قوي (وضع الحركة)"), stab) { stab = it; st.stabilization = it }
                ChipRow("حدة الصورة", listOf("بلا", "خفيفة", "قوية"), sharp) { sharp = it; st.sharpness = it }
                SwitchRow("معالجة صورة عالية الجودة", "تقليل ضوضاء وحدة وتظليل عالي الجودة من المستشعر (قد تخفض المعدل في بعض الهواتف)", isp) {
                    isp = it; st.ispHigh = it
                }
            }

            Section("🎛 الصوت") {
                SwitchRow("الصوت التلقائي (يسمع ويضبط)", "AGC للميكروفون، خفض الموسيقى أثناء الكلام، توازن الباص والحدة، وجهارة موحّدة", autoAudio) {
                    autoAudio = it; st.autoAudio = it
                }
                SwitchRow("تطبيق معايرة المقصورة", "من «مركز البث ← معايرة المعادل»", useCalib) { useCalib = it; st.useCalibration = it }
                SwitchRow("محرك الصوت افتراضياً", "عند وجود موسيقى مختارة", engine) { engine = it; st.engineDefaultOn = it }
                ChipRow("المؤثر الافتراضي", Preset.entries.map { it.label }, Preset.entries.indexOfFirst { it.name == preset }) {
                    preset = Preset.entries[it].name; st.preset = preset
                }
                ChipRow("مقام Autotune", listOf("تلقائي") + NOTE_NAMES.toList(), vKey + 1) {
                    vKey = it - 1; st.voiceKey = vKey
                }
                ChipRow("سلّم Autotune", Scale.entries.map { it.label }, Scale.entries.indexOfFirst { it.name == vScale }) {
                    vScale = Scale.entries[it].name; st.voiceScale = vScale
                }
                ChipRow("تنقية الضوضاء (محرك الصوت)", listOf("إيقاف", "خفيفة", "متوسطة", "قوية"), denoise) {
                    denoise = it; st.denoise = it
                }
                SliderRow("مستوى الموسيقى", musicScale, 0.3f..1.8f) { musicScale = it; st.musicGainScale = it }
                SliderRow("مستوى الصوت (الميكروفون)", micScale, 0.3f..2f) { micScale = it; st.micGainScale = it }
                SwitchRow("تشغيل الموسيقى أثناء التسجيل", "عبر مكبرات الهاتف أو السيارة", monitor) {
                    monitor = it; st.monitorMusic = it
                }
            }

            Section("📤 المشاركة") {
                SwitchRow("عرض المشاركة بعد الحفظ", "تيك توك، يوتيوب، إنستغرام وغيرها", share) { share = it; st.shareAfterSave = it }
            }

            Section("🚗 النظام") {
                SwitchRow("تشغيل المراقبة بعد إعادة تشغيل الهاتف", "تعمل فقط إن كانت سيارتك محددة", auto) {
                    auto = it; car.autoMonitor = it
                }
                OutlinedButton({ CrashLog.clear(this@SettingsActivity) }) { Text("مسح سجل الانهيارات") }
                Text("CarCam 0.1", style = MaterialTheme.typography.bodySmall, color = CcColors.Muted)
            }
            DevCredit()
        }
    }

    @Composable
    private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(colors = CardDefaults.cardColors(containerColor = CcColors.Surface), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = CcColors.Primary)
                content()
            }
        }
    }

    @Composable
    private fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title)
                if (desc != null) Text(desc, style = MaterialTheme.typography.bodySmall, color = CcColors.Muted)
            }
            Switch(checked, onChange)
        }
    }

    @Composable
    private fun ChipRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEachIndexed { i, o -> OptionChip(o, i == selected) { onSelect(i) } }
            }
        }
    }

    @Composable
    private fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
        Column {
            Text("$title: ${"%.1f".format(value)}×", style = MaterialTheme.typography.bodyMedium)
            Slider(value, onChange, valueRange = range)
        }
    }
}
