package com.carcam.app

import com.carcam.ui.DevCredit

import com.carcam.camera.LiveCameraActivity
import com.carcam.library.LiveHubActivity

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.carcam.camera.CameraActivity
import com.carcam.core.CarPrefs
import com.carcam.core.MonitorService
import com.carcam.core.SessionStore
import com.carcam.library.LibraryActivity
import com.carcam.ui.ActionCard
import com.carcam.ui.CarCamTheme
import com.carcam.ui.CcColors
import com.carcam.ui.StatusRow
import com.carcam.video.VideoLibraryActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CarCamTheme { Home() } }
    }

    private fun hasBtPermission() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    /** آمنة: لا تقرأ الأجهزة دون إذن، ولا تنهار عند أي خطأ */
    @SuppressLint("MissingPermission")
    private fun bondedDevices(): List<Pair<String, String>> {
        if (!hasBtPermission()) return emptyList()
        return runCatching {
            getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices.orEmpty()
                .map { (it.name ?: "؟") to it.address }
        }.getOrDefault(emptyList())
    }

    private fun missingPermissions(): List<String> = buildList {
        if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
    }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }

    private fun permLabel(p: String) = when (p) {
        Manifest.permission.BLUETOOTH_CONNECT -> "الأجهزة القريبة (بلوتوث)"
        Manifest.permission.POST_NOTIFICATIONS -> "الإشعارات"
        Manifest.permission.CAMERA -> "الكاميرا"
        Manifest.permission.RECORD_AUDIO -> "الميكروفون"
        else -> p
    }

    @Composable
    private fun Home() {
        val prefs = remember { CarPrefs(this) }
        val session by SessionStore.state.collectAsStateWithLifecycle()
        var carName by remember { mutableStateOf(prefs.carName) }
        var carAddr by remember { mutableStateOf(prefs.carAddress) }
        var devices by remember { mutableStateOf(listOf<Pair<String, String>>()) }
        var missing by remember { mutableStateOf(missingPermissions()) }
        var crash by remember { mutableStateOf(CrashLog.read(this)) }

        val permLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { missing = missingPermissions(); devices = bondedDevices() }

        LaunchedEffect(Unit) {
            devices = bondedDevices()
            if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
        }

        fun toggleMonitor(on: Boolean) {
            if (on) {
                if (MonitorService.start(this)) prefs.autoMonitor = true
                else Toast.makeText(this, "امنح إذن الأجهزة القريبة أولاً", Toast.LENGTH_LONG).show()
            } else {
                MonitorService.stop(this); prefs.autoMonitor = false
            }
        }

        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // الرأس
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(54.dp).clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(CcColors.Primary, CcColors.Accent))),
                    contentAlignment = Alignment.Center
                ) { Text("🎬", fontSize = 28.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("CarCam", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("وسيط الكاميرا والموسيقى للسيارة", style = MaterialTheme.typography.bodySmall, color = CcColors.Muted)
                }
                TextButton({ startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }) { Text("⚙️", fontSize = 24.sp) }
            }

            // انهيار سابق
            crash?.let { text ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0x33FF4D6D)), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("حدث انهيار في المرة السابقة (أرسل هذا النص):", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text, fontSize = 10.sp, lineHeight = 12.sp,
                            modifier = Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState())
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({
                                getSystemService(ClipboardManager::class.java)
                                    .setPrimaryClip(ClipData.newPlainText("crash", text))
                            }) { Text("نسخ") }
                            OutlinedButton({ CrashLog.clear(this@MainActivity); crash = null }) { Text("مسح") }
                        }
                    }
                }
            }

            // الأذونات
            if (missing.isNotEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = CcColors.SurfaceHi), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("أذونات مطلوبة", style = MaterialTheme.typography.titleMedium)
                        Text(missing.joinToString("، ") { permLabel(it) }, style = MaterialTheme.typography.bodySmall, color = CcColors.Muted)
                        Button({ permLauncher.launch(missing.toTypedArray()) }) { Text("منح الأذونات") }
                    }
                }
            }

            // حالة المراقبة
            Card(colors = CardDefaults.cardColors(containerColor = CcColors.Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("المراقبة التلقائية", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (session.ready) "جاهز للتسجيل الآن ✅"
                                else "تعرض زر التسجيل عند اتصال السيارة وتشغيل الموسيقى",
                                style = MaterialTheme.typography.bodySmall, color = CcColors.Muted
                            )
                        }
                        Switch(session.monitoring, { toggleMonitor(it) }, enabled = carAddr != null)
                    }
                    StatusRow("السيارة", carName ?: "لم تُحدد", session.carConnected)
                    StatusRow("الموسيقى", if (session.musicActive) "تعمل" else "متوقفة", session.musicActive)
                }
            }

            // الأدوات
            Text("الأدوات", style = MaterialTheme.typography.titleMedium, color = CcColors.Muted)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard("📷", "الكاميرا", "4K • محرك صوت", Modifier.weight(1f)) {
                    startActivity(Intent(this@MainActivity, CameraActivity::class.java))
                }
                ActionCard("🎵", "الموسيقى", "مكتبة ومشغّل", Modifier.weight(1f)) {
                    startActivity(Intent(this@MainActivity, LibraryActivity::class.java))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard("🎞", "الفيديو", "مشغّل بإيماءات", Modifier.weight(1f)) {
                    startActivity(Intent(this@MainActivity, VideoLibraryActivity::class.java))
                }
                ActionCard("📁", "تسجيلاتي", "فيديوهات CarCam", Modifier.weight(1f)) {
                    startActivity(Intent(this@MainActivity, VideoLibraryActivity::class.java).putExtra("tab", "mine"))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard("🎥", "كاميرا لايف", "قلب بلا انقطاع • فلاتر (تجريبية)", Modifier.weight(1f)) {
                    startActivity(Intent(this@MainActivity, LiveCameraActivity::class.java))
                }
                ActionCard("📡", "بث مباشر", "تيك توك • يوتيوب • فيسبوك • إنستغرام", Modifier.weight(1f)) {
                    startActivity(Intent(this@MainActivity, LiveHubActivity::class.java))
                }
            }

            // اختيار السيارة
            Card(colors = CardDefaults.cardColors(containerColor = CcColors.Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("سيارتك (بلوتوث)", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        TextButton({ devices = bondedDevices(); missing = missingPermissions() }) { Text("تحديث") }
                    }
                    if (devices.isEmpty()) {
                        Text(
                            "لا توجد أجهزة مقترنة. اقرن السيارة من إعدادات البلوتوث ثم اضغط تحديث.",
                            style = MaterialTheme.typography.bodySmall, color = CcColors.Muted
                        )
                    }
                    devices.forEach { (name, addr) ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                                prefs.carAddress = addr; prefs.carName = name; carName = name; carAddr = addr
                            }.padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = addr == carAddr, onClick = null)
                            Spacer(Modifier.width(10.dp))
                            Text(name)
                        }
                    }
                }
            }

            Text(
                "⚠️ للسلامة: لا تتفاعل مع الشاشة أثناء القيادة. ابدأ التسجيل من إشعار السيارة أو بمفتاح الصوت داخل الكاميرا.",
                style = MaterialTheme.typography.bodySmall, color = CcColors.Muted
            )
            DevCredit()
        }
    }
}
