package com.carcam.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.carcam.camera.CameraActivity
import com.carcam.core.CarPrefs
import com.carcam.core.MonitorService
import com.carcam.core.SessionStore
import com.carcam.library.LibraryActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    private fun hasBtPermission() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    /** آمنة: لا تقرأ الأجهزة دون إذن، ولا تنهار عند أي خطأ */
    @SuppressLint("MissingPermission")
    private fun bondedDevices(): List<Pair<String, String>> {
        if (!hasBtPermission()) return emptyList()
        return runCatching {
            getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices.orEmpty()
                .map { (it.name ?: "؟") to it.address }
        }.getOrDefault(emptyList())
    }

    @Composable
    private fun Screen() {
        val prefs = remember { CarPrefs(this) }
        val session by SessionStore.state.collectAsStateWithLifecycle()
        var carName by remember { mutableStateOf(prefs.carName) }
        var devices by remember { mutableStateOf(listOf<Pair<String, String>>()) }
        var btOk by remember { mutableStateOf(hasBtPermission()) }
        var crash by remember { mutableStateOf(CrashLog.read(this)) }

        val permLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { btOk = hasBtPermission(); devices = bondedDevices() }

        fun askPermissions() {
            val perms = buildList {
                if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
                if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (perms.isNotEmpty()) permLauncher.launch(perms.toTypedArray())
        }

        LaunchedEffect(Unit) {
            devices = bondedDevices()
            if (!btOk) askPermissions()
        }

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
            crash?.let { text ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("حدث انهيار في المرة السابقة (أرسل هذا النص):", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text, fontSize = 10.sp, lineHeight = 12.sp,
                            modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({
                                getSystemService(ClipboardManager::class.java)
                                    .setPrimaryClip(ClipData.newPlainText("crash", text))
                            }) { Text("نسخ") }
                            OutlinedButton({ CrashLog.clear(this@MainActivity); crash = null }) { Text("مسح") }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            Text("CarCam Mediator", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text("السيارة: ${carName ?: "لم تُحدد"}")
            Text("البلوتوث: ${if (session.carConnected) "متصل ✅" else "غير متصل"}")
            Text("الموسيقى: ${if (session.musicActive) "تعمل 🎵" else "متوقفة"}")
            Text("جاهز للتسجيل: ${if (session.ready) "نعم" else "لا"}")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (session.monitoring) MonitorService.stop(this@MainActivity)
                        else MonitorService.start(this@MainActivity)
                    },
                    enabled = carName != null,
                ) { Text(if (session.monitoring) "إيقاف المراقبة" else "بدء المراقبة") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ startActivity(Intent(this@MainActivity, CameraActivity::class.java)) }) { Text("فتح الكاميرا") }
                Button({ startActivity(Intent(this@MainActivity, LibraryActivity::class.java)) }) { Text("مكتبة الموسيقى") }
            }
            Spacer(Modifier.height(12.dp))
            Text("اختر بلوتوث سيارتك:", style = MaterialTheme.typography.titleMedium)
            if (!btOk) {
                Text("إذن الأجهزة القريبة غير ممنوح.")
                Button({ askPermissions() }) { Text("منح الإذن") }
            }
            LazyColumn {
                items(devices) { (name, addr) ->
                    Text(
                        name,
                        Modifier.fillMaxWidth().clickable {
                            prefs.carAddress = addr; prefs.carName = name; carName = name
                        }.padding(vertical = 12.dp)
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
