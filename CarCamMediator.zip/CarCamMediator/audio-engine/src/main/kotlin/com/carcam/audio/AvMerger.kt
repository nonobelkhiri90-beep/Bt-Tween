package com.carcam.audio

import android.content.ContentValues
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaMetadataRetriever
import android.media.MediaCodec
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يدمج فيديو صامت مع ملف صوت m4a في ملف mp4 نهائي دون إعادة ترميز */
object AvMerger {

    /**
     * @param audioSkipUs كم نقتطع من بداية الصوت ليتطابق مع لحظة بدء الفيديو
     *        (الصوت يبدأ قبل الفيديو بقليل). القيمة السالبة تؤخّر الصوت.
     * @return Uri الملف الجديد، أو null عند الفشل. عند النجاح يُحذف الفيديو الصامت الأصلي.
     */
    fun merge(ctx: Context, videoUri: Uri, audioFile: File, audioSkipUs: Long): Uri? {
        val cr = ctx.contentResolver
        val vEx = MediaExtractor(); val aEx = MediaExtractor()
        var outUri: Uri? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var muxer: MediaMuxer? = null
        try {
            vEx.setDataSource(ctx, videoUri, null)
            aEx.setDataSource(audioFile.path)
            val vT = findTrack(vEx, "video/"); val aT = findTrack(aEx, "audio/")
            if (vT < 0 || aT < 0) return null
            vEx.selectTrack(vT); aEx.selectTrack(aT)

            val rotation = MediaMetadataRetriever().let { r ->
                try {
                    r.setDataSource(ctx, videoUri)
                    r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                } finally { r.release() }
            }

            val name = "CarCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "_music"
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CarCam")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            outUri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
            pfd = cr.openFileDescriptor(outUri, "rw") ?: return null
            val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            m.setOrientationHint(rotation)
            val vOut = m.addTrack(vEx.getTrackFormat(vT))
            val aOut = m.addTrack(aEx.getTrackFormat(aT))
            m.start()

            if (audioSkipUs > 0) aEx.seekTo(audioSkipUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                val vt = vEx.sampleTime
                var at = aEx.sampleTime
                while (at >= 0 && at - audioSkipUs < 0) { aEx.advance(); at = aEx.sampleTime }
                if (vt < 0 && at < 0) break
                val useVideo = at < 0 || (vt >= 0 && vt <= at - audioSkipUs)
                val ex = if (useVideo) vEx else aEx
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                info.set(0, n, if (useVideo) vt else at - audioSkipUs, ex.sampleFlags)
                m.writeSampleData(if (useVideo) vOut else aOut, buf, info)
                ex.advance()
            }
            m.stop(); m.release(); muxer = null
            pfd.close(); pfd = null

            cr.update(outUri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            runCatching { cr.delete(videoUri, null, null) }
            return outUri
        } catch (e: Exception) {
            outUri?.let { runCatching { cr.delete(it, null, null) } }
            return null
        } finally {
            runCatching { muxer?.release() }; runCatching { pfd?.close() }
            vEx.release(); aEx.release()
        }
    }

    private fun findTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME)?.startsWith(prefix) == true) return i
        }
        return -1
    }
}
