package com.carcam.audio

val NOTE_NAMES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

/** السلالم الموسيقية (أبعاد النوتات المسموحة نسبةً للنغمة الأساسية) */
enum class Scale(val label: String, val intervals: IntArray) {
    MAJOR("كبير", intArrayOf(0, 2, 4, 5, 7, 9, 11)),
    MINOR("صغير", intArrayOf(0, 2, 3, 5, 7, 8, 10)),
    PENTATONIC("بنتاتونيك", intArrayOf(0, 2, 4, 7, 9)),
    CHROMATIC("كروماتيك", intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)),
}

/** key: 0..11 (C..B) أو -1 لاكتشاف مقام الأغنية تلقائياً */
/** denoise: 0 إيقاف، 1 خفيفة، 2 متوسطة، 3 قوية */
class VoiceOptions(val key: Int = -1, val scale: Scale = Scale.MAJOR, val denoise: Int = 0)
