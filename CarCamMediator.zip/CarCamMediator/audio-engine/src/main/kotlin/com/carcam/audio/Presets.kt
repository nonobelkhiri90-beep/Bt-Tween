package com.carcam.audio

/** سلسلتا مؤثرات (للصوت وللموسيقى) + مستويي الصوت */
class MixSetup(
    val micChain: Effect, val musicChain: Effect, val micGain: Float, val musicGain: Float,
    val autoTune: AutoTune? = null,
)

enum class Preset(val label: String, val usesKey: Boolean = false) {
    CLEAN("نظيف"), STUDIO("ستوديو"), HALL("قاعة"), ECHO("صدى"), KARAOKE("كاريوكي"),
    AUTOTUNE("أوتوتيون", true), TPAIN("T-Pain", true),
    CHIPMUNK("طفل"), DEEP("عميق"), ROBOT("روبوت");

    /** ينشئ نسخة جديدة (المؤثرات تحمل حالة داخلية فلا تُشارَك) */
    fun create(v: VoiceOptions = VoiceOptions()): MixSetup {
        val key = if (v.key < 0) 0 else v.key
        val base = when (this) {
            CLEAN -> MixSetup(
                EffectChain(BiquadFilter.highPass(80f), NoiseGate(-50f)),
                EffectChain(), 1.0f, 0.8f
            )
            STUDIO -> MixSetup(
                EffectChain(
                    BiquadFilter.highPass(90f), NoiseGate(-48f), equalizer3(-1f, 2f, 2f),
                    Compressor(-18f, 3f, 10f, 120f, 4f), Reverb(0.4f, 0.5f, 0.12f, 1f)
                ),
                equalizer3(2f, 0f, 1f), 1.0f, 0.6f
            )
            HALL -> MixSetup(
                EffectChain(BiquadFilter.highPass(90f), Compressor(-20f, 3f, 10f, 150f, 3f), Reverb(0.85f, 0.4f, 0.35f, 0.9f)),
                Reverb(0.5f, 0.5f, 0.08f, 1f), 1.0f, 0.65f
            )
            ECHO -> MixSetup(
                EffectChain(BiquadFilter.highPass(90f), NoiseGate(-48f), Echo(320f, 0.4f, 0.45f), Reverb(0.4f, 0.5f, 0.1f, 1f)),
                EffectChain(), 1.0f, 0.65f
            )
            KARAOKE -> MixSetup(
                EffectChain(
                    BiquadFilter.highPass(90f), Compressor(-18f, 3f, 8f, 120f, 4f),
                    Echo(180f, 0.3f, 0.25f), Reverb(0.7f, 0.4f, 0.3f, 0.9f)
                ),
                EffectChain(), 1.2f, 0.5f
            )
            AUTOTUNE -> {
                val at = AutoTune(key, v.scale, 110f)
                MixSetup(
                    EffectChain(
                        BiquadFilter.highPass(90f), NoiseGate(-48f), at,
                        Compressor(-18f, 3f, 10f, 120f, 4f), Reverb(0.4f, 0.5f, 0.12f, 1f)
                    ),
                    equalizer3(2f, 0f, 1f), 1.0f, 0.55f, at
                )
            }
            TPAIN -> {
                val at = AutoTune(key, v.scale, 0f)
                MixSetup(
                    EffectChain(
                        BiquadFilter.highPass(90f), NoiseGate(-48f), at,
                        Compressor(-16f, 3f, 8f, 100f, 4f), Reverb(0.35f, 0.5f, 0.1f, 1f)
                    ),
                    equalizer3(2f, 0f, 1f), 1.0f, 0.55f, at
                )
            }
            CHIPMUNK -> MixSetup(
                EffectChain(
                    BiquadFilter.highPass(100f), NoiseGate(-48f), PitchShifter(1.335f, 1024f),
                    Compressor(-18f, 3f, 10f, 120f, 3f)
                ),
                EffectChain(), 1.0f, 0.6f
            )
            DEEP -> MixSetup(
                EffectChain(
                    BiquadFilter.highPass(80f), NoiseGate(-48f), PitchShifter(0.794f, 1024f),
                    Compressor(-18f, 3f, 10f, 120f, 3f), Reverb(0.3f, 0.5f, 0.08f, 1f)
                ),
                EffectChain(), 1.0f, 0.6f
            )
            ROBOT -> MixSetup(
                EffectChain(
                    BiquadFilter.highPass(100f), NoiseGate(-48f), RingMod(55f, 1f),
                    Echo(40f, 0.3f, 0.35f), Compressor(-16f, 3f, 10f, 100f, 4f)
                ),
                EffectChain(), 1.0f, 0.6f
            )
        }
        return if (v.denoise > 0) MixSetup(
            EffectChain(NoiseSuppress(v.denoise), base.micChain), base.musicChain, base.micGain, base.musicGain, base.autoTune
        ) else base
    }
}
