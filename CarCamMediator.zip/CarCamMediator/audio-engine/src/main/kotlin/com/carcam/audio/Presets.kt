package com.carcam.audio

/** سلسلتا مؤثرات (للصوت وللموسيقى) + مستويي الصوت */
class MixSetup(val micChain: Effect, val musicChain: Effect, val micGain: Float, val musicGain: Float)

enum class Preset(val label: String) {
    CLEAN("نظيف"), STUDIO("ستوديو"), HALL("قاعة"), ECHO("صدى"), KARAOKE("كاريوكي");

    /** ينشئ نسخة جديدة (المؤثرات تحمل حالة داخلية فلا تُشارَك) */
    fun create(): MixSetup = when (this) {
        CLEAN -> MixSetup(
            EffectChain(BiquadFilter.highPass(80f), NoiseGate(-50f)),
            EffectChain(), 1.0f, 0.8f
        )
        STUDIO -> MixSetup(
            EffectChain(
                BiquadFilter.highPass(90f), NoiseGate(-48f), equalizer3(-1f, 2f, 2f),
                Compressor(-18f, 3f, 10f, 120f, 4f), Reverb(0.4f, 0.5f, 0.12f, 1f)
            ),
            equalizer3(2f, 0f, 1f), 1.0f, 0.6f
        )
        HALL -> MixSetup(
            EffectChain(BiquadFilter.highPass(90f), Compressor(-20f, 3f, 10f, 150f, 3f), Reverb(0.85f, 0.4f, 0.35f, 0.9f)),
            Reverb(0.5f, 0.5f, 0.08f, 1f), 1.0f, 0.65f
        )
        ECHO -> MixSetup(
            EffectChain(BiquadFilter.highPass(90f), NoiseGate(-48f), Echo(320f, 0.4f, 0.45f), Reverb(0.4f, 0.5f, 0.1f, 1f)),
            EffectChain(), 1.0f, 0.65f
        )
        KARAOKE -> MixSetup(
            EffectChain(
                BiquadFilter.highPass(90f), Compressor(-18f, 3f, 8f, 120f, 4f),
                Echo(180f, 0.3f, 0.25f), Reverb(0.7f, 0.4f, 0.3f, 0.9f)
            ),
            EffectChain(), 1.2f, 0.5f
        )
    }
}
