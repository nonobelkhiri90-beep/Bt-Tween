package com.carcam.audio

import android.content.Context
import android.net.Uri
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/** يقدّر مقام الأغنية (النغمة الأساسية + كبير/صغير) من أول ثوانٍ منها (Goertzel + بروفايلات Krumhansl) */
object KeyDetector {
    class Result(val tonic: Int, val minor: Boolean)

    private val MAJOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

    fun detect(ctx: Context, uri: Uri, startMs: Long, seconds: Int = 12): Result? {
        val dec = runCatching { MusicDecoder(ctx, uri, startMs) }.getOrNull() ?: return null
        try {
            val win = SR / 2
            val buf = FloatArray(win * 2)
            val mono = FloatArray(win)
            val notes = 48..83
            val coefs = notes.map { 2.0 * cos(2.0 * PI * 440.0 * 2.0.pow((it - 69) / 12.0) / SR) }
            val chroma = DoubleArray(12)
            for (w in 0 until seconds * 2) {
                val n = dec.read(buf, win)
                if (n < win) break
                for (i in 0 until win) mono[i] = (buf[2 * i] + buf[2 * i + 1]) * 0.5f
                for ((idx, note) in notes.withIndex()) {
                    val c = coefs[idx]
                    var s1 = 0.0; var s2 = 0.0
                    for (i in 0 until win) { val s = mono[i] + c * s1 - s2; s2 = s1; s1 = s }
                    val p = s1 * s1 + s2 * s2 - c * s1 * s2
                    chroma[note % 12] += sqrt(max(p, 0.0))
                }
            }
            if (chroma.sum() < 1e-6) return null

            var best = -2.0; var bt = 0; var bm = false
            for (t in 0 until 12) for (m in 0..1) {
                val prof = if (m == 1) MINOR else MAJOR
                val x = DoubleArray(12) { chroma[(t + it) % 12] }
                val c = corr(x, prof)
                if (c > best) { best = c; bt = t; bm = (m == 1) }
            }
            return Result(bt, bm)
        } finally {
            dec.release()
        }
    }

    private fun corr(a: DoubleArray, b: DoubleArray): Double {
        val ma = a.average(); val mb = b.average()
        var num = 0.0; var da = 0.0; var db = 0.0
        for (i in a.indices) {
            num += (a[i] - ma) * (b[i] - mb)
            da += (a[i] - ma) * (a[i] - ma); db += (b[i] - mb) * (b[i] - mb)
        }
        return if (da > 0 && db > 0) num / sqrt(da * db) else 0.0
    }
}
