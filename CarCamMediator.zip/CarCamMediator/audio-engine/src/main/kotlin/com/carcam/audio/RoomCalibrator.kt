package com.carcam.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/** تخزين نتيجة المعايرة (تصحيح dB لكل أوكتاف) */
object CalibStore {
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("calib", Context.MODE_PRIVATE)

    fun get(ctx: Context): FloatArray? {
        val s = sp(ctx).getString("gains", null) ?: return null
        val p = s.split(",").mapNotNull { it.toFloatOrNull() }
        return if (p.size == RoomCalibrator.CENTERS.size) p.toFloatArray() else null
    }

    fun set(ctx: Context, g: FloatArray?) {
        sp(ctx).edit().apply {
            if (g == null) remove("gains") else putString("gains", g.joinToString(","))
        }.apply()
    }
}

/**
 * معايرة الصوت بالميكروفون: يشغّل ضجيجاً وردياً عبر المكبر ويسجّله، فيقدّر استجابة (المكبر + المقصورة)
 * في ثمانية نطاقات أوكتاف ويحسب تصحيحاً (EQ) بحدود آمنة. النتيجة تقريبية لأن استجابة ميكروفون الهاتف نفسها غير مسطحة.
 */
object RoomCalibrator {
    val CENTERS = intArrayOf(62, 125, 250, 500, 1000, 2000, 4000, 8000)

    class Result(val relativeDb: FloatArray, val correctionDb: FloatArray, val snrDb: Float, val levelDb: Float)

    private class Pink {
        private val rnd = java.util.Random(7)
        private var b0 = 0f; private var b1 = 0f; private var b2 = 0f; private var b3 = 0f
        private var b4 = 0f; private var b5 = 0f; private var b6 = 0f
        fun next(): Float {
            val w = rnd.nextFloat() * 2f - 1f
            b0 = 0.99886f * b0 + w * 0.0555179f
            b1 = 0.99332f * b1 + w * 0.0750759f
            b2 = 0.96900f * b2 + w * 0.1538520f
            b3 = 0.86650f * b3 + w * 0.3104856f
            b4 = 0.55000f * b4 + w * 0.5329522f
            b5 = -0.7616f * b5 - w * 0.0168980f
            val p = b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362f
            b6 = w * 0.115926f
            return p * 0.11f
        }
    }

    @SuppressLint("MissingPermission")
    fun run(seconds: Int = 6, onProgress: (Float) -> Unit = {}): Result? {
        val minRec = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = runCatching {
            AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minRec, 16384))
        }.getOrNull() ?: return null
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        val minTrk = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val track = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
                )
                .setBufferSizeInBytes(max(minTrk, 16384))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        }.getOrNull()
        if (track == null) { rec.release(); return null }

        try {
            rec.startRecording()
            val inBuf = ShortArray(1024)
            // 1) ضجيج المحيط
            val ambN = (SR * 1.5f).toInt()
            val amb = FloatArray(ambN)
            var got = 0
            while (got < ambN) {
                val n = rec.read(inBuf, 0, 1024)
                if (n <= 0) return null
                for (i in 0 until n) if (got < ambN) amb[got++] = inBuf[i] / 32768f
            }
            // 2) ضجيج وردي عبر المكبر مع التسجيل
            val total = seconds * SR
            val sig = FloatArray(total)
            got = 0
            val pink = Pink()
            val outBuf = ShortArray(2048)
            track.play()
            while (got < total) {
                for (i in 0 until 1024) {
                    val v = (pink.next() * 0.6f * 32767f).toInt().coerceIn(-32767, 32767).toShort()
                    outBuf[2 * i] = v; outBuf[2 * i + 1] = v
                }
                track.write(outBuf, 0, 2048)
                val n = rec.read(inBuf, 0, 1024)
                if (n <= 0) return null
                for (i in 0 until n) if (got < total) sig[got++] = inBuf[i] / 32768f
                onProgress(got.toFloat() / total)
            }
            track.stop(); rec.stop()
            return analyze(sig, amb)
        } finally {
            runCatching { track.release() }
            runCatching { rec.release() }
        }
    }

    private fun avgPower(x: FloatArray, from: Int): FloatArray {
        val n = 4096
        val fft = Fft(n)
        val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / n)).toFloat() }
        val acc = FloatArray(n / 2 + 1)
        val re = FloatArray(n)
        val im = FloatArray(n)
        var c = 0
        var st = from
        while (st + n <= x.size) {
            for (i in 0 until n) { re[i] = x[st + i] * win[i]; im[i] = 0f }
            fft.transform(re, im, false)
            for (k in 0..n / 2) acc[k] += re[k] * re[k] + im[k] * im[k]
            c++
            st += n / 2
        }
        if (c > 0) for (k in acc.indices) acc[k] /= c
        return acc
    }

    private fun analyze(sig: FloatArray, amb: FloatArray): Result? {
        val skip = (SR * 0.7f).toInt()
        if (sig.size - skip < 8192) return null
        val ps = avgPower(sig, skip)
        val pn = avgPower(amb, 0)
        val n = 4096
        val db = FloatArray(CENTERS.size)
        for ((idx, fc) in CENTERS.withIndex()) {
            val i0 = max(1, (fc / 1.41421356f * n / SR).toInt())
            val i1 = max(i0 + 1, (fc * 1.41421356f * n / SR).toInt())
            var s = 0f; var nn = 0f
            for (k in i0 until i1) { s += ps[k]; nn += pn[k] }
            val p = max(s - nn, s * 0.05f)
            db[idx] = 10f * log10(p + 1e-12f)
        }
        val ref = (db[3] + db[4] + db[5] + db[6]) / 4f
        val rel = FloatArray(db.size) { db[it] - ref }
        val corr = FloatArray(db.size) { i ->
            val fc = CENTERS[i]
            val lo = if (fc < 100) -6f else -6f
            val hi = if (fc < 100) 3f else if (fc < 200) 4f else 6f
            (-rel[i] * 0.8f).coerceIn(lo, hi)
        }
        var ss = 0.0
        for (v in sig) ss += v * v
        var an = 0.0
        for (v in amb) an += v * v
        val sp = ss / sig.size
        val ap = max(an / amb.size, 1e-12)
        val snr = (10.0 * log10(sp / ap)).toFloat()
        val level = (10.0 * log10(sqrt(sp) * sqrt(sp) + 1e-12)).toFloat()
        return Result(rel, corr, snr, level)
    }
}
