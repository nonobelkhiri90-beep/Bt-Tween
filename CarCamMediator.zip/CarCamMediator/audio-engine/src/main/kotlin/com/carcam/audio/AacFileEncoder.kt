package com.carcam.audio

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import kotlin.math.min

/** يكتب PCM ستيريو 16-bit إلى ملف AAC داخل حاوية m4a */
class AacFileEncoder(file: File) {
    private val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    private val muxer = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var started = false
    private var frames = 0L
    private var bytes = ByteArray(0)

    init {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    fun write(pcm: ShortArray, frameCount: Int) {
        val total = frameCount * 4
        if (bytes.size < total) bytes = ByteArray(total)
        for (i in 0 until frameCount * 2) {
            val s = pcm[i].toInt()
            bytes[2 * i] = (s and 0xFF).toByte(); bytes[2 * i + 1] = (s shr 8).toByte()
        }
        var off = 0
        while (off < total) {
            val idx = codec.dequeueInputBuffer(10_000)
            if (idx < 0) { drain(false); continue }
            val ib = codec.getInputBuffer(idx)!!
            ib.clear()
            var n = min(ib.capacity(), total - off); n -= n % 4
            ib.put(bytes, off, n)
            codec.queueInputBuffer(idx, 0, n, frames * 1_000_000L / SR, 0)
            frames += n / 4; off += n
            drain(false)
        }
    }

    fun finish() {
        val idx = codec.dequeueInputBuffer(100_000)
        if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, frames * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drain(true)
        runCatching { codec.stop() }; runCatching { codec.release() }
        runCatching { if (started) muxer.stop() }; runCatching { muxer.release() }
    }

    private fun drain(eos: Boolean) {
        var spins = 0
        while (true) {
            val o = codec.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
            when {
                o == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!eos || ++spins > 300) return }
                o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    track = muxer.addTrack(codec.outputFormat); muxer.start(); started = true
                }
                o >= 0 -> {
                    val b = codec.getOutputBuffer(o)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) {
                        b.position(info.offset); b.limit(info.offset + info.size)
                        muxer.writeSampleData(track, b, info)
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }
}
