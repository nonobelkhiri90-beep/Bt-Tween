package com.carcam.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/** يقيس مستوى الميكروفون (dBFS) لبضع ثوانٍ، لاختبار وصول الموسيقى إلى ميكروفون البث */
object MicProbe {
    /** source: MediaRecorder.AudioSource.*. يعيد null إن تعذّر فتح الميكروفون */
    @SuppressLint("MissingPermission")
    fun measureDb(source: Int, ms: Int = 2000): Float? {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = runCatching {
            AudioRecord(source, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 8192))
        }.getOrNull() ?: return null
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        try {
            rec.startRecording()
            val buf = ShortArray(2048)
            var sum = 0.0
            var n = 0L
            val end = System.currentTimeMillis() + ms
            // نتجاهل أول 300ms (استقرار المعالجات)
            val warm = System.currentTimeMillis() + 300
            while (System.currentTimeMillis() < end) {
                val r = rec.read(buf, 0, buf.size)
                if (r <= 0) break
                if (System.currentTimeMillis() < warm) continue
                for (i in 0 until r) { val v = buf[i] / 32768.0; sum += v * v }
                n += r
            }
            rec.stop()
            if (n == 0L) return null
            return (20.0 * log10(max(sqrt(sum / n), 1e-9))).toFloat()
        } finally {
            rec.release()
        }
    }
}
