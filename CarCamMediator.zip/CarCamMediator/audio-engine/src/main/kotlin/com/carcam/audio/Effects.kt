package com.carcam.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

const val SR = 44100

/** كل المؤثرات تعمل على مصفوفة Float متداخلة ستيريو [L,R,L,R...] */
interface Effect { fun process(buf: FloatArray, frames: Int) }

class EffectChain(private val effects: List<Effect>) : Effect {
    constructor(vararg e: Effect) : this(e.toList())
    override fun process(buf: FloatArray, frames: Int) { for (e in effects) e.process(buf, frames) }
}

private fun dbToLin(db: Float) = exp(db * 0.11512925f)
private fun linToDb(x: Float) = 8.685889f * ln(max(x, 1e-6f))

/** فلتر Biquad (وصفات RBJ) */
class BiquadFilter private constructor(
    private val b0: Double, private val b1: Double, private val b2: Double,
    private val a1: Double, private val a2: Double,
) : Effect {
    private var z1L = 0.0; private var z2L = 0.0
    private var z1R = 0.0; private var z2R = 0.0

    override fun process(buf: FloatArray, frames: Int) {
        for (i in 0 until frames) {
            val xl = buf[2 * i].toDouble()
            val yl = b0 * xl + z1L
            z1L = b1 * xl - a1 * yl + z2L; z2L = b2 * xl - a2 * yl
            buf[2 * i] = yl.toFloat()
            val xr = buf[2 * i + 1].toDouble()
            val yr = b0 * xr + z1R
            z1R = b1 * xr - a1 * yr + z2R; z2R = b2 * xr - a2 * yr
            buf[2 * i + 1] = yr.toFloat()
        }
    }

    companion object {
        private fun make(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) =
            BiquadFilter(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)

        fun highPass(freq: Float, q: Float = 0.707f): BiquadFilter {
            val w = 2 * PI * freq / SR; val c = cos(w); val al = sin(w) / (2 * q)
            return make((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
        }

        fun peaking(freq: Float, gainDb: Float, q: Float = 0.9f): BiquadFilter {
            val a = Math.pow(10.0, gainDb / 40.0)
            val w = 2 * PI * freq / SR; val c = cos(w); val al = sin(w) / (2 * q)
            return make(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
        }

        fun lowShelf(freq: Float, gainDb: Float): BiquadFilter {
            val a = Math.pow(10.0, gainDb / 40.0)
            val w = 2 * PI * freq / SR; val c = cos(w); val s = sin(w)
            val al = s / 2 * sqrt(2.0); val t = 2 * sqrt(a) * al
            return make(
                a * ((a + 1) - (a - 1) * c + t), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - t),
                (a + 1) + (a - 1) * c + t, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - t
            )
        }

        fun highShelf(freq: Float, gainDb: Float): BiquadFilter {
            val a = Math.pow(10.0, gainDb / 40.0)
            val w = 2 * PI * freq / SR; val c = cos(w); val s = sin(w)
            val al = s / 2 * sqrt(2.0); val t = 2 * sqrt(a) * al
            return make(
                a * ((a + 1) + (a - 1) * c + t), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - t),
                (a + 1) - (a - 1) * c + t, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - t
            )
        }
    }
}

/** معادل ثلاثي: باص / وسط / حدة */
fun equalizer3(lowDb: Float, midDb: Float, highDb: Float): Effect = EffectChain(
    BiquadFilter.lowShelf(100f, lowDb), BiquadFilter.peaking(1000f, midDb), BiquadFilter.highShelf(8000f, highDb)
)

/** ضاغط ديناميكي (ويُستعمل كمحدِّد عند نسبة عالية) */
class Compressor(
    private val thresholdDb: Float, private val ratio: Float,
    attackMs: Float, releaseMs: Float, private val makeupDb: Float = 0f,
) : Effect {
    private val aC = exp(-1f / (attackMs * 0.001f * SR))
    private val rC = exp(-1f / (releaseMs * 0.001f * SR))
    private var env = 0f

    override fun process(buf: FloatArray, frames: Int) {
        for (i in 0 until frames) {
            val l = buf[2 * i]; val r = buf[2 * i + 1]
            val peak = max(abs(l), abs(r))
            val c = if (peak > env) aC else rC
            env = c * env + (1 - c) * peak
            val over = linToDb(env) - thresholdDb
            val gDb = (if (over > 0) -over * (1 - 1 / ratio) else 0f) + makeupDb
            val g = dbToLin(gDb)
            buf[2 * i] = l * g; buf[2 * i + 1] = r * g
        }
    }
}

/** بوابة ضجيج: تكتم الصوت عندما يكون أضعف من العتبة */
class NoiseGate(thresholdDb: Float, attackMs: Float = 3f, releaseMs: Float = 150f) : Effect {
    private val thr = dbToLin(thresholdDb)
    private val aC = 1 - exp(-1f / (attackMs * 0.001f * SR))
    private val rC = 1 - exp(-1f / (releaseMs * 0.001f * SR))
    private var env = 0f
    private var gain = 0f

    override fun process(buf: FloatArray, frames: Int) {
        for (i in 0 until frames) {
            val peak = max(abs(buf[2 * i]), abs(buf[2 * i + 1]))
            env = if (peak > env) peak else env * 0.9995f
            val target = if (env > thr) 1f else 0f
            gain += (target - gain) * (if (target > gain) aC else rC)
            buf[2 * i] *= gain; buf[2 * i + 1] *= gain
        }
    }
}

/** صدى (Echo / Delay) */
class Echo(delayMs: Float, private val feedback: Float, private val mix: Float) : Effect {
    private val n = max(1, (delayMs * 0.001f * SR).toInt())
    private val bl = FloatArray(n); private val br = FloatArray(n)
    private var idx = 0

    override fun process(buf: FloatArray, frames: Int) {
        for (i in 0 until frames) {
            val l = buf[2 * i]; val r = buf[2 * i + 1]
            val dl = bl[idx]; val dr = br[idx]
            bl[idx] = l + dl * feedback; br[idx] = r + dr * feedback
            buf[2 * i] = l + dl * mix; buf[2 * i + 1] = r + dr * mix
            if (++idx >= n) idx = 0
        }
    }
}

/** ريفيرب على طريقة Freeverb: 8 فلاتر Comb + 4 Allpass لكل قناة */
class Reverb(room: Float = 0.7f, damp: Float = 0.5f, private val wet: Float = 0.25f, private val dry: Float = 1f) : Effect {
    private class Comb(size: Int, val feedback: Float, val d1: Float) {
        private val b = FloatArray(size); private var i = 0; private var store = 0f
        fun tick(x: Float): Float {
            val o = b[i]
            store = o * (1 - d1) + store * d1
            b[i] = x + store * feedback
            if (++i >= b.size) i = 0
            return o
        }
    }
    private class Allpass(size: Int) {
        private val b = FloatArray(size); private var i = 0
        fun tick(x: Float): Float {
            val o = b[i]
            b[i] = x + o * 0.5f
            if (++i >= b.size) i = 0
            return o - x
        }
    }

    private val combT = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val apT = intArrayOf(556, 441, 341, 225)
    private val fb = room * 0.28f + 0.7f
    private val d1 = damp * 0.4f
    private val combL = combT.map { Comb(it, fb, d1) }
    private val combR = combT.map { Comb(it + 23, fb, d1) }
    private val apL = apT.map { Allpass(it) }
    private val apR = apT.map { Allpass(it + 23) }

    override fun process(buf: FloatArray, frames: Int) {
        for (i in 0 until frames) {
            val l = buf[2 * i]; val r = buf[2 * i + 1]
            val inp = (l + r) * 0.015f
            var oL = 0f; var oR = 0f
            for (c in combL) oL += c.tick(inp)
            for (c in combR) oR += c.tick(inp)
            for (a in apL) oL = a.tick(oL)
            for (a in apR) oR = a.tick(oR)
            buf[2 * i] = l * dry + oL * wet * 3f
            buf[2 * i + 1] = r * dry + oR * wet * 3f
        }
    }
}
