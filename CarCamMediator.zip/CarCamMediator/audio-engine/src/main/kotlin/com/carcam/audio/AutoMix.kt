package com.carcam.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** معادلات RBJ لمرشحات Biquad */
internal object Rbj {
    fun lowShelf(f: Double, gDb: Double): DoubleArray {
        val a = 10.0.pow(gDb / 40.0); val w = 2.0 * PI * f / SR; val c = cos(w); val s = sin(w)
        val al = s / 2.0 * sqrt(2.0); val t = 2.0 * sqrt(a) * al
        return doubleArrayOf(
            a * ((a + 1) - (a - 1) * c + t), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - t),
            (a + 1) + (a - 1) * c + t, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - t
        )
    }

    fun highShelf(f: Double, gDb: Double): DoubleArray {
        val a = 10.0.pow(gDb / 40.0); val w = 2.0 * PI * f / SR; val c = cos(w); val s = sin(w)
        val al = s / 2.0 * sqrt(2.0); val t = 2.0 * sqrt(a) * al
        return doubleArrayOf(
            a * ((a + 1) + (a - 1) * c + t), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - t),
            (a + 1) - (a - 1) * c + t, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - t
        )
    }

    fun peaking(f: Double, gDb: Double, q: Double): DoubleArray {
        val a = 10.0.pow(gDb / 40.0); val w = 2.0 * PI * f / SR; val c = cos(w); val al = sin(w) / (2.0 * q)
        return doubleArrayOf(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
    }
}

/** معادل متكيّف: باص (رف 120Hz) + حضور (3.5kHz) + حدة (رف 9kHz) تتغير معاملاتها أثناء التشغيل */
internal class AdaptiveEq : Effect {
    private class Stage {
        var b0 = 1.0; var b1 = 0.0; var b2 = 0.0; var a1 = 0.0; var a2 = 0.0
        var z1l = 0.0; var z2l = 0.0; var z1r = 0.0; var z2r = 0.0
        fun set(c: DoubleArray) {
            val a0 = c[3]
            b0 = c[0] / a0; b1 = c[1] / a0; b2 = c[2] / a0; a1 = c[4] / a0; a2 = c[5] / a0
        }
        fun process(buf: FloatArray, frames: Int) {
            for (i in 0 until frames) {
                val xl = buf[2 * i].toDouble()
                val yl = b0 * xl + z1l
                z1l = b1 * xl - a1 * yl + z2l; z2l = b2 * xl - a2 * yl
                buf[2 * i] = yl.toFloat()
                val xr = buf[2 * i + 1].toDouble()
                val yr = b0 * xr + z1r
                z1r = b1 * xr - a1 * yr + z2r; z2r = b2 * xr - a2 * yr
                buf[2 * i + 1] = yr.toFloat()
            }
        }
    }

    private val lo = Stage()
    private val pr = Stage()
    private val hi = Stage()

    fun setGains(lowDb: Float, presDb: Float, highDb: Float) {
        lo.set(Rbj.lowShelf(120.0, lowDb.toDouble()))
        pr.set(Rbj.peaking(3500.0, presDb.toDouble(), 0.8))
        hi.set(Rbj.highShelf(9000.0, highDb.toDouble()))
    }

    override fun process(buf: FloatArray, frames: Int) {
        lo.process(buf, frames); pr.process(buf, frames); hi.process(buf, frames)
    }
}

/**
 * الصوت التلقائي: «يسمع» الميكروفون والموسيقى ويضبط في الزمن الحقيقي:
 *  - AGC للميكروفون (مستوى الكلام ≈ -20 dBFS، دون تضخيم الضجيج في فترات الصمت).
 *  - خفض الموسيقى تلقائياً أثناء الكلام (Ducking) وإعادتها بعده.
 *  - توازن طيفي للموسيقى (باص/حضور/حدة) نحو منحنى متوازن، بحدود ±6 dB وبتغيّر بطيء.
 *  - ضبط الجهارة الكلية وتفادي التشبّع.
 * (اختُبرت منطقياً رقمياً: يصحّح باص +9dB بنحو -5.7dB، ويرفع باصاً ناقصاً بنحو +3.9dB)
 */
class AutoMix {
    @Volatile var micDb = -90f; private set
    @Volatile var musicDb = -90f; private set
    @Volatile var micGainDb = 0f; private set
    @Volatile var duckDb = 0f; private set
    @Volatile var bassDb = 0f; private set
    @Volatile var presenceDb = 0f; private set
    @Volatile var trebleDb = 0f; private set
    @Volatile var masterDb = 0f; private set
    @Volatile var voiceActive = false; private set

    private val eq = AdaptiveEq()
    private val fft = Fft(NF)
    private val hist = FloatArray(NF)
    private val hann = FloatArray(NF) { (0.5 - 0.5 * cos(2.0 * PI * it / NF)).toFloat() }
    private val re = FloatArray(NF)
    private val im = FloatArray(NF)
    private val lvl = FloatArray(5)
    private val ema = FloatArray(5)
    private var emaInit = false
    private var anaCount = 0

    private var nf = 0.003f
    private var vr = 0f
    private var firstVoice = true
    private var gMic = 1f
    private var gMicPrev = 1f
    private var duck = 1f
    private var duckPrev = 1f
    private var loud = 0f
    private var gM = 1f
    private var gMPrev = 1f
    private var gl = 0f
    private var gp = 0f
    private var gh = 0f

    private fun db(x: Float) = 20f * log10(max(x, 1e-6f))

    private fun rmsL(buf: FloatArray, frames: Int): Float {
        var s = 0f
        for (i in 0 until frames) s += buf[2 * i] * buf[2 * i]
        return sqrt(s / frames)
    }

    private fun ramp(buf: FloatArray, frames: Int, from: Float, to: Float) {
        val step = (to - from) / frames
        var g = from
        for (i in 0 until frames) { g += step; buf[2 * i] *= g; buf[2 * i + 1] *= g }
    }

    /** يُستدعى بعد سلاسل المؤثرات وقبل المزج */
    fun processInputs(mic: FloatArray, music: FloatArray, frames: Int) {
        val micRms = rmsL(mic, frames)
        val musicRms = rmsL(music, frames)

        // أرضية الضجيج وكشف الكلام
        nf = if (micRms < nf) nf * 0.9f + micRms * 0.1f else nf * 1.0008f + 1e-7f
        nf = nf.coerceIn(1e-4f, 0.05f)
        val voice = micRms > max(nf * 3.2f, 0.006f)
        voiceActive = voice

        // AGC للميكروفون
        if (voice) {
            vr = if (firstVoice) micRms else vr + 0.08f * (micRms - vr)
            firstVoice = false
            val tg = (TARGET_VOICE / vr).coerceIn(0.6f, 5f)
            gMic += (tg - gMic) * 0.02f
        }
        ramp(mic, frames, gMicPrev, gMic)
        gMicPrev = gMic

        // خفض الموسيقى أثناء الكلام
        val dt = if (voice) 0.5f else 1f
        duck += (dt - duck) * (if (dt < duck) 0.25f else 0.04f)

        // توازن طيفي للموسيقى (التحليل على الإشارة الخام قبل المعادل)
        val n = min(frames, NF)
        System.arraycopy(hist, n, hist, 0, NF - n)
        for (i in 0 until n) hist[NF - n + i] = music[2 * i]
        anaCount++
        if (anaCount >= 8 && musicRms > 0.003f) { anaCount = 0; analyze() }
        eq.process(music, frames)

        ramp(music, frames, duckPrev, duck)
        duckPrev = duck

        micDb = db(micRms * gMicPrev)
        musicDb = db(musicRms * duckPrev)
        micGainDb = db(gMicPrev)
        duckDb = db(duckPrev)
        bassDb = gl; presenceDb = gp; trebleDb = gh
    }

    private fun analyze() {
        for (i in 0 until NF) { re[i] = hist[i] * hann[i]; im[i] = 0f }
        fft.transform(re, im, false)
        for (b in 0 until 5) {
            var sum = 0f
            for (k in LO[b] until HI[b]) sum += re[k] * re[k] + im[k] * im[k]
            lvl[b] = 10f * log10(sum / OCT[b] + 1e-12f)
        }
        if (!emaInit) { for (b in 0 until 5) ema[b] = lvl[b]; emaInit = true }
        else for (b in 0 until 5) ema[b] += 0.1f * (lvl[b] - ema[b])

        val d0 = (ema[0] - ema[2]) - TGT[0]
        val d3 = (ema[3] - ema[2]) - TGT[3]
        val d4 = (ema[4] - ema[2]) - TGT[4]
        val tl = (-0.6f * d0).coerceIn(-6f, 6f)
        val tp = (-0.5f * d3).coerceIn(-4f, 4f)
        val th = (-0.5f * d4).coerceIn(-5f, 5f)
        gl += (tl - gl).coerceIn(-0.15f, 0.15f)
        gp += (tp - gp).coerceIn(-0.15f, 0.15f)
        gh += (th - gh).coerceIn(-0.15f, 0.15f)
        eq.setGains(gl, gp, gh)
    }

    /** يُستدعى على المزيج النهائي قبل المحدِّد */
    fun processMix(mix: FloatArray, frames: Int) {
        var s = 0f
        for (i in 0 until frames * 2) s += mix[i] * mix[i]
        val p = s / (frames * 2)
        loud += 0.02f * (p - loud)
        val r = sqrt(loud)
        if (r > 0.004f) {
            val tg = (TARGET_MIX / r).coerceIn(0.5f, 1.6f)
            gM += (tg - gM) * 0.01f
        }
        ramp(mix, frames, gMPrev, gM)
        gMPrev = gM
        masterDb = db(gM)
    }

    private companion object {
        const val NF = 2048
        const val TARGET_VOICE = 0.1f
        const val TARGET_MIX = 0.126f
        val LO = intArrayOf(1, 6, 23, 92, 278)
        val HI = intArrayOf(6, 23, 92, 278, 650)
        val OCT = floatArrayOf(1.9069f, 1.7370f, 2.0f, 1.5850f, 1.2224f)
        val TGT = floatArrayOf(3f, 2f, 0f, -4f, -9f)
    }
}
