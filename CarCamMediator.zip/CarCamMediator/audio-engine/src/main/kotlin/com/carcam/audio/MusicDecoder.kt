package com.carcam.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

/** يفك ترميز أي ملف صوتي إلى PCM ستيريو 44.1kHz عائم، بدءاً من نقطة محددة */
class MusicDecoder(ctx: Context, uri: Uri, startMs: Long = 0) {
    private val extractor = MediaExtractor()
    private val codec: MediaCodec
    private val info = MediaCodec.BufferInfo()
    private var srcRate = SR
    private var srcCh = 2
    private var pcmFloat = false
    private var inputDone = false
    private var outputDone = false

    private var pend = FloatArray(SR * 2)
    private var pendLen = 0
    private var phase = 0.0
    private var prevL = 0f
    private var prevR = 0f
    private var havePrev = false

    init {
        extractor.setDataSource(ctx, uri, null)
        var idx = -1
        for (i in 0 until extractor.trackCount) {
            if (extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; break }
        }
        require(idx >= 0) { "no audio track" }
        extractor.selectTrack(idx)
        val fmt = extractor.getTrackFormat(idx)
        srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        srcCh = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        if (startMs > 0) extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()
    }

    /** يملأ out بـ frames إطار ستيريو متداخل، ويعيد عدد الإطارات الفعلية (أقل عند نهاية الأغنية) */
    fun read(out: FloatArray, frames: Int): Int {
        val need = frames * 2
        var guard = 0
        while (pendLen < need && !outputDone && guard++ < 400) pump()
        val n = min(need, pendLen)
        System.arraycopy(pend, 0, out, 0, n)
        System.arraycopy(pend, n, pend, 0, pendLen - n)
        pendLen -= n
        return n / 2
    }

    val finished get() = outputDone && pendLen == 0

    private fun pump() {
        if (!inputDone) {
            val i = codec.dequeueInputBuffer(0)
            if (i >= 0) {
                val b = codec.getInputBuffer(i)!!
                val n = extractor.readSampleData(b, 0)
                if (n < 0) {
                    codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    inputDone = true
                } else {
                    codec.queueInputBuffer(i, 0, n, extractor.sampleTime, 0)
                    extractor.advance()
                }
            }
        }
        val o = codec.dequeueOutputBuffer(info, 5000)
        when {
            o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                val f = codec.outputFormat
                srcRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                srcCh = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                pcmFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                    f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
            }
            o >= 0 -> {
                val b = codec.getOutputBuffer(o)!!
                if (info.size > 0) convert(b)
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
            }
        }
    }

    private fun convert(b: ByteBuffer) {
        b.position(info.offset); b.limit(info.offset + info.size)
        b.order(ByteOrder.nativeOrder())
        if (pcmFloat) {
            val fb = b.asFloatBuffer(); val frames = info.size / (4 * srcCh)
            for (f in 0 until frames) {
                val l = fb.get(f * srcCh); val r = if (srcCh > 1) fb.get(f * srcCh + 1) else l
                push(l, r)
            }
        } else {
            val sb = b.asShortBuffer(); val frames = info.size / (2 * srcCh)
            for (f in 0 until frames) {
                val l = sb.get(f * srcCh) / 32768f
                val r = if (srcCh > 1) sb.get(f * srcCh + 1) / 32768f else l
                push(l, r)
            }
        }
    }

    /** إعادة أخذ عينات خطية إلى 44.1kHz */
    private fun push(l: Float, r: Float) {
        if (srcRate == SR) { append(l, r); return }
        if (!havePrev) { prevL = l; prevR = r; havePrev = true }
        val ratio = srcRate.toDouble() / SR
        while (phase < 1.0) {
            val p = phase.toFloat()
            append(prevL + (l - prevL) * p, prevR + (r - prevR) * p)
            phase += ratio
        }
        phase -= 1.0
        prevL = l; prevR = r
    }

    private fun append(l: Float, r: Float) {
        if (pendLen + 2 > pend.size) pend = pend.copyOf(pend.size * 2)
        pend[pendLen++] = l; pend[pendLen++] = r
    }

    fun release() {
        runCatching { codec.stop() }; runCatching { codec.release() }; runCatching { extractor.release() }
    }
}
