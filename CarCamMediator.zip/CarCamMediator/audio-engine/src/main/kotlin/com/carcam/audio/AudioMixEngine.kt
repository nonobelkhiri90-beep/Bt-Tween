package com.carcam.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.SystemClock
import java.io.File
import kotlin.math.max

class EngineConfig(
    val musicUri: Uri? = null,
    val musicStartMs: Long = 0,
    val preset: Preset = Preset.CLEAN,
    val micEnabled: Boolean = true,
    /** تشغيل الموسيقى المعالَجة عبر مكبرات الهاتف/السيارة أثناء التسجيل */
    val monitorMusic: Boolean = true,
    /** سماع صوتك بالمؤثرات (يحتاج سماعة سلكية وإلا يحدث صفير) */
    val monitorVoice: Boolean = false,
)

/**
 * المحرك: ميكروفون + موسيقى مفكوكة ← سلسلة مؤثرات لكل منهما ← Mixer ← Limiter ← AAC.
 * ينتج ملف m4a يُدمج مع الفيديو لاحقاً بواسطة AvMerger.
 */
class AudioMixEngine(private val ctx: Context, private val cfg: EngineConfig, private val outFile: File) {

    @Volatile var micGain = 1f
    @Volatile var musicGain = 0.8f
    /** لحظة (elapsedRealtime) التي يقابلها الإطار الأول من الصوت، لمزامنة الفيديو */
    @Volatile var startElapsedNs = 0L; private set
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start(onReady: () -> Unit) {
        if (running) return
        running = true
        thread = Thread({ runLoop(onReady) }, "AudioMixEngine").apply { priority = Thread.MAX_PRIORITY; start() }
    }

    fun signalStop() { running = false }

    fun stop(): File { running = false; thread?.join(); thread = null; return outFile }

    @SuppressLint("MissingPermission")
    private fun runLoop(onReady: () -> Unit) {
        val setup = cfg.preset.create()
        micGain = setup.micGain; musicGain = setup.musicGain
        val master = Compressor(-1f, 20f, 0.5f, 80f, 0f)

        val decoder = cfg.musicUri?.let { runCatching { MusicDecoder(ctx, it, cfg.musicStartMs) }.getOrNull() }
        var aec: AcousticEchoCanceler? = null
        var ns: NoiseSuppressor? = null
        val rec: AudioRecord? = if (cfg.micEnabled) runCatching {
            val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            // عند تشغيل الموسيقى من المكبرات نستعمل مصدراً يفعّل إلغاء الصدى
            val src = if (cfg.monitorMusic) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
            AudioRecord(src, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, BLOCK * 8))
                .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
                ?.also {
                    if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(it.audioSessionId)?.also { e -> e.enabled = true }
                    if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(it.audioSessionId)?.also { e -> e.enabled = true }
                }
        }.getOrNull() else null

        val track: AudioTrack? = if (cfg.monitorMusic || cfg.monitorVoice) runCatching {
            val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
                )
                .setBufferSizeInBytes(max(minBuf, BLOCK * 16))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        }.getOrNull() else null

        val enc = AacFileEncoder(outFile)
        val micShort = ShortArray(BLOCK)
        val mic = FloatArray(BLOCK * 2); val music = FloatArray(BLOCK * 2); val mix = FloatArray(BLOCK * 2)
        val outS = ShortArray(BLOCK * 2); val monS = ShortArray(BLOCK * 2)
        val blockNs = BLOCK * 1_000_000_000L / SR
        var framesDone = 0L
        var first = true
        val t0 = System.nanoTime()

        try {
            rec?.startRecording(); track?.play()
            while (running) {
                java.util.Arrays.fill(mic, 0f)
                if (rec != null) {
                    var n = 0
                    while (n < BLOCK && running) {
                        val r = rec.read(micShort, n, BLOCK - n)
                        if (r <= 0) break
                        n += r
                    }
                    for (i in 0 until n) { val s = micShort[i] / 32768f; mic[2 * i] = s; mic[2 * i + 1] = s }
                }
                java.util.Arrays.fill(music, 0f)
                decoder?.read(music, BLOCK)

                setup.micChain.process(mic, BLOCK)
                setup.musicChain.process(music, BLOCK)

                val mg = micGain; val ug = musicGain
                for (i in 0 until BLOCK * 2) mix[i] = mic[i] * mg + music[i] * ug
                master.process(mix, BLOCK)
                for (i in 0 until BLOCK * 2) outS[i] = (mix[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                enc.write(outS, BLOCK)

                if (track != null) {
                    for (i in 0 until BLOCK * 2) {
                        var v = 0f
                        if (cfg.monitorMusic) v += music[i] * ug
                        if (cfg.monitorVoice) v += mic[i] * mg
                        monS[i] = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                    }
                    track.write(monS, 0, BLOCK * 2)
                }

                framesDone += BLOCK
                if (first) { first = false; startElapsedNs = SystemClock.elapsedRealtimeNanos() - blockNs; onReady() }
                if (rec == null) {
                    val wait = (t0 + framesDone * 1_000_000_000L / SR - System.nanoTime()) / 1_000_000
                    if (wait > 0) Thread.sleep(wait)
                }
            }
        } finally {
            runCatching { rec?.stop() }; runCatching { rec?.release() }
            runCatching { aec?.release() }; runCatching { ns?.release() }
            runCatching { track?.stop() }; runCatching { track?.release() }
            decoder?.release()
            enc.finish()
        }
    }

    companion object { private const val BLOCK = 1024 }
}
