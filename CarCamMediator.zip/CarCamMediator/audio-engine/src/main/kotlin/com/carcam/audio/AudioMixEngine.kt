package com.carcam.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.SystemClock
import java.io.File
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.max

class EngineConfig(
    val musicUri: Uri? = null,
    val musicStartMs: Long = 0,
    val preset: Preset = Preset.CLEAN,
    val micEnabled: Boolean = true,
    /** تشغيل الموسيقى المعالَجة عبر مكبرات الهاتف/السيارة أثناء التسجيل */
    val monitorMusic: Boolean = true,
    /** سماع صوتك بالمؤثرات (يحتاج سماعة سلكية وإلا يحدث صفير) */
    val monitorVoice: Boolean = false,
    /** خيارات Autotune (المقام والسلّم) وتنقية الضوضاء */
    val voice: VoiceOptions = VoiceOptions(),
    /** معاملات ضرب لمستوى الصوت والموسيقى (من الإعدادات) */
    val micGainScale: Float = 1f,
    val musicGainScale: Float = 1f,
    /** الصوت التلقائي: AGC + خفض الموسيقى أثناء الكلام + توازن طيفي + جهارة */
    val autoMix: Boolean = false,
    /** تصحيح معايرة المقصورة (8 نطاقات dB) يُطبَّق على صوت المكبر فقط */
    val monitorEq: FloatArray? = null,
)

/**
 * المحرك: ميكروفون + موسيقى مفكوكة ← سلسلة مؤثرات لكل منهما ← (صوت تلقائي) ← Mixer ← Limiter ← AAC.
 * الموسيقى يمكن إضافتها أو إيقافها أثناء التسجيل بـ setMusic.
 * ينتج ملف m4a يُدمج مع الفيديو لاحقاً بواسطة AvMerger.
 */
class AudioMixEngine(private val ctx: Context, private val cfg: EngineConfig, private val outFile: File) {

    @Volatile var micGain = 1f
    /** اسم المقام المكتشف تلقائياً (للعرض) */
    @Volatile var detectedKeyName: String? = null; private set
    /** true إن تعذّر فك ترميز ملف الموسيقى (يُسجَّل الميكروفون فقط) */
    @Volatile var musicFailed = false; private set
    @Volatile var musicGain = 0.8f
    /** true أثناء وجود موسيقى تعمل داخل المحرك */
    @Volatile var hasMusic = false; private set
    /** إحصاءات الصوت التلقائي (null إن كان متوقفاً) */
    @Volatile var autoStats: AutoMix? = null; private set
    /** لحظة (elapsedRealtime) التي يقابلها الإطار الأول من الصوت، لمزامنة الفيديو */
    @Volatile var startElapsedNs = 0L; private set
    @Volatile private var running = false
    private var thread: Thread? = null

    private val pendingDecoder = AtomicReference<MusicDecoder?>(null)
    @Volatile private var pendingClear = false
    @Volatile private var autoTuneRef: AutoTune? = null

    fun start(onReady: () -> Unit, onError: (String) -> Unit = {}) {
        if (running) return
        running = true
        thread = Thread({
            try { runLoop(onReady) } catch (t: Throwable) { running = false; onError(t.message ?: t.javaClass.simpleName) }
        }, "AudioMixEngine").apply { priority = Thread.MAX_PRIORITY; start() }
    }

    fun signalStop() { running = false }

    fun stop(): File { running = false; thread?.join(); thread = null; return outFile }

    /**
     * يضيف موسيقى (أو يستبدلها) أثناء التسجيل دون قطع الصوت؛ uri=null يوقفها.
     * فك الترميز يتم في خيط جانبي كي لا يتأثر التقاط الميكروفون.
     */
    fun setMusic(uri: Uri?, startMs: Long = 0) {
        if (uri == null) { pendingClear = true; return }
        Thread {
            val d = runCatching { MusicDecoder(ctx, uri, startMs) }.getOrNull()
            if (d == null) { musicFailed = true; return@Thread }
            musicFailed = false
            pendingDecoder.getAndSet(d)?.release()
            val at = autoTuneRef
            if (at != null && cfg.preset.usesKey && cfg.voice.key < 0) {
                val k = runCatching { KeyDetector.detect(ctx, uri, startMs) }.getOrNull()
                if (k != null) {
                    val sc = if (cfg.voice.scale == Scale.MAJOR || cfg.voice.scale == Scale.MINOR)
                        (if (k.minor) Scale.MINOR else Scale.MAJOR) else cfg.voice.scale
                    at.setKey(k.tonic, sc)
                    detectedKeyName = NOTE_NAMES[k.tonic] + (if (k.minor) " minor" else " major")
                }
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    private fun runLoop(onReady: () -> Unit) {
        val master = Compressor(-1f, 20f, 0.5f, 80f, 0f)

        var decoder: MusicDecoder? = cfg.musicUri?.let { runCatching { MusicDecoder(ctx, it, cfg.musicStartMs) }.getOrNull() }
        musicFailed = cfg.musicUri != null && decoder == null

        // Autotune: اكتشاف مقام الأغنية تلقائياً قبل البدء (الفيديو ينتظر جاهزية المحرك فتبقى المزامنة سليمة)
        var voice = cfg.voice
        val mUri = cfg.musicUri
        if (cfg.preset.usesKey && voice.key < 0 && mUri != null) {
            val k = runCatching { KeyDetector.detect(ctx, mUri, cfg.musicStartMs) }.getOrNull()
            if (k != null) {
                val sc = if (voice.scale == Scale.MAJOR || voice.scale == Scale.MINOR)
                    (if (k.minor) Scale.MINOR else Scale.MAJOR) else voice.scale
                voice = VoiceOptions(k.tonic, sc, voice.denoise)
                detectedKeyName = NOTE_NAMES[k.tonic] + (if (k.minor) " minor" else " major")
            }
        }
        val setup = cfg.preset.create(voice)
        autoTuneRef = setup.autoTune
        micGain = setup.micGain * cfg.micGainScale
        musicGain = setup.musicGain * cfg.musicGainScale

        val auto: AutoMix? = if (cfg.autoMix) AutoMix() else null
        autoStats = auto
        val monEq: Effect? = cfg.monitorEq?.let { g ->
            val idx = RoomCalibrator.CENTERS.indices.filter { it < g.size && abs(g[it]) >= 0.5f }
            if (idx.isEmpty()) null
            else EffectChain(idx.map { BiquadFilter.peaking(RoomCalibrator.CENTERS[it].toFloat(), g[it], 1.1f) })
        }

        var aec: AcousticEchoCanceler? = null
        var ns: NoiseSuppressor? = null
        val rec: AudioRecord? = if (cfg.micEnabled) runCatching {
            val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            // عند تشغيل الموسيقى من المكبرات نستعمل مصدراً يفعّل إلغاء الصدى
            val src = if (cfg.monitorMusic && decoder != null) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
            AudioRecord(src, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, BLOCK * 16))
                .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
                ?.also {
                    if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(it.audioSessionId)?.also { e -> e.enabled = true }
                    if (NoiseSuppressor.isAvailable() && cfg.voice.denoise == 0) ns = NoiseSuppressor.create(it.audioSessionId)?.also { e -> e.enabled = true }
                }
        }.getOrNull() else null

        // المخرج موجود دائماً عند تفعيل مراقبة الموسيقى كي تُسمع الموسيقى المضافة لاحقاً
        val track: AudioTrack? = if (cfg.monitorMusic || cfg.monitorVoice) runCatching {
            val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
                )
                .setBufferSizeInBytes(max(minBuf, BLOCK * 16))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
        }.getOrNull() else null

        val enc = AacFileEncoder(outFile)
        val micShort = ShortArray(BLOCK)
        val mic = FloatArray(BLOCK * 2); val music = FloatArray(BLOCK * 2); val mix = FloatArray(BLOCK * 2)
        val mon = FloatArray(BLOCK * 2)
        val outS = ShortArray(BLOCK * 2); val monS = ShortArray(BLOCK * 2)
        val blockNs = BLOCK * 1_000_000_000L / SR
        var framesDone = 0L
        var first = true
        val t0 = System.nanoTime()

        try {
            rec?.startRecording(); track?.play()
            while (running) {
                // موسيقى أُضيفت أو أُوقفت أثناء التسجيل
                val nd = pendingDecoder.getAndSet(null)
                if (nd != null) {
                    decoder?.release(); decoder = nd
                    if (rec != null && aec == null && AcousticEchoCanceler.isAvailable()) {
                        aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { e -> e.enabled = true }
                    }
                }
                if (pendingClear) { decoder?.release(); decoder = null; pendingClear = false }
                hasMusic = decoder != null && decoder?.finished != true

                java.util.Arrays.fill(mic, 0f)
                if (rec != null) {
                    var n = 0
                    while (n < BLOCK && running) {
                        val r = rec.read(micShort, n, BLOCK - n)
                        if (r <= 0) break
                        n += r
                    }
                    for (i in 0 until n) { val s = micShort[i] / 32768f; mic[2 * i] = s; mic[2 * i + 1] = s }
                }
                java.util.Arrays.fill(music, 0f)
                decoder?.read(music, BLOCK)

                setup.micChain.process(mic, BLOCK)
                setup.musicChain.process(music, BLOCK)
                auto?.processInputs(mic, music, BLOCK)

                val mg = micGain; val ug = musicGain
                for (i in 0 until BLOCK * 2) mix[i] = mic[i] * mg + music[i] * ug
                auto?.processMix(mix, BLOCK)
                master.process(mix, BLOCK)
                for (i in 0 until BLOCK * 2) outS[i] = (mix[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                enc.write(outS, BLOCK)

                if (track != null) {
                    for (i in 0 until BLOCK * 2) mon[i] = if (cfg.monitorMusic) music[i] * ug else 0f
                    monEq?.process(mon, BLOCK)
                    for (i in 0 until BLOCK * 2) {
                        var v = mon[i]
                        if (cfg.monitorVoice) v += mic[i] * mg
                        monS[i] = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                    }
                    track.write(monS, 0, BLOCK * 2)
                }

                framesDone += BLOCK
                if (first) { first = false; startElapsedNs = SystemClock.elapsedRealtimeNanos() - blockNs; onReady() }
                if (rec == null) {
                    val wait = (t0 + framesDone * 1_000_000_000L / SR - System.nanoTime()) / 1_000_000
                    if (wait > 0) Thread.sleep(wait)
                }
            }
        } finally {
            runCatching { rec?.stop() }; runCatching { rec?.release() }
            runCatching { aec?.release() }; runCatching { ns?.release() }
            runCatching { track?.stop() }; runCatching { track?.release() }
            decoder?.release()
            pendingDecoder.getAndSet(null)?.release()
            hasMusic = false
            enc.finish()
        }
    }

    companion object { private const val BLOCK = 1024 }
}
