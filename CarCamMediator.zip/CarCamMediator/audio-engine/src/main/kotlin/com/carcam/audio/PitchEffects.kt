package com.carcam.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * مغيّر نغمة بخطّي تأخير متقاطعي النافذة (Hann). عندما تكون النافذة = فترتين صوتيتين
 * (كما يضبطها AutoTune) تتطابق النسختان في الطور فلا يظهر تلوّن Comb.
 */
class PitchShifter(initialRatio: Float = 1f, windowSamples: Float = 1024f) : Effect {
    @Volatile var targetRatio = initialRatio
    @Volatile var targetWindow = windowSamples
    private var ratio = initialRatio
    private var d = windowSamples
    private val size = 8192
    private val bl = FloatArray(size)
    private val br = FloatArray(size)
    private var w = 0
    private var phase = 0.5f // 0.5 => نسخة واحدة بوزن كامل عند النسبة 1

    override fun process(buf: FloatArray, frames: Int) {
        val twoPi = (2.0 * PI).toFloat()
        for (i in 0 until frames) {
            ratio += (targetRatio - ratio) * 0.002f
            d += (targetWindow - d) * 0.0005f
            bl[w] = buf[2 * i]; br[w] = buf[2 * i + 1]
            val p2 = (phase + 0.5f) % 1f
            val g1 = 0.5f - 0.5f * cos(twoPi * phase)
            val g2 = 0.5f - 0.5f * cos(twoPi * p2)
            val d1 = phase * d
            val d2 = p2 * d
            buf[2 * i] = read(bl, d1) * g1 + read(bl, d2) * g2
            buf[2 * i + 1] = read(br, d1) * g1 + read(br, d2) * g2
            phase += (1f - ratio) / d
            if (phase >= 1f) phase -= 1f else if (phase < 0f) phase += 1f
            if (++w >= size) w = 0
        }
    }

    private fun read(b: FloatArray, delay: Float): Float {
        var pos = w - delay
        while (pos < 0f) pos += size
        val i0 = pos.toInt()
        val fr = pos - i0
        val a = b[i0 % size]
        val c = b[(i0 + 1) % size]
        return a * (1f - fr) + c * fr
    }
}

/** كاشف الطبقة YIN (على عينات منخفضة 22kHz لتوفير المعالج) */
class YinDetector {
    companion object {
        /** عدد العينات الأصلية بين تحليلين */
        const val HOP = 512
        private const val H = 1024
        private const val N = 832
        private const val W = 512
        private const val TAU_MIN = 28
        private const val TAU_MAX = 315
    }

    private val ring = FloatArray(H)
    private var wr = 0
    private var since = 0
    private var carry = 0f
    private var haveCarry = false
    private val lin = FloatArray(N)
    private val cmnd = FloatArray(TAU_MAX + 2)

    fun feed(buf: FloatArray, frames: Int, onPitch: (Float) -> Unit) {
        for (i in 0 until frames) {
            val s = buf[2 * i]
            if (!haveCarry) { carry = s; haveCarry = true; continue }
            haveCarry = false
            ring[wr] = (carry + s) * 0.5f
            wr = (wr + 1) and (H - 1)
            if (++since >= HOP / 2) { since = 0; onPitch(analyze()) }
        }
    }

    /** يعيد التردد بالهرتز أو 0 إن لم يوجد صوت مُنغَّم */
    private fun analyze(): Float {
        for (k in 0 until N) lin[k] = ring[(wr - N + k) and (H - 1)]
        var e = 0f
        for (j in 0 until W) e += lin[j] * lin[j]
        if (e / W < 1e-5f) return 0f

        var running = 0f
        cmnd[0] = 1f
        for (tau in 1..TAU_MAX + 1) {
            var sum = 0f
            for (j in 0 until W) { val df = lin[j] - lin[j + tau]; sum += df * df }
            running += sum
            cmnd[tau] = if (running > 0f) sum * tau / running else 1f
        }
        var tau = TAU_MIN
        var found = -1
        while (tau < TAU_MAX) {
            if (cmnd[tau] < 0.15f) {
                while (tau + 1 < TAU_MAX && cmnd[tau + 1] < cmnd[tau]) tau++
                found = tau; break
            }
            tau++
        }
        if (found < 0) return 0f
        val s0 = cmnd[found - 1]; val s1 = cmnd[found]; val s2 = cmnd[found + 1]
        val den = 2f * (s0 + s2 - 2f * s1)
        val shift = if (den != 0f) (s0 - s2) / den else 0f
        val period = found + shift.coerceIn(-1f, 1f)
        return (SR / 2f) / period
    }
}

/** تصحيح النغمة: يكتشف الطبقة ويسحبها إلى أقرب نوتة في السلّم. retuneMs=0 => تأثير T-Pain */
class AutoTune(
    initKey: Int,
    initScale: Scale,
    retuneMs: Float,
    private val amount: Float = 1f,
) : Effect {
    @Volatile private var key = initKey
    @Volatile private var scale = initScale

    /** تغيير المقام والسلّم أثناء التشغيل (عند إضافة موسيقى لاحقاً) */
    fun setKey(k: Int, s: Scale) { key = k; scale = s }

    private val shifter = PitchShifter(1f, 1024f)
    private val yin = YinDetector()
    private val alpha = if (retuneMs <= 0f) 1f else 1f - exp(-(YinDetector.HOP * 1000f / SR) / retuneMs)
    private var ratio = 1f

    override fun process(buf: FloatArray, frames: Int) {
        yin.feed(buf, frames) { f0 -> onPitch(f0) }
        shifter.process(buf, frames)
    }

    private fun onPitch(f0: Float) {
        if (f0 <= 0f) {
            ratio += (1f - ratio) * 0.25f
        } else {
            val midi = 69f + 12f * (ln(f0 / 440f) / ln(2f))
            val base = midi.roundToInt()
            var best = Float.MAX_VALUE
            var target = midi
            for (n in base - 2..base + 2) {
                val pc = (((n - key) % 12) + 12) % 12
                if (scale.intervals.contains(pc)) {
                    val dist = abs(n - midi)
                    if (dist < best) { best = dist; target = n.toFloat() }
                }
            }
            var r = 2f.pow((target - midi) / 12f)
            r = 1f + (r - 1f) * amount
            r = r.coerceIn(0.89f, 1.12f)
            ratio += (r - ratio) * alpha
            shifter.targetWindow = (2f * SR / f0).coerceIn(160f, 1200f)
        }
        shifter.targetRatio = ratio
    }
}

/** تأثير الروبوت: ضرب الإشارة بموجة جيبية منخفضة التردد */
class RingMod(private val freq: Float, private val mix: Float) : Effect {
    private var ph = 0.0
    override fun process(buf: FloatArray, frames: Int) {
        val inc = 2.0 * PI * freq / SR
        for (i in 0 until frames) {
            val m = sin(ph).toFloat()
            ph += inc
            if (ph > 2.0 * PI) ph -= 2.0 * PI
            buf[2 * i] = buf[2 * i] * (1f - mix) + buf[2 * i] * m * mix
            buf[2 * i + 1] = buf[2 * i + 1] * (1f - mix) + buf[2 * i + 1] * m * mix
        }
    }
}
