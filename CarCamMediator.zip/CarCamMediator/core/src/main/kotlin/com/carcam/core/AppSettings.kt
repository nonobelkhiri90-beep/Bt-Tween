package com.carcam.core

import android.content.Context

/** إعدادات التطبيق المشتركة (الكاميرا والصوت والمشاركة) */
class AppSettings(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    private fun str(k: String, d: String) = sp.getString(k, d) ?: d

    var resolution: String
        get() = str("res", "FHD"); set(v) = sp.edit().putString("res", v).apply()
    var portraitDefault: Boolean
        get() = sp.getBoolean("portrait", false); set(v) = sp.edit().putBoolean("portrait", v).apply()
    var gridDefault: Boolean
        get() = sp.getBoolean("grid", false); set(v) = sp.edit().putBoolean("grid", v).apply()
    var timerDefault: Int
        get() = sp.getInt("timer", 0); set(v) = sp.edit().putInt("timer", v).apply()
    var shutterKeys: Boolean
        get() = sp.getBoolean("shutter_keys", true); set(v) = sp.edit().putBoolean("shutter_keys", v).apply()

    var engineDefaultOn: Boolean
        get() = sp.getBoolean("engine_on", true); set(v) = sp.edit().putBoolean("engine_on", v).apply()
    var preset: String
        get() = str("preset", "CLEAN"); set(v) = sp.edit().putString("preset", v).apply()
    /** -1 = تلقائي، 0..11 = C..B */
    var voiceKey: Int
        get() = sp.getInt("voice_key", -1); set(v) = sp.edit().putInt("voice_key", v).apply()
    var voiceScale: String
        get() = str("voice_scale", "MAJOR"); set(v) = sp.edit().putString("voice_scale", v).apply()
    /** تنقية الضوضاء: 0 إيقاف، 1 خفيفة، 2 متوسطة، 3 قوية */
    var denoise: Int
        get() = sp.getInt("denoise", 2); set(v) = sp.edit().putInt("denoise", v).apply()
    var micGainScale: Float
        get() = sp.getFloat("mic_scale", 1f); set(v) = sp.edit().putFloat("mic_scale", v).apply()
    var musicGainScale: Float
        get() = sp.getFloat("music_scale", 1f); set(v) = sp.edit().putFloat("music_scale", v).apply()
    var monitorMusic: Boolean
        get() = sp.getBoolean("monitor_music", true); set(v) = sp.edit().putBoolean("monitor_music", v).apply()

    /** الصوت التلقائي (AGC + خفض الموسيقى أثناء الكلام + توازن طيفي) */
    var autoAudio: Boolean
        get() = sp.getBoolean("auto_audio", true); set(v) = sp.edit().putBoolean("auto_audio", v).apply()
    /** تطبيق معايرة المقصورة على صوت المكبر */
    var useCalibration: Boolean
        get() = sp.getBoolean("use_calib", true); set(v) = sp.edit().putBoolean("use_calib", v).apply()

    // ---- جودة الفيديو (كاميرا لايف) ----
    /** 24 / 30 / 60 */
    var fps: Int
        get() = sp.getInt("fps", 30); set(v) = sp.edit().putInt("fps", v).apply()
    /** AVC أو HEVC */
    var codec: String
        get() = str("codec", "HEVC"); set(v) = sp.edit().putString("codec", v).apply()
    /** 0 عادية، 1 عالية، 2 قصوى */
    var qualityTier: Int
        get() = sp.getInt("quality_tier", 1); set(v) = sp.edit().putInt("quality_tier", v).apply()
    /** 0 بلا، 1 قياسي، 2 قوي (وضع الحركة) */
    var stabilization: Int
        get() = sp.getInt("stab", 1); set(v) = sp.edit().putInt("stab", v).apply()
    /** معالجة صورة عالية الجودة (تقليل ضوضاء/حدة/تظليل عالي الجودة من المستشعر) */
    var ispHigh: Boolean
        get() = sp.getBoolean("isp_high", true); set(v) = sp.edit().putBoolean("isp_high", v).apply()
    /** 0 بلا، 1 خفيفة، 2 قوية */
    var sharpness: Int
        get() = sp.getInt("sharp", 1); set(v) = sp.edit().putInt("sharp", v).apply()

    var shareAfterSave: Boolean
        get() = sp.getBoolean("share_after", false); set(v) = sp.edit().putBoolean("share_after", v).apply()
}
