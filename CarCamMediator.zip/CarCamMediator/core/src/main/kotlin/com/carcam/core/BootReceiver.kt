package com.carcam.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** يعيد تشغيل المراقبة بعد إقلاع الهاتف إن كان المستخدم فعّلها */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = CarPrefs(c)
        if (p.autoMonitor && p.carAddress != null) runCatching { MonitorService.start(c) }
    }
}
