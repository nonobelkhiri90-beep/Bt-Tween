package com.carcam.camera.live

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.StreamConfigurationMap
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Range
import android.util.Size
import android.view.Surface
import kotlin.math.abs
import kotlin.math.max

/**
 * تحكم Camera2 بأقصى جودة ممكنة: معدل إطارات (24/30/60)، تثبيت (قياسي/قوي + OIS)، معالجة صورة عالية الجودة،
 * قفل التعريض والتوازن، توازن أبيض، تقريب متعدد العدسات، تعريض، فلاش، تركيز بالنقر.
 */
class Cam2(
    ctx: Context,
    private val pipeline: LivePipeline,
    private val onError: (String) -> Unit,
) {
    private val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("cam2").apply { start() }
    private val handler = Handler(thread.looper)

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var surface: Surface? = null
    @Volatile private var chars: CameraCharacteristics? = null
    private var epoch = 0

    /** تُستدعى عند اكتمال ضبط الجلسة (على خيط الكاميرا) */
    @Volatile var onSessionReady: (() -> Unit)? = null
    @Volatile var zoom = 1f; private set
    @Volatile var ev = 0; private set
    @Volatile var torch = false; private set
    /** المعدل الفعلي بعد التحقق من دعم الجهاز */
    @Volatile var actualFps = 30; private set
    /** 0 بلا، 1 قياسي، 2 قوي */
    @Volatile var stab = 1; private set
    @Volatile var ispHigh = true; private set
    @Volatile var aeLock = false; private set
    @Volatile var wbIndex = 0; private set
    private var focusRect: MeteringRectangle? = null

    private fun findId(front: Boolean): String? {
        val want = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        return mgr.cameraIdList.firstOrNull { mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want }
    }

    /** أكبر حجم 16:9 لا يتجاوز المطلوب ويدعم المعدل؛ وإلا نخفض المعدل إلى 30 محتفظين بالدقة */
    private fun chooseSize(map: StreamConfigurationMap, wantW: Int, wantH: Int, fps: Int): Pair<Size, Int> {
        val all = map.getOutputSizes(SurfaceTexture::class.java)
        fun supports(s: Size, f: Int): Boolean {
            val d = map.getOutputMinFrameDuration(SurfaceTexture::class.java, s)
            return d <= 0L || d <= 1_000_000_000L / f + 2_000_000L
        }
        fun pick(f: Int): Size? = all.filter {
            abs(it.width * 9 - it.height * 16) <= it.width && it.width <= wantW && it.height <= wantH && supports(it, f)
        }.maxByOrNull { it.width * it.height }

        var f = fps
        var s = pick(f)
        if (s == null || (f > 30 && s.width < wantW * 3 / 4)) {
            val s30 = pick(30)
            if (s30 != null && (s == null || s30.width > s.width)) { s = s30; f = 30 }
        }
        if (s == null) {
            s = all.filter { it.width <= wantW && it.height <= wantH }.maxByOrNull { it.width * it.height }
                ?: all.minByOrNull { it.width * it.height }!!
        }
        return s to f
    }

    fun configure(stabilization: Int, isp: Boolean) { stab = stabilization; ispHigh = isp }

    /** يفتح الكاميرا المطلوبة (يغلق الحالية أولاً). الإخراج المرمَّز لا ينقطع. */
    fun open(front: Boolean, wantW: Int, wantH: Int, fps: Int) {
        val my = ++epoch
        handler.post {
            try {
                closeInternal()
                val id = findId(front) ?: run { onError("لا توجد كاميرا ${if (front) "أمامية" else "خلفية"}"); return@post }
                val ch = mgr.getCameraCharacteristics(id)
                chars = ch
                zoom = 1f; ev = 0; torch = false; focusRect = null; aeLock = false; wbIndex = 0
                val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
                val (size, f) = chooseSize(map, wantW, wantH, fps)
                actualFps = f
                val sensor = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
                pipeline.requestCamera(front, size.width, size.height, sensor) { surf ->
                    handler.post { if (my == epoch) openDevice(id, surf) }
                }
            } catch (t: Throwable) {
                onError("الكاميرا: ${t.message}")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun openDevice(id: String, surf: Surface) {
        val my = epoch
        surface = surf
        mgr.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) {
                if (my != epoch) { d.close(); return }
                device = d
                d.createCaptureSession(listOf(surf), object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        if (my != epoch) { s.close(); return }
                        session = s
                        pushRequest()
                        onSessionReady?.invoke()
                    }
                    override fun onConfigureFailed(s: CameraCaptureSession) { this@Cam2.onError("تعذّر ضبط جلسة الكاميرا") }
                }, handler)
            }
            override fun onDisconnected(d: CameraDevice) { d.close() }
            override fun onError(d: CameraDevice, error: Int) { d.close(); this@Cam2.onError("خطأ الكاميرا ($error)") }
        }, handler)
    }

    private fun closeInternal() {
        runCatching { session?.close() }; session = null
        runCatching { device?.close() }; device = null
    }

    fun close() {
        epoch++
        handler.post { closeInternal() }
    }

    fun release() {
        close()
        handler.post { thread.quitSafely() }
    }

    // ---- معلومات للواجهة ----
    fun minZoom(): Float {
        val ch = chars ?: return 1f
        return if (Build.VERSION.SDK_INT >= 30) ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.lower ?: 1f else 1f
    }
    fun maxZoom(): Float {
        val ch = chars ?: return 1f
        return if (Build.VERSION.SDK_INT >= 30) ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.upper ?: 1f
        else ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
    }
    /** محطات العدسات: 0.5× (إن وُجدت عدسة واسعة) ثم 1× و2× و3× و5× حسب المتاح */
    fun lensStops(): List<Float> {
        val mn = minZoom(); val mx = maxZoom()
        val out = mutableListOf<Float>()
        if (mn <= 0.65f) out.add(mn)
        out.add(1f)
        for (z in listOf(2f, 3f, 5f)) if (mx >= z) out.add(z)
        return out
    }
    fun hasFlash(): Boolean = chars?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    fun evRange(): IntRange {
        val r = chars?.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return 0..0
        return r.lower..r.upper
    }
    fun evStep(): Float = chars?.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
    fun hasStabilization(): Boolean {
        val m = chars?.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
        return m != null && m.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
    }

    private val wbAll = listOf(
        "تلقائي" to CaptureRequest.CONTROL_AWB_MODE_AUTO,
        "نهار" to CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
        "غائم" to CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
        "متوهج" to CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
        "فلورسنت" to CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,
    )
    private fun wbAvailable(): List<Pair<String, Int>> {
        val modes = chars?.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)
        return wbAll.filter { it.second == CaptureRequest.CONTROL_AWB_MODE_AUTO || (modes != null && modes.contains(it.second)) }
    }
    fun wbLabels(): List<String> = wbAvailable().map { it.first }

    // ---- التحكم ----
    fun changeZoom(z: Float) { zoom = z.coerceIn(minZoom(), max(1f, maxZoom())); handler.post { pushRequest() } }
    fun changeEv(i: Int) { ev = i; handler.post { pushRequest() } }
    fun changeTorch(on: Boolean) { torch = on; handler.post { pushRequest() } }
    fun changeStab(level: Int) { stab = level; handler.post { pushRequest() } }
    fun changeIsp(on: Boolean) { ispHigh = on; handler.post { pushRequest() } }
    fun changeAeLock(on: Boolean) { aeLock = on; handler.post { pushRequest() } }
    fun changeWb(i: Int) { wbIndex = i; handler.post { pushRequest() } }

    /** نقطة تركيز في إحداثيات المخزن الطبيعي (0..1، الأصل أعلى-يسار) */
    fun focusAt(bu: Float, bv: Float) {
        val ch = chars ?: return
        val ar = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        val w = ar.width(); val h = ar.height()
        val half = (minOf(w, h) * 0.07f).toInt()
        val cx = (bu * w).toInt(); val cy = (bv * h).toInt()
        val x = (cx - half).coerceIn(0, w - 1); val y = (cy - half).coerceIn(0, h - 1)
        val rw = (half * 2).coerceAtMost(w - x); val rh = (half * 2).coerceAtMost(h - y)
        focusRect = MeteringRectangle(x, y, rw, rh, MeteringRectangle.METERING_WEIGHT_MAX - 1)
        handler.post { pushRequest(triggerAf = true) }
    }

    private fun has(a: IntArray?, v: Int) = a != null && a.contains(v)

    private fun pushRequest(triggerAf: Boolean = false) {
        val d = device ?: return
        val s = session ?: return
        val surf = surface ?: return
        val ch = chars ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            b.addTarget(surf)
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)

            // معدل الإطارات
            val fps = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val want = actualFps
            val pick: Range<Int>? = fps?.firstOrNull { it.lower == want && it.upper == want }
                ?: fps?.filter { it.lower <= want && it.upper >= want }?.minByOrNull { it.upper - it.lower }
                ?: fps?.filter { it.upper <= 30 }?.maxByOrNull { it.upper * 100 + it.lower }
            if (pick != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pick)

            // التثبيت: قياسي (EIS) / قوي (تثبيت المعاينة كوضع الحركة) / بلا (مع OIS البصري)
            val stabModes = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            var eis = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF
            if (stab >= 1 && has(stabModes, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)) {
                eis = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
            }
            if (stab >= 2 && Build.VERSION.SDK_INT >= 33 &&
                has(stabModes, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION)
            ) {
                eis = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
            }
            b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, eis)
            if (eis == CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF &&
                has(ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION), CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            ) {
                b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            }

            // معالجة صورة عالية الجودة من المستشعر
            if (ispHigh) {
                if (has(ch.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES), CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY))
                    b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                if (has(ch.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES), CaptureRequest.EDGE_MODE_HIGH_QUALITY))
                    b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
                if (has(ch.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES), CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY))
                    b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
                if (has(ch.get(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES), CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY))
                    b.set(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY)
                if (has(ch.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES), CaptureRequest.TONEMAP_MODE_HIGH_QUALITY))
                    b.set(CaptureRequest.TONEMAP_MODE, CaptureRequest.TONEMAP_MODE_HIGH_QUALITY)
            }

            // التقريب (يشمل العدسة الواسعة عند توفرها)
            if (Build.VERSION.SDK_INT >= 30) {
                b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
            } else {
                val ar = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                if (ar != null && zoom > 1f) {
                    val cw = (ar.width() / zoom).toInt(); val chh = (ar.height() / zoom).toInt()
                    val cx = ar.centerX(); val cy = ar.centerY()
                    b.set(CaptureRequest.SCALER_CROP_REGION, Rect(cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2))
                }
            }

            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
            b.set(CaptureRequest.FLASH_MODE, if (torch && hasFlash()) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)

            // قفل التعريض والتوازن + توازن الأبيض
            if (ch.get(CameraCharacteristics.CONTROL_AE_LOCK_AVAILABLE) == true) b.set(CaptureRequest.CONTROL_AE_LOCK, aeLock)
            if (ch.get(CameraCharacteristics.CONTROL_AWB_LOCK_AVAILABLE) == true) b.set(CaptureRequest.CONTROL_AWB_LOCK, aeLock)
            val wb = wbAvailable()
            b.set(CaptureRequest.CONTROL_AWB_MODE, wb.getOrNull(wbIndex)?.second ?: CaptureRequest.CONTROL_AWB_MODE_AUTO)

            val fr = focusRect
            if (fr != null) {
                if ((ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0) > 0)
                    b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(fr))
                if ((ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0) > 0)
                    b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(fr))
            }
            if (triggerAf) {
                val t = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                t.addTarget(surf)
                t.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                if (fr != null) {
                    t.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(fr))
                    t.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(fr))
                }
                t.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
                s.capture(t.build(), null, handler)
            }
            s.setRepeatingRequest(b.build(), null, handler)
        } catch (e: Exception) {
            onError("ضبط الكاميرا: ${e.message}")
        }
    }
}
