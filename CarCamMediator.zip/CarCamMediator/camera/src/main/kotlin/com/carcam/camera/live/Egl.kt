package com.carcam.camera.live

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

/** تهيئة EGL: عرض وسياق وأسطح (نافذة المعاينة + سطح المرمّز + Pbuffer) */
internal class EglCore {
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null

    init {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(display != EGL14.EGL_NO_DISPLAY) { "EGL: لا يوجد عرض" }
        val ver = IntArray(2)
        check(EGL14.eglInitialize(display, ver, 0, ver, 1)) { "EGL: فشل التهيئة" }
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) && num[0] > 0) { "EGL: لا يوجد إعداد مناسب" }
        config = configs[0]
        val ctxAttrs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, ctxAttrs, 0)
        check(context != EGL14.EGL_NO_CONTEXT) { "EGL: فشل إنشاء السياق" }
    }

    fun createWindowSurface(surface: Surface): EGLSurface {
        val s = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
        check(s != EGL14.EGL_NO_SURFACE) { "EGL: فشل سطح النافذة" }
        return s
    }

    fun createPbuffer(w: Int, h: Int): EGLSurface {
        val s = EGL14.eglCreatePbufferSurface(
            display, config, intArrayOf(EGL14.EGL_WIDTH, w, EGL14.EGL_HEIGHT, h, EGL14.EGL_NONE), 0
        )
        check(s != EGL14.EGL_NO_SURFACE) { "EGL: فشل Pbuffer" }
        return s
    }

    fun makeCurrent(s: EGLSurface) {
        check(EGL14.eglMakeCurrent(display, s, s, context)) { "EGL: makeCurrent" }
    }

    fun noVsync() { EGL14.eglSwapInterval(display, 0) }
    fun swap(s: EGLSurface) { EGL14.eglSwapBuffers(display, s) }
    fun setPresentationTime(s: EGLSurface, ns: Long) { EGLExt.eglPresentationTimeANDROID(display, s, ns) }
    fun destroySurface(s: EGLSurface) { EGL14.eglDestroySurface(display, s) }

    fun release() {
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroyContext(display, context)
        EGL14.eglReleaseThread()
        EGL14.eglTerminate(display)
        display = EGL14.EGL_NO_DISPLAY
        context = EGL14.EGL_NO_CONTEXT
    }

    companion object { const val EGL_RECORDABLE_ANDROID = 0x3142 }
}

/** أسماء الفلاتر بنفس ترتيب أرقامها في الـ Shader */
val LIVE_FILTERS = listOf(
    "بلا", "أبيض وأسود", "سيبيا", "حيوي", "بارد", "دافئ",
    "سينمائي", "نيجاتيف", "تنعيم", "كرتون", "فينتج", "تحسين ذكي"
)

/** مصفوفة الإسقاط: تدوير + انعكاس (للأمامية في المعاينة فقط) + احتواء/تغطية داخل سطح الإخراج */
internal fun buildMvp(
    out: FloatArray, ow: Int, oh: Int, bw: Int, bh: Int, rot: Int, mirror: Boolean, fit: Boolean,
) {
    val rotated = rot == 90 || rot == 270
    val iw = (if (rotated) bh else bw).toFloat()
    val ih = (if (rotated) bw else bh).toFloat()
    val sx = ow / iw
    val sy = oh / ih
    val s = if (fit) min(sx, sy) else max(sx, sy)
    Matrix.setIdentityM(out, 0)
    if (mirror) Matrix.scaleM(out, 0, -1f, 1f, 1f)
    Matrix.scaleM(out, 0, 2f * s / ow, 2f * s / oh, 1f)
    Matrix.rotateM(out, 0, -rot.toFloat(), 0f, 0f, 1f)
    Matrix.scaleM(out, 0, bw / 2f, bh / 2f, 1f)
}

/** يرسم نسيج الكاميرا (OES) عبر Shader فيه الفلاتر والتظليل الحوافّي */
internal class FilterRenderer {
    private var program = 0
    private var aPos = 0
    private var aTex = 0
    private var uMvp = 0
    private var uTexMat = 0
    private var uTex = 0
    private var uFilter = 0
    private var uAmount = 0
    private var uVig = 0
    private var uTexel = 0
    private var uSharp = 0

    private val verts: FloatBuffer = floatBuf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val tex: FloatBuffer = floatBuf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

    private fun floatBuf(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(a); position(0) }

    fun init() {
        program = link(VERTEX, FRAGMENT)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uTexMat = GLES20.glGetUniformLocation(program, "uTexMat")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
        uFilter = GLES20.glGetUniformLocation(program, "uFilter")
        uAmount = GLES20.glGetUniformLocation(program, "uAmount")
        uVig = GLES20.glGetUniformLocation(program, "uVig")
        uTexel = GLES20.glGetUniformLocation(program, "uTexel")
        uSharp = GLES20.glGetUniformLocation(program, "uSharp")
    }

    fun createOesTexture(): Int {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, t[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return t[0]
    }

    fun draw(
        texId: Int, texMat: FloatArray, mvp: FloatArray,
        filter: Int, amount: Float, vignette: Float, texelW: Float, texelH: Float, sharp: Float,
    ) {
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uTexMat, 1, false, texMat, 0)
        GLES20.glUniform1i(uFilter, filter)
        GLES20.glUniform1f(uAmount, amount)
        GLES20.glUniform1f(uVig, vignette)
        GLES20.glUniform2f(uTexel, texelW, texelH)
        GLES20.glUniform1f(uSharp, sharp)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, verts)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 8, tex)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTex)
    }

    fun release() { if (program != 0) GLES20.glDeleteProgram(program); program = 0 }

    private fun compile(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src)
        GLES20.glCompileShader(sh)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(sh)
            GLES20.glDeleteShader(sh)
            throw RuntimeException("Shader: $log")
        }
        return sh
    }

    private fun link(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Program: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    private companion object {
        const val VERTEX = """
uniform mat4 uMvp;
uniform mat4 uTexMat;
attribute vec4 aPos;
attribute vec4 aTex;
varying vec2 vTex;
void main() {
    gl_Position = uMvp * aPos;
    vTex = (uTexMat * aTex).xy;
}
"""
        const val FRAGMENT = """
#extension GL_OES_EGL_image_external : require
precision mediump float;
varying vec2 vTex;
uniform samplerExternalOES uTex;
uniform int uFilter;
uniform float uAmount;
uniform float uVig;
uniform vec2 uTexel;
uniform float uSharp;

vec3 smp(vec2 o) { return texture2D(uTex, vTex + o * uTexel).rgb; }
float lumOf(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    vec3 c = texture2D(uTex, vTex).rgb;
    float lum = lumOf(c);
    vec3 o = c;
    if (uFilter == 1) {
        o = vec3(lum);
    } else if (uFilter == 2) {
        o = vec3(dot(c, vec3(0.393, 0.769, 0.189)), dot(c, vec3(0.349, 0.686, 0.168)), dot(c, vec3(0.272, 0.534, 0.131)));
    } else if (uFilter == 3) {
        o = mix(vec3(lum), c, 1.7);
        o = (o - 0.5) * 1.12 + 0.5;
    } else if (uFilter == 4) {
        o = c * vec3(0.88, 1.0, 1.16);
    } else if (uFilter == 5) {
        o = c * vec3(1.14, 1.0, 0.86);
    } else if (uFilter == 6) {
        vec3 g = mix(vec3(lum), c, 1.1);
        vec3 shadows = vec3(0.02, 0.10, 0.14) * (1.0 - lum);
        vec3 highs = vec3(0.12, 0.06, -0.04) * lum;
        o = (g - 0.5) * 1.15 + 0.5 + shadows + highs;
    } else if (uFilter == 7) {
        o = vec3(1.0) - c;
    } else if (uFilter == 8) {
        vec3 sum = c;
        float wsum = 1.0;
        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                vec3 s = smp(vec2(float(i), float(j)) * 1.5);
                float d = length(s - c);
                float w = exp(-d * d * 60.0);
                sum += s * w;
                wsum += w;
            }
        }
        o = sum / wsum;
        o = o * 1.05 + 0.015;
    } else if (uFilter == 9) {
        vec3 p = floor(c * 5.0 + 0.5) / 5.0;
        float a = lumOf(smp(vec2(-1.0, -1.0)));
        float b = lumOf(smp(vec2(0.0, -1.0)));
        float cc = lumOf(smp(vec2(1.0, -1.0)));
        float d = lumOf(smp(vec2(-1.0, 0.0)));
        float f = lumOf(smp(vec2(1.0, 0.0)));
        float g = lumOf(smp(vec2(-1.0, 1.0)));
        float h = lumOf(smp(vec2(0.0, 1.0)));
        float k = lumOf(smp(vec2(1.0, 1.0)));
        float gx = (cc + 2.0 * f + k) - (a + 2.0 * d + g);
        float gy = (g + 2.0 * h + k) - (a + 2.0 * b + cc);
        float e = clamp(length(vec2(gx, gy)) * 3.0, 0.0, 1.0);
        o = p * (1.0 - e);
    } else if (uFilter == 10) {
        vec3 g = c * vec3(1.08, 1.0, 0.9);
        o = g * 0.85 + 0.08;
        o = mix(vec3(lumOf(o)), o, 0.8);
    } else if (uFilter == 11) {
        vec3 g = mix(vec3(lum), c, 1.16);
        vec3 sc = g * g * (3.0 - 2.0 * g);
        o = mix(g, sc, 0.35) + (1.0 - lum) * 0.025;
    }
    vec3 outc = mix(c, o, uAmount);
    if (uSharp > 0.0) {
        vec3 avg = (smp(vec2(-1.0, 0.0)) + smp(vec2(1.0, 0.0)) + smp(vec2(0.0, -1.0)) + smp(vec2(0.0, 1.0))) * 0.25;
        outc += (c - avg) * uSharp * 1.3;
    }
    vec2 q = vTex - vec2(0.5);
    float v = clamp(1.0 - dot(q, q) * 1.9, 0.0, 1.0);
    outc *= mix(1.0, v, uVig);
    gl_FragColor = vec4(clamp(outc, 0.0, 1.0), 1.0);
}
"""
    }
}
