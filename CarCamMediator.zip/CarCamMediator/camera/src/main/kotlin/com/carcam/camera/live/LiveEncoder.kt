package com.carcam.camera.live

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import java.io.File

/**
 * مرمّز فيديو بمدخل Surface (H.264 أو HEVC عند توفره) بمعدل بتات متغيّر وملف High للجودة الأعلى،
 * يكتب mp4 بلا صوت (يُدمج الصوت لاحقاً).
 */
internal class LiveEncoder(
    val file: File, val width: Int, val height: Int, bitrate: Int, fps: Int = 30, hevc: Boolean = false,
) {
    val mime: String = if (hevc && hasEncoder(MediaFormat.MIMETYPE_VIDEO_HEVC)) MediaFormat.MIMETYPE_VIDEO_HEVC
    else MediaFormat.MIMETYPE_VIDEO_AVC
    val isHevc: Boolean get() = mime == MediaFormat.MIMETYPE_VIDEO_HEVC

    private val codec: MediaCodec = MediaCodec.createEncoderByType(mime)
    val inputSurface: Surface
    private val muxer = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var started = false

    init {
        fun format(full: Boolean) = MediaFormat.createVideoFormat(mime, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            if (full) {
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                if (mime == MediaFormat.MIMETYPE_VIDEO_AVC) {
                    setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
                }
            }
        }
        try {
            codec.configure(format(true), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            codec.reset()
            codec.configure(format(false), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
        inputSurface = codec.createInputSurface()
        codec.start()
    }

    /** يسحب الإطارات المرمّزة الجاهزة (بلا انتظار) أو حتى النهاية عند end=true */
    fun drain(end: Boolean) {
        var spins = 0
        while (true) {
            val i = codec.dequeueOutputBuffer(info, if (end) 10_000 else 0)
            when {
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!end || ++spins > 300) return }
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    track = muxer.addTrack(codec.outputFormat); muxer.start(); started = true
                }
                i >= 0 -> {
                    val b = codec.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) {
                        b.position(info.offset); b.limit(info.offset + info.size)
                        muxer.writeSampleData(track, b, info)
                    }
                    codec.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }

    fun finish() {
        runCatching { codec.signalEndOfInputStream() }
        runCatching { drain(true) }
        runCatching { codec.stop() }
        runCatching { codec.release() }
        runCatching { if (started) muxer.stop() }
        runCatching { muxer.release() }
        runCatching { inputSurface.release() }
    }

    companion object {
        fun hasEncoder(mime: String): Boolean = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) }
            }
        } catch (e: Exception) { false }
    }
}
