package com.carcam.camera

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.carcam.audio.AudioMixEngine
import com.carcam.audio.AvMerger
import com.carcam.audio.CalibStore
import com.carcam.audio.EngineConfig
import com.carcam.audio.NOTE_NAMES
import com.carcam.audio.Preset
import com.carcam.audio.Scale
import com.carcam.audio.VoiceOptions
import com.carcam.camera.live.Cam2
import com.carcam.camera.live.LIVE_FILTERS
import com.carcam.camera.live.LivePipeline
import com.carcam.core.AppSettings
import com.carcam.library.MusicPickerDialog
import com.carcam.ui.CarCamTheme
import com.carcam.ui.CcColors
import com.carcam.ui.GlassChip
import com.carcam.ui.ShareDialog
import kotlinx.coroutines.delay
import java.io.File

private class LiveHolder {
    var engine: AudioMixEngine? = null
}

/**
 * كاميرا لايف (تجريبية): Camera2 + OpenGL + مرمّز خاص.
 * جودة قصوى: حتى 4K و60 إطاراً، HEVC، معدل بتات متغير، تثبيت قوي، معالجة صورة عالية الجودة، قفل AE/AWB،
 * توازن أبيض، عدسات متعددة، فلاتر مباشرة، قلب الكاميرا بلا انقطاع، وإضافة الموسيقى أثناء التسجيل.
 */
class LiveCameraActivity : ComponentActivity() {
    private var shutter: (() -> Unit)? = null
    private var pipelineRef: LivePipeline? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { CarCamTheme(rtl = false) { Root() } }
    }

    @Suppress("DEPRECATION")
    private fun displayDegrees(): Int = when (windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_90 -> 90
        Surface.ROTATION_180 -> 180
        Surface.ROTATION_270 -> 270
        else -> 0
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        pipelineRef?.displayRotation = displayDegrees()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (!AppSettings(this).shutterKeys) return super.onKeyDown(keyCode, event)
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_CAMERA || keyCode == KeyEvent.KEYCODE_HEADSETHOOK
        ) {
            if (event?.repeatCount == 0) shutter?.invoke()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun openSaved(u: Uri) {
        startActivity(
            Intent().setClassName(packageName, "com.carcam.video.VideoPlayerActivity")
                .setData(u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }

    @Composable
    private fun Root() {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        var granted by remember { mutableStateOf(false) }
        val launcher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { r -> granted = r.values.all { it } }
        LaunchedEffect(Unit) { launcher.launch(needed) }
        if (granted) LiveScreen() else Box(Modifier.fillMaxSize().background(Color.Black))
    }

    @Composable
    private fun LiveScreen() {
        val ctx = LocalContext.current
        val st = remember { AppSettings(ctx) }
        val h = remember { LiveHolder() }

        var error by remember { mutableStateOf<String?>(null) }
        val pipeline = remember { LivePipeline { msg -> runOnUiThread { error = msg } }.also { it.start() } }
        val cam = remember { Cam2(ctx, pipeline) { msg -> runOnUiThread { error = msg } } }

        // --- الفيديو ---
        var front by remember { mutableStateOf(false) }
        var res by remember { mutableStateOf(Res.entries.firstOrNull { it.name == st.resolution } ?: Res.FHD) }
        var fps by remember { mutableIntStateOf(st.fps) }
        var hevc by remember { mutableStateOf(st.codec == "HEVC") }
        var tier by remember { mutableIntStateOf(st.qualityTier) }
        var stab by remember { mutableIntStateOf(st.stabilization) }
        var isp by remember { mutableStateOf(st.ispHigh) }
        var aeLock by remember { mutableStateOf(false) }
        var wbIdx by remember { mutableIntStateOf(0) }
        var wbLabels by remember { mutableStateOf(listOf("تلقائي")) }
        var lensStops by remember { mutableStateOf(listOf(1f)) }
        var portrait by remember { mutableStateOf(st.portraitDefault) }
        var previewReady by remember { mutableStateOf(false) }
        var grid by remember { mutableStateOf(st.gridDefault) }
        var torchOn by remember { mutableStateOf(false) }
        var hasFlash by remember { mutableStateOf(false) }
        var zoom by remember { mutableFloatStateOf(1f) }
        var ev by remember { mutableIntStateOf(0) }
        var evRange by remember { mutableStateOf(0..0) }
        var evStep by remember { mutableFloatStateOf(0f) }
        var focusPt by remember { mutableStateOf<Offset?>(null) }

        // --- المظهر ---
        var filterIdx by remember { mutableIntStateOf(0) }
        var amount by remember { mutableFloatStateOf(1f) }
        var vignette by remember { mutableStateOf(false) }
        var sharp by remember { mutableIntStateOf(st.sharpness) }

        // --- الصوت ---
        var preset by remember { mutableStateOf(Preset.entries.firstOrNull { it.name == st.preset } ?: Preset.CLEAN) }
        var denoise by remember { mutableIntStateOf(st.denoise) }
        var autoAudio by remember { mutableStateOf(st.autoAudio) }
        var autoText by remember { mutableStateOf("") }
        var voiceKey by remember { mutableIntStateOf(st.voiceKey) }
        var voiceScale by remember { mutableStateOf(Scale.entries.firstOrNull { it.name == st.voiceScale } ?: Scale.MAJOR) }
        var musicUri by remember { mutableStateOf<String?>(null) }
        var musicTitle by remember { mutableStateOf<String?>(null) }
        var showPicker by remember { mutableStateOf(false) }

        // --- التسجيل ---
        var recording by remember { mutableStateOf(false) }
        var starting by remember { mutableStateOf(false) }
        var mergeCount by remember { mutableIntStateOf(0) }
        var seconds by remember { mutableLongStateOf(0) }
        var recStart by remember { mutableLongStateOf(0) }
        var lastSaved by remember { mutableStateOf<Uri?>(null) }
        var showShare by remember { mutableStateOf(false) }
        var panelTab by remember { mutableIntStateOf(0) }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
            if (u != null) {
                musicUri = u.toString(); musicTitle = u.lastPathSegment
                h.engine?.setMusic(u, 0L)
            }
        }

        fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()

        fun startRec() {
            if (recording || starting) return
            starting = true
            val (bw, bh) = when (res) { Res.UHD -> 3840 to 2160; Res.FHD -> 1920 to 1080; Res.HD -> 1280 to 720 }
            val (w, hh) = if (portrait) bh to bw else bw to bh
            val bpp = if (hevc) floatArrayOf(0.07f, 0.10f, 0.14f)[tier] else floatArrayOf(0.10f, 0.14f, 0.20f)[tier]
            val bitrate = (w.toLong() * hh * fps * bpp).toLong().coerceIn(3_000_000L, 120_000_000L).toInt()
            val mu = musicUri
            val e = AudioMixEngine(
                ctx,
                EngineConfig(
                    mu?.let { Uri.parse(it) }, 0L, preset, monitorMusic = st.monitorMusic,
                    voice = VoiceOptions(voiceKey, voiceScale, denoise),
                    micGainScale = st.micGainScale, musicGainScale = st.musicGainScale,
                    autoMix = autoAudio,
                    monitorEq = if (st.useCalibration) CalibStore.get(ctx) else null
                ),
                File(cacheDir, "mix_${System.currentTimeMillis()}.m4a")
            )
            h.engine = e
            e.start(
                onReady = {
                    runOnUiThread {
                        if (e.musicFailed) toast("تعذّر قراءة صوت الملف، سيُسجَّل الميكروفون فقط")
                        e.detectedKeyName?.let { toast("المقام المكتشف: $it") }
                        val vf = File(cacheDir, "live_${System.currentTimeMillis()}.mp4")
                        pipeline.startRecording(vf, w, hh, bitrate, fps, hevc) { isH ->
                            runOnUiThread {
                                recording = true; starting = false; recStart = SystemClock.elapsedRealtime()
                                if (hevc && !isH) toast("HEVC غير مدعوم في هذا الجهاز، استُعمل H.264")
                            }
                        }
                    }
                },
                onError = { msg ->
                    runOnUiThread { starting = false; recording = false; h.engine = null; toast("خطأ في محرك الصوت: $msg") }
                }
            )
        }

        fun stopRec() {
            if (!recording && !starting) return
            val eng = h.engine
            h.engine = null
            eng?.signalStop()
            recording = false; starting = false; seconds = 0
            mergeCount++
            pipeline.stopRecording { file, startNs ->
                Thread {
                    var out: Uri? = null
                    val audio = eng?.stop()
                    if (eng != null && audio != null && file != null && startNs > 0L) {
                        val skipUs = (startNs - eng.startElapsedNs) / 1000
                        out = AvMerger.merge(ctx, Uri.fromFile(file), audio, skipUs)
                    }
                    file?.delete(); audio?.delete()
                    runOnUiThread {
                        mergeCount--
                        if (out != null) {
                            lastSaved = out
                            if (st.shareAfterSave) showShare = true
                            toast("تم الحفظ في Movies/CarCam")
                        } else toast("فشل حفظ الفيديو")
                    }
                }.start()
            }
        }

        val previewView = remember {
            SurfaceView(ctx).apply {
                holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) {}
                    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                        pipeline.setPreviewSurface(holder.surface, width, height)
                        previewReady = true
                    }
                    override fun surfaceDestroyed(holder: SurfaceHolder) {
                        previewReady = false
                        pipeline.setPreviewSurface(null, 0, 0)
                    }
                })
                val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    override fun onScale(d: ScaleGestureDetector): Boolean {
                        cam.changeZoom(cam.zoom * d.scaleFactor)
                        zoom = cam.zoom
                        return true
                    }
                })
                val tap = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
                    override fun onSingleTapUp(e: MotionEvent): Boolean {
                        pipeline.touchToBuffer(e.x, e.y)?.let { cam.focusAt(it[0], it[1]) }
                        focusPt = Offset(e.x, e.y)
                        return true
                    }
                })
                setOnTouchListener { _, e -> scale.onTouchEvent(e); tap.onTouchEvent(e); true }
            }
        }

        DisposableEffect(Unit) {
            pipelineRef = pipeline
            pipeline.displayRotation = displayDegrees()
            cam.onSessionReady = {
                runOnUiThread {
                    hasFlash = cam.hasFlash(); evRange = cam.evRange(); evStep = cam.evStep()
                    zoom = cam.zoom; ev = 0; torchOn = false; aeLock = false; wbIdx = 0
                    lensStops = cam.lensStops(); wbLabels = cam.wbLabels()
                    if (cam.actualFps != fps) {
                        toast("الجهاز لا يدعم ${fps} إطار/ث بهذه الدقة، استُعمل ${cam.actualFps}")
                        fps = cam.actualFps
                    }
                }
            }
            onDispose {
                shutter = null
                h.engine?.signalStop()
                cam.release()
                pipeline.release()
                pipelineRef = null
            }
        }
        SideEffect {
            pipeline.filter = filterIdx
            pipeline.amount = amount
            pipeline.vignette = if (vignette) 0.8f else 0f
            pipeline.sharpness = when (sharp) { 1 -> 0.4f; 2 -> 0.8f; else -> 0f }
            shutter = { if (recording || starting) stopRec() else startRec() }
        }
        LaunchedEffect(portrait) {
            requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        LaunchedEffect(front, res, previewReady, fps) {
            if (previewReady) {
                delay(250)
                val (w, hh) = when (res) { Res.UHD -> 3840 to 2160; Res.FHD -> 1920 to 1080; Res.HD -> 1280 to 720 }
                cam.configure(stab, isp)
                cam.open(front, w, hh, fps)
            }
        }
        LaunchedEffect(recording) {
            while (recording) { seconds = (SystemClock.elapsedRealtime() - recStart) / 1000; delay(500) }
        }
        LaunchedEffect(recording, autoAudio) {
            while (recording) {
                val a = h.engine?.autoStats
                autoText = if (a != null) {
                    "🎧 صوتك %d dB • الموسيقى %d dB • باص %+.1f • حدة %+.1f • خفض %d dB".format(
                        a.micDb.toInt(), a.musicDb.toInt(), a.bassDb, a.trebleDb, a.duckDb.toInt()
                    )
                } else ""
                delay(500)
            }
            autoText = ""
        }
        LaunchedEffect(focusPt) { if (focusPt != null) { delay(900); focusPt = null } }
        LaunchedEffect(res) { st.resolution = res.name }
        LaunchedEffect(preset) { st.preset = preset.name }
        LaunchedEffect(denoise) { st.denoise = denoise }
        LaunchedEffect(voiceKey) { st.voiceKey = voiceKey }
        LaunchedEffect(voiceScale) { st.voiceScale = voiceScale.name }

        val idle = !recording && !starting

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView({ previewView }, Modifier.fillMaxSize())

            if (grid) Canvas(Modifier.fillMaxSize()) {
                val c = Color(0x88FFFFFF)
                for (i in 1..2) {
                    drawLine(c, Offset(size.width * i / 3f, 0f), Offset(size.width * i / 3f, size.height), 2f)
                    drawLine(c, Offset(0f, size.height * i / 3f), Offset(size.width, size.height * i / 3f), 2f)
                }
            }
            focusPt?.let { p ->
                Box(
                    Modifier.offset { IntOffset((p.x - 36.dp.toPx()).toInt(), (p.y - 36.dp.toPx()).toInt()) }
                        .size(72.dp).border(2.dp, Color.Yellow, CircleShape)
                )
            }

            // الأعلى: المؤقت وملخص الجودة
            Column(Modifier.align(Alignment.TopCenter).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (recording) Text("● %02d:%02d".format(seconds / 60, seconds % 60), color = Color.Red)
                Text(
                    "${res.label} • ${fps}fps • ${if (hevc) "HEVC" else "H.264"} • %.1f×".format(zoom),
                    color = Color.White, fontSize = 11.sp
                )
                if (autoText.isNotEmpty()) Text(autoText, color = CcColors.Accent, fontSize = 10.sp)
            }
            if (mergeCount > 0) Text(
                "جاري دمج الصوت…", color = Color.White,
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(12.dp))
                    .background(Color(0xAA000000)).padding(10.dp)
            )
            lastSaved?.let { u ->
                Row(
                    Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 64.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GlassChip("▶ مشاهدة") { openSaved(u) }
                    GlassChip("📤 مشاركة") { showShare = true }
                }
            }
            if (showShare) lastSaved?.let { u -> ShareDialog(u) { showShare = false } }
            if (showPicker) MusicPickerDialog(
                onPick = { uri, startMs, title ->
                    showPicker = false
                    musicUri = uri.toString(); musicTitle = title
                    h.engine?.setMusic(uri, startMs)
                },
                onPickFile = { showPicker = false; picker.launch(arrayOf("audio/*", "video/*")) },
                onDismiss = { showPicker = false }
            )

            error?.let { msg ->
                Column(
                    Modifier.align(Alignment.Center).padding(24.dp).clip(RoundedCornerShape(16.dp))
                        .background(Color(0xEE300A14)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("تعذّر تشغيل كاميرا لايف", color = Color.White)
                    Text(msg, color = Color(0xFFFFB3C0), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassChip("الكاميرا الكلاسيكية") {
                            startActivity(Intent(this@LiveCameraActivity, CameraActivity::class.java)); finish()
                        }
                        GlassChip("إخفاء") { error = null }
                    }
                }
            }

            // يسار: فلاش وعدسات
            Column(
                Modifier.align(Alignment.CenterStart).padding(10.dp).fillMaxHeight(0.7f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (hasFlash) ChipS(if (torchOn) "⚡ مفعّل" else "⚡", torchOn, true) { torchOn = !torchOn; cam.changeTorch(torchOn) }
                lensStops.forEach { z ->
                    ChipS("%.1f×".format(z), kotlin.math.abs(zoom - z) < 0.06f, true) { cam.changeZoom(z); zoom = cam.zoom }
                }
            }

            // يمين: التصوير وقلب الكاميرا والموسيقى
            Column(
                Modifier.align(Alignment.CenterEnd).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                val pulse by rememberInfiniteTransition(label = "rec").animateFloat(
                    initialValue = 1f, targetValue = if (recording) 0.35f else 1f,
                    animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha"
                )
                Box(
                    Modifier.size(84.dp).clip(CircleShape).border(4.dp, Color.White, CircleShape)
                        .clickable(enabled = previewReady) { if (recording || starting) stopRec() else startRec() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.size(if (recording) 34.dp else 64.dp)
                            .clip(if (recording) RoundedCornerShape(8.dp) else CircleShape)
                            .background(Color(0xFFFF3B5C).copy(alpha = if (recording) pulse else 1f))
                    )
                }
                Chip("🔄", previewReady) { front = !front }
                ChipS("🎵", musicUri != null, true) { showPicker = true }
            }

            // أسفل: اللوحة والتبويبات
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 76.dp, end = 116.dp, bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (panelTab != 0) {
                    Column(
                        Modifier.fillMaxWidth().heightIn(max = 190.dp).clip(RoundedCornerShape(20.dp))
                            .background(Color(0xDD0B0816)).verticalScroll(rememberScrollState()).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        when (panelTab) {
                            1 -> {
                                Group("الدقة") {
                                    Res.entries.forEach { r -> ChipS(r.label, r == res, idle) { res = r } }
                                }
                                Group("الإطارات") {
                                    listOf(24, 30, 60).forEach { f -> ChipS("$f", f == fps, idle) { fps = f; st.fps = f } }
                                }
                                Group("الترميز والجودة") {
                                    ChipS("H.264", !hevc, idle) { hevc = false; st.codec = "AVC" }
                                    ChipS("HEVC", hevc, idle) { hevc = true; st.codec = "HEVC" }
                                    listOf("عادية", "عالية", "قصوى").forEachIndexed { i, n ->
                                        ChipS(n, i == tier, idle) { tier = i; st.qualityTier = i }
                                    }
                                }
                                Group("التثبيت") {
                                    listOf("بلا", "قياسي", "قوي").forEachIndexed { i, n ->
                                        ChipS(n, i == stab, true) { stab = i; st.stabilization = i; cam.changeStab(i) }
                                    }
                                    ChipS("معالجة عالية", isp, true) { isp = !isp; st.ispHigh = isp; cam.changeIsp(isp) }
                                }
                                Group("التعريض والألوان") {
                                    ChipS("قفل AE/AWB", aeLock, true) { aeLock = !aeLock; cam.changeAeLock(aeLock) }
                                    Chip("توازن: ${wbLabels.getOrElse(wbIdx) { "تلقائي" }}", true) {
                                        wbIdx = (wbIdx + 1) % wbLabels.size; cam.changeWb(wbIdx)
                                    }
                                    if (evRange.last > evRange.first) {
                                        Chip("☀−", true) { ev = (ev - 1).coerceAtLeast(evRange.first); cam.changeEv(ev) }
                                        Chip("EV %.1f".format(ev * evStep), false) {}
                                        Chip("☀+", true) { ev = (ev + 1).coerceAtMost(evRange.last); cam.changeEv(ev) }
                                    }
                                }
                                Group("العرض") {
                                    ChipS(if (grid) "▦ شبكة" else "▦ شبكة", grid, true) { grid = !grid }
                                    Chip(if (portrait) "↔ أفقي" else "📱 طولي", idle) { portrait = !portrait }
                                }
                            }
                            2 -> {
                                Group("المؤثر") {
                                    Preset.entries.forEach { p -> ChipS(p.label, p == preset, idle) { preset = p } }
                                }
                                Group("تنقية الضوضاء") {
                                    listOf("إيقاف", "خفيفة", "متوسطة", "قوية").forEachIndexed { i, n ->
                                        ChipS(n, i == denoise, idle) { denoise = i }
                                    }
                                }
                                Group("الصوت التلقائي") {
                                    ChipS(if (autoAudio) "🎧 يسمع ويضبط" else "🎧 متوقف", autoAudio, idle) {
                                        autoAudio = !autoAudio; st.autoAudio = autoAudio
                                    }
                                }
                                if (preset.usesKey) Group("Autotune") {
                                    Chip(if (voiceKey < 0) "مقام: تلقائي" else "مقام: ${NOTE_NAMES[voiceKey]}", idle) {
                                        voiceKey = if (voiceKey >= 11) -1 else voiceKey + 1
                                    }
                                    Chip("سلّم: ${voiceScale.label}", idle) {
                                        voiceScale = Scale.entries[(voiceScale.ordinal + 1) % Scale.entries.size]
                                    }
                                }
                                Group("الموسيقى") {
                                    Chip(if (musicTitle != null) "🎵 ${musicTitle}" else "🎵 إضافة", true) { showPicker = true }
                                    if (musicUri != null) Chip("⏹ إيقاف", true) {
                                        h.engine?.setMusic(null); musicUri = null; musicTitle = null
                                    }
                                    Chip("🎵−", true) { h.engine?.let { it.musicGain = (it.musicGain - 0.1f).coerceAtLeast(0f) } }
                                    Chip("🎵+", true) { h.engine?.let { it.musicGain = (it.musicGain + 0.1f).coerceAtMost(1.5f) } }
                                    Chip("🎤−", true) { h.engine?.let { it.micGain = (it.micGain - 0.1f).coerceAtLeast(0f) } }
                                    Chip("🎤+", true) { h.engine?.let { it.micGain = (it.micGain + 0.1f).coerceAtMost(2f) } }
                                }
                            }
                            3 -> {
                                Group("الفلتر") {
                                    LIVE_FILTERS.forEachIndexed { i, n -> ChipS(n, i == filterIdx, true) { filterIdx = i } }
                                }
                                Group("القوة والحدة") {
                                    Chip("−", true) { amount = (amount - 0.2f).coerceAtLeast(0.2f) }
                                    Chip("${(amount * 100).toInt()}%", false) {}
                                    Chip("+", true) { amount = (amount + 0.2f).coerceAtMost(1f) }
                                    ChipS("◐ تظليل", vignette, true) { vignette = !vignette }
                                    listOf("حدة: بلا", "حدة: خفيفة", "حدة: قوية").forEachIndexed { i, n ->
                                        ChipS(n, i == sharp, true) { sharp = i; st.sharpness = i }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("🎥 فيديو", "🎤 صوت", "🎨 مظهر").forEachIndexed { i, n ->
                        ChipS(n, panelTab == i + 1, true) { panelTab = if (panelTab == i + 1) 0 else i + 1 }
                    }
                }
            }
        }
    }

    @Composable
    private fun Group(title: String, content: @Composable RowScope.() -> Unit) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = CcColors.Muted, fontSize = 11.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
        }
    }

    @Composable
    private fun Chip(text: String, enabled: Boolean, onClick: () -> Unit) =
        GlassChip(text, enabled = enabled, onClick = onClick)

    @Composable
    private fun ChipS(text: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) =
        GlassChip(text, selected = selected, enabled = enabled, onClick = onClick)
}
