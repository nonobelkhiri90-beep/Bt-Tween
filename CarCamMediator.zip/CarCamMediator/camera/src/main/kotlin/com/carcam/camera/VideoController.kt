package com.carcam.camera

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import android.view.Surface
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Res(val label: String, val quality: Quality) {
    UHD("4K", Quality.UHD), FHD("1080p", Quality.FHD), HD("720p", Quality.HD)
}

/** يغلّف CameraX: ربط الكاميرا، التسجيل، التقريب، التعريض، الفلاش، التركيز */
class VideoController(private val ctx: Context, private val owner: LifecycleOwner) {
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    var camera: Camera? = null
        private set
    val isRecording get() = recording != null

    fun bind(view: PreviewView, front: Boolean, res: Res, onReady: () -> Unit) {
        val f = ProcessCameraProvider.getInstance(ctx)
        f.addListener({
            val provider = f.get()
            val rot = view.display?.rotation ?: Surface.ROTATION_0
            val preview = Preview.Builder().setTargetRotation(rot).build()
                .also { it.setSurfaceProvider(view.surfaceProvider) }
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(res.quality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                ).build()
            val vc = VideoCapture.Builder(recorder).setTargetRotation(rot).build()
            val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            provider.unbindAll()
            camera = provider.bindToLifecycle(owner, sel, preview, vc)
            videoCapture = vc
            onReady()
        }, ContextCompat.getMainExecutor(ctx))
    }

    // ---- التقريب ----
    private fun zs() = camera?.cameraInfo?.zoomState?.value
    fun zoomRatio(): Float = zs()?.zoomRatio ?: 1f
    fun minZoom(): Float = zs()?.minZoomRatio ?: 1f
    fun maxZoom(): Float = zs()?.maxZoomRatio ?: 1f
    fun setZoom(r: Float) { camera?.cameraControl?.setZoomRatio(r.coerceIn(minZoom(), maxZoom())) }

    // ---- الفلاش ----
    fun hasFlash(): Boolean = camera?.cameraInfo?.hasFlashUnit() == true
    fun torch(on: Boolean) { camera?.cameraControl?.enableTorch(on) }

    // ---- التعريض ----
    fun evRange(): IntRange {
        val s = camera?.cameraInfo?.exposureState ?: return 0..0
        if (!s.isExposureCompensationSupported) return 0..0
        return s.exposureCompensationRange.lower..s.exposureCompensationRange.upper
    }
    fun evStep(): Float = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0f
    fun setEv(i: Int) { camera?.cameraControl?.setExposureCompensationIndex(i) }

    // ---- التركيز بالنقر ----
    fun focus(view: PreviewView, x: Float, y: Float) {
        val c = camera ?: return
        val p = view.meteringPointFactory.createPoint(x, y)
        c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(p).build())
    }

    @SuppressLint("MissingPermission")
    fun start(withAudio: Boolean = true, onEvent: (VideoRecordEvent) -> Unit) {
        val vc = videoCapture ?: return
        if (recording != null) return
        val name = "CarCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CarCam")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(ctx, opts)
        if (withAudio) pr = pr.withAudioEnabled()
        recording = pr
            .start(ContextCompat.getMainExecutor(ctx)) { e ->
                if (e is VideoRecordEvent.Finalize) recording = null
                onEvent(e)
            }
    }

    fun stop() { recording?.stop(); recording = null }
}
