package com.carcam.camera.live

import android.graphics.SurfaceTexture
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.min

/**
 * مسار الفيديو: Camera2 -> SurfaceTexture -> OpenGL (فلاتر) -> {معاينة SurfaceView + مرمّز H.264}.
 * قلب الكاميرا: نبقي المرمّز يعمل ونبدّل مصدر النسيج فقط، فيبقى الملف واحداً بلا انقطاع
 * (يتجمّد آخر إطار لحظةً ريثما تفتح الكاميرا الأخرى).
 */
class LivePipeline(private val onError: (String) -> Unit) {
    private class CamTex(val front: Boolean) {
        var texId = 0
        var st: SurfaceTexture? = null
        var surface: Surface? = null
        var bufW = 1920
        var bufH = 1080
        var sensor = 90
    }

    private val thread = HandlerThread("live-gl").apply { start() }
    private val handler = Handler(thread.looper)

    private var egl: EglCore? = null
    private var renderer: FilterRenderer? = null
    private var pbuf: EGLSurface? = null
    private var previewSurf: EGLSurface? = null
    private var previewW = 1
    private var previewH = 1
    private val back = CamTex(false)
    private val front = CamTex(true)
    private var encoder: LiveEncoder? = null
    private var encSurf: EGLSurface? = null
    private var encW = 0
    private var encH = 0
    private var recFirstNs = -1L
    private val texMat = FloatArray(16)
    private val mvp = FloatArray(16)

    @Volatile private var released = false
    @Volatile var filter = 0
    @Volatile var amount = 1f
    @Volatile var vignette = 0f
    @Volatile var sharpness = 0f
    @Volatile var displayRotation = 0
    @Volatile var wantFront = false
    @Volatile var videoStartNs = 0L

    // للاستعلام من الواجهة (تحويل اللمس إلى إحداثيات المستشعر)
    @Volatile private var curRot = 0
    @Volatile private var curMirror = false
    @Volatile private var curBw = 1920
    @Volatile private var curBh = 1080
    @Volatile private var prevWv = 1
    @Volatile private var prevHv = 1

    fun start() {
        handler.post {
            try {
                val e = EglCore()
                egl = e
                val pb = e.createPbuffer(1, 1)
                pbuf = pb
                e.makeCurrent(pb)
                val r = FilterRenderer()
                r.init()
                renderer = r
                for (c in listOf(back, front)) {
                    c.texId = r.createOesTexture()
                    val st = SurfaceTexture(c.texId)
                    c.st = st
                    c.surface = Surface(st)
                    st.setOnFrameAvailableListener({ onFrame(c) }, handler)
                }
            } catch (t: Throwable) {
                onError("OpenGL: ${t.message}")
            }
        }
    }

    /** تُستدعى من الواجهة عند توفر سطح المعاينة (أو null عند زواله) */
    fun setPreviewSurface(surface: Surface?, w: Int, h: Int) {
        if (released) return
        val latch = CountDownLatch(1)
        handler.post {
            try {
                val e = egl
                if (e != null) {
                    previewSurf?.let { e.destroySurface(it) }
                    previewSurf = null
                    if (surface != null) {
                        val s = e.createWindowSurface(surface)
                        e.makeCurrent(s)
                        e.noVsync()
                        previewSurf = s
                        previewW = w; previewH = h
                        prevWv = w; prevHv = h
                    } else {
                        pbuf?.let { e.makeCurrent(it) }
                    }
                }
            } catch (t: Throwable) {
                onError("المعاينة: ${t.message}")
            } finally {
                latch.countDown()
            }
        }
        latch.await(1, TimeUnit.SECONDS)
    }

    /** يحضّر سطح الكاميرا المطلوبة ويعيده عبر cb (على خيط GL) */
    fun requestCamera(isFront: Boolean, w: Int, h: Int, sensor: Int, cb: (Surface) -> Unit) {
        handler.post {
            wantFront = isFront
            val c = if (isFront) front else back
            c.bufW = w; c.bufH = h; c.sensor = sensor
            c.st?.setDefaultBufferSize(w, h)
            c.surface?.let(cb)
        }
    }

    private fun onFrame(c: CamTex) {
        try { drawFrame(c) } catch (t: Throwable) { onError("الرسم: ${t.message}") }
    }

    private fun drawFrame(c: CamTex) {
        val e = egl ?: return
        val r = renderer ?: return
        val st = c.st ?: return
        pbuf?.let { e.makeCurrent(it) }
        st.updateTexImage()
        if (c.front != wantFront) return // إطارات الكاميرا المتروكة تُهمَل
        st.getTransformMatrix(texMat)

        val rot = if (c.front) (c.sensor + displayRotation) % 360 else (c.sensor - displayRotation + 360) % 360
        curRot = rot; curMirror = c.front; curBw = c.bufW; curBh = c.bufH
        val tw = 1f / c.bufW
        val th = 1f / c.bufH
        val f = filter; val a = amount; val v = vignette; val sh = sharpness

        previewSurf?.let { s ->
            e.makeCurrent(s)
            GLES20.glViewport(0, 0, previewW, previewH)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            buildMvp(mvp, previewW, previewH, c.bufW, c.bufH, rot, c.front, true)
            r.draw(c.texId, texMat, mvp, f, a, v, tw, th, sh)
            e.swap(s)
        }

        val enc = encoder
        val es = encSurf
        if (enc != null && es != null) {
            e.makeCurrent(es)
            GLES20.glViewport(0, 0, encW, encH)
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            buildMvp(mvp, encW, encH, c.bufW, c.bufH, rot, false, false)
            r.draw(c.texId, texMat, mvp, f, a, v, tw, th, sh)
            val now = SystemClock.elapsedRealtimeNanos()
            if (recFirstNs < 0) { recFirstNs = now; videoStartNs = now }
            e.setPresentationTime(es, now - recFirstNs)
            e.swap(es)
            enc.drain(false)
        }
    }

    fun startRecording(file: File, w: Int, h: Int, bitrate: Int, fps: Int, hevc: Boolean, onStarted: (Boolean) -> Unit) {
        handler.post {
            try {
                val e = egl ?: throw IllegalStateException("GL غير جاهز")
                val enc = LiveEncoder(file, w, h, bitrate, fps, hevc)
                encoder = enc
                encW = w; encH = h
                recFirstNs = -1L
                videoStartNs = 0L
                val s = e.createWindowSurface(enc.inputSurface)
                e.makeCurrent(s)
                e.noVsync()
                encSurf = s
                pbuf?.let { e.makeCurrent(it) }
                onStarted(enc.isHevc)
            } catch (t: Throwable) {
                onError("المرمّز: ${t.message}")
                encoder?.finish(); encoder = null; encSurf = null
            }
        }
    }

    /** يوقف التسجيل ويعيد الملف ولحظة أول إطار (elapsedRealtimeNanos) */
    fun stopRecording(cb: (File?, Long) -> Unit) {
        handler.post {
            val enc = encoder
            val s = encSurf
            encoder = null; encSurf = null
            val start = videoStartNs
            if (enc == null) { cb(null, 0L); return@post }
            enc.finish()
            runCatching { s?.let { egl?.destroySurface(it) } }
            cb(enc.file, start)
        }
    }

    /** يحوّل نقطة لمس على المعاينة إلى إحداثيات مخزن الكاميرا الطبيعية (0..1، الأصل أعلى-يسار) */
    fun touchToBuffer(x: Float, y: Float): FloatArray? {
        val pw = prevWv.toFloat(); val ph = prevHv.toFloat()
        if (pw <= 1f || ph <= 1f) return null
        val rot = curRot
        val rotated = rot == 90 || rot == 270
        val iw = (if (rotated) curBh else curBw).toFloat()
        val ih = (if (rotated) curBw else curBh).toFloat()
        val s = min(pw / iw, ph / ih)
        val dw = iw * s; val dh = ih * s
        val ox = (pw - dw) / 2f; val oy = (ph - dh) / 2f
        var u = (x - ox) / dw
        val v = (y - oy) / dh
        if (u < 0f || u > 1f || v < 0f || v > 1f) return null
        if (curMirror) u = 1f - u
        return when (rot) {
            0 -> floatArrayOf(u, v)
            90 -> floatArrayOf(v, 1f - u)
            180 -> floatArrayOf(1f - u, 1f - v)
            else -> floatArrayOf(1f - v, u)
        }
    }

    fun release() {
        released = true
        handler.post {
            runCatching { encoder?.finish() }
            encoder = null
            for (c in listOf(back, front)) {
                runCatching { c.surface?.release() }
                runCatching { c.st?.release() }
            }
            runCatching { renderer?.release() }
            runCatching { egl?.release() }
            egl = null
            thread.quitSafely()
        }
    }
}
