package com.carcam.camera

import com.carcam.audio.CalibStore
import com.carcam.library.MusicPickerDialog

import com.carcam.audio.NOTE_NAMES
import com.carcam.audio.Scale
import com.carcam.audio.VoiceOptions
import com.carcam.core.AppSettings
import com.carcam.ui.ShareDialog

import android.Manifest
import android.content.Intent
import android.view.KeyEvent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import com.carcam.ui.CarCamTheme
import com.carcam.ui.GlassChip
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.carcam.audio.AudioMixEngine
import com.carcam.audio.AvMerger
import com.carcam.audio.EngineConfig
import com.carcam.audio.Preset
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private class Holder {
    var engine: AudioMixEngine? = null
    var videoStartNs = 0L
    var lastElapsedMs = 0L
}

class CameraActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val auto = intent.getBooleanExtra(EXTRA_AUTO_START, false)
        setContent { CarCamTheme(rtl = false) { Root(auto) } }
    }

    private var shutter: (() -> Unit)? = null

    /** مفاتيح الصوت وزر سماعة البلوتوث تعمل كزر تصوير (للاستعمال دون لمس الشاشة) */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (!AppSettings(this).shutterKeys) return super.onKeyDown(keyCode, event)
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_CAMERA || keyCode == KeyEvent.KEYCODE_HEADSETHOOK
        ) {
            if (event?.repeatCount == 0) shutter?.invoke()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun openSaved(u: Uri) {
        startActivity(
            Intent().setClassName(packageName, "com.carcam.video.VideoPlayerActivity")
                .setData(u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }

    @Composable
    private fun Root(autoStart: Boolean) {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        var granted by remember { mutableStateOf(false) }
        val launcher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { r -> granted = r.values.all { it } }
        LaunchedEffect(Unit) { launcher.launch(needed) }
        if (granted) CameraScreen(autoStart) else Box(Modifier.fillMaxSize().background(Color.Black))
    }

    @Composable
    private fun CameraScreen(autoStart: Boolean) {
        val ctx = LocalContext.current
        val owner = LocalLifecycleOwner.current
        val scope = rememberCoroutineScope()
        val controller = remember { VideoController(ctx, owner) }
        val h = remember { Holder() }
        val st = remember { AppSettings(ctx) }

        var musicUri by remember { mutableStateOf(intent.getStringExtra(EXTRA_MUSIC_URI)) }
        val musicStart = remember { intent.getLongExtra(EXTRA_MUSIC_START_MS, 0L) }

        var front by remember { mutableStateOf(false) }
        var res by remember { mutableStateOf(Res.entries.firstOrNull { it.name == st.resolution } ?: Res.FHD) }
        var ready by remember { mutableStateOf(false) }
        var recording by remember { mutableStateOf(false) }
        var starting by remember { mutableStateOf(false) }
        var mergeCount by remember { mutableIntStateOf(0) }
        var seconds by remember { mutableLongStateOf(0) }
        var engineOn by remember { mutableStateOf(st.engineDefaultOn) }
        var preset by remember { mutableStateOf(Preset.entries.firstOrNull { it.name == st.preset } ?: Preset.STUDIO) }
        var portrait by remember { mutableStateOf(st.portraitDefault) }
        var grid by remember { mutableStateOf(st.gridDefault) }
        var torchOn by remember { mutableStateOf(false) }
        var hasFlash by remember { mutableStateOf(false) }
        var timerSec by remember { mutableIntStateOf(st.timerDefault) }
        var countdown by remember { mutableIntStateOf(0) }
        var zoom by remember { mutableFloatStateOf(1f) }
        var ev by remember { mutableIntStateOf(0) }
        var evRange by remember { mutableStateOf(0..0) }
        var evStep by remember { mutableFloatStateOf(0f) }
        var focusPt by remember { mutableStateOf<Offset?>(null) }
        var musicPos by remember { mutableLongStateOf(musicStart) }
        var flipPending by remember { mutableStateOf(false) }
        var resume by remember { mutableStateOf(false) }
        var lastSaved by remember { mutableStateOf<Uri?>(null) }
        var voiceKey by remember { mutableIntStateOf(st.voiceKey) }
        var voiceScale by remember { mutableStateOf(Scale.entries.firstOrNull { it.name == st.voiceScale } ?: Scale.MAJOR) }
        var showShare by remember { mutableStateOf(false) }
        var denoise by remember { mutableIntStateOf(st.denoise) }
        var autoAudio by remember { mutableStateOf(st.autoAudio) }
        var showPicker by remember { mutableStateOf(false) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
            if (u != null) { musicUri = u.toString(); musicPos = 0L; engineOn = true; h.engine?.setMusic(u, 0L) }
        }

        val previewView = remember {
            PreviewView(ctx).apply {
                val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    override fun onScale(d: ScaleGestureDetector): Boolean {
                        val z = (controller.zoomRatio() * d.scaleFactor).coerceIn(controller.minZoom(), controller.maxZoom())
                        controller.setZoom(z); zoom = z
                        return true
                    }
                })
                val tap = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
                    override fun onSingleTapUp(e: MotionEvent): Boolean {
                        controller.focus(this@apply, e.x, e.y)
                        focusPt = Offset(e.x, e.y)
                        return true
                    }
                })
                setOnTouchListener { _, e -> scale.onTouchEvent(e); tap.onTouchEvent(e); true }
            }
        }

        fun beginVideo(withAudio: Boolean) {
            controller.start(withAudio) { e ->
                when (e) {
                    is VideoRecordEvent.Start -> {
                        h.videoStartNs = SystemClock.elapsedRealtimeNanos()
                        recording = true; starting = false
                    }
                    is VideoRecordEvent.Status ->
                        seconds = e.recordingStats.recordedDurationNanos / 1_000_000_000
                    is VideoRecordEvent.Finalize -> {
                        recording = false; starting = false; seconds = 0
                        val eng = h.engine; h.engine = null
                        when {
                            e.hasError() -> {
                                Thread { eng?.stop() }.start()
                                Toast.makeText(ctx, "فشل الحفظ (${e.error})", Toast.LENGTH_LONG).show()
                            }
                            eng != null -> {
                                mergeCount++
                                val vUri = e.outputResults.outputUri
                                val skipUs = (h.videoStartNs - eng.startElapsedNs) / 1000
                                Thread {
                                    val f = eng.stop()
                                    val out = AvMerger.merge(ctx, vUri, f, skipUs)
                                    f.delete()
                                    runOnUiThread {
                                        mergeCount--
                                        if (out != null) { lastSaved = out; if (st.shareAfterSave) showShare = true }
                                        Toast.makeText(
                                            ctx,
                                            if (out != null) "تم الحفظ مع الصوت في Movies/CarCam" else "فشل دمج الصوت",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }.start()
                            }
                            else -> {
                                lastSaved = e.outputResults.outputUri
                                if (st.shareAfterSave) showShare = true
                                Toast.makeText(ctx, "تم الحفظ في Movies/CarCam", Toast.LENGTH_LONG).show()
                            }
                        }
                        if (flipPending) {
                            // قلب الكاميرا أثناء التسجيل: نحفظ المقطع ثم نبدأ مقطعاً جديداً بالكاميرا الأخرى
                            flipPending = false
                            musicPos += h.lastElapsedMs
                            resume = true
                            front = !front
                        }
                    }
                    else -> {}
                }
            }
        }

        fun startClip() {
            starting = true
            val mu = musicUri
            if (engineOn) {
                val e = AudioMixEngine(
                    ctx,
                    EngineConfig(
                        mu?.let { Uri.parse(it) }, musicPos, preset, monitorMusic = st.monitorMusic,
                        voice = VoiceOptions(voiceKey, voiceScale, denoise),
                        micGainScale = st.micGainScale, musicGainScale = st.musicGainScale,
                        autoMix = autoAudio,
                        monitorEq = if (st.useCalibration) CalibStore.get(ctx) else null
                    ),
                    File(cacheDir, "mix_${System.currentTimeMillis()}.m4a")
                )
                h.engine = e
                // نبدأ الصوت أولاً، وعند جاهزيته نبدأ الفيديو؛ ثم نقتطع الفارق عند الدمج
                e.start(
                    onReady = {
                        runOnUiThread {
                            if (e.musicFailed) {
                                Toast.makeText(ctx, "تعذّر قراءة صوت الملف، سيُسجَّل الميكروفون فقط", Toast.LENGTH_LONG).show()
                            }
                            e.detectedKeyName?.let {
                                Toast.makeText(ctx, "المقام المكتشف: $it", Toast.LENGTH_SHORT).show()
                            }
                            beginVideo(false)
                        }
                    },
                    onError = { msg ->
                        runOnUiThread {
                            starting = false; h.engine = null
                            Toast.makeText(ctx, "خطأ في محرك الصوت: $msg", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            } else beginVideo(true)
        }

        fun stopClip() {
            h.engine?.let {
                h.lastElapsedMs = (SystemClock.elapsedRealtimeNanos() - it.startElapsedNs) / 1_000_000
                it.signalStop()
            }
            controller.stop()
        }

        fun toggle() {
            if (countdown > 0) return
            if (recording || starting) { stopClip(); return }
            if (timerSec > 0) {
                scope.launch {
                    for (i in timerSec downTo 1) { countdown = i; delay(1000) }
                    countdown = 0
                    startClip()
                }
            } else startClip()
        }

        SideEffect { shutter = { toggle() } }
        LaunchedEffect(res) { st.resolution = res.name }
        LaunchedEffect(preset) { st.preset = preset.name }
        LaunchedEffect(voiceKey) { st.voiceKey = voiceKey }
        LaunchedEffect(denoise) { st.denoise = denoise }
        LaunchedEffect(voiceScale) { st.voiceScale = voiceScale.name }
        LaunchedEffect(portrait) {
            requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        LaunchedEffect(front, res, portrait) {
            ready = false
            delay(350) // ننتظر استقرار اتجاه الشاشة قبل الربط
            controller.bind(previewView, front, res) {
                ready = true
                zoom = controller.zoomRatio()
                evRange = controller.evRange(); evStep = controller.evStep(); ev = 0
                hasFlash = controller.hasFlash(); torchOn = false
            }
        }
        var autoDone by remember { mutableStateOf(false) }
        LaunchedEffect(ready) {
            if (ready) {
                if (autoStart && !autoDone) { autoDone = true; startClip() }
                else if (resume) { resume = false; startClip() }
            }
        }
        LaunchedEffect(focusPt) { if (focusPt != null) { delay(900); focusPt = null } }
        DisposableEffect(Unit) { onDispose { shutter = null; controller.stop(); h.engine?.signalStop() } }

        val idle = !recording && !starting

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView({ previewView }, Modifier.fillMaxSize())

            if (grid) Canvas(Modifier.fillMaxSize()) {
                val c = Color(0x88FFFFFF)
                for (i in 1..2) {
                    drawLine(c, Offset(size.width * i / 3f, 0f), Offset(size.width * i / 3f, size.height), 2f)
                    drawLine(c, Offset(0f, size.height * i / 3f), Offset(size.width, size.height * i / 3f), 2f)
                }
            }

            focusPt?.let { p ->
                Box(
                    Modifier.offset { IntOffset((p.x - 36.dp.toPx()).toInt(), (p.y - 36.dp.toPx()).toInt()) }
                        .size(72.dp).border(2.dp, Color.Yellow, CircleShape)
                )
            }

            Column(
                Modifier.align(Alignment.TopCenter).padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (recording) Text("● %02d:%02d".format(seconds / 60, seconds % 60), color = Color.Red)
                Text("%.1f×".format(zoom), color = Color.White, fontSize = 12.sp)
            }
            if (countdown > 0) Text(
                "$countdown", color = Color.White, fontSize = 96.sp, modifier = Modifier.align(Alignment.Center)
            )
            if (mergeCount > 0) Text(
                "جاري دمج الصوت…", color = Color.White,
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(12.dp))
                    .background(Color(0xAA000000)).padding(10.dp)
            )

            lastSaved?.let { u ->
                Row(
                    Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 64.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GlassChip("▶ مشاهدة") { openSaved(u) }
                    GlassChip("📤 مشاركة") { showShare = true }
                }
            }
            if (showShare) lastSaved?.let { u -> ShareDialog(u) { showShare = false } }
            if (showPicker) MusicPickerDialog(
                onPick = { uri, startMs, _ ->
                    showPicker = false
                    musicUri = uri.toString(); musicPos = startMs
                    if (!recording) engineOn = true
                    h.engine?.setMusic(uri, startMs)
                },
                onPickFile = { showPicker = false; picker.launch(arrayOf("video/*", "audio/*")) },
                onDismiss = { showPicker = false }
            )

            // خيارات الكاميرا (يسار)
            Column(
                Modifier.align(Alignment.CenterStart).padding(10.dp).fillMaxHeight(0.9f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip(res.label, idle) { res = Res.entries[(res.ordinal + 1) % Res.entries.size] }
                if (hasFlash) ChipS(if (torchOn) "⚡ مفعّل" else "⚡", torchOn, true) { torchOn = !torchOn; controller.torch(torchOn) }
                ChipS(if (timerSec == 0) "⏱ بلا" else "⏱ ${timerSec}ث", timerSec > 0, idle) {
                    timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
                }
                ChipS(if (grid) "▦ مفعّلة" else "▦ شبكة", grid, true) { grid = !grid }
                Chip(if (portrait) "↔ أفقي" else "📱 طولي", idle) { portrait = !portrait }
                if (evRange.last > evRange.first) {
                    Chip("☀+", true) { ev = (ev + 1).coerceAtMost(evRange.last); controller.setEv(ev) }
                    Text("EV %.1f".format(ev * evStep), color = Color.White, fontSize = 12.sp)
                    Chip("☀−", true) { ev = (ev - 1).coerceAtLeast(evRange.first); controller.setEv(ev) }
                }
            }

            // التسجيل وقلب الكاميرا (يمين)
            Column(
                Modifier.align(Alignment.CenterEnd).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                val pulse by rememberInfiniteTransition(label = "rec").animateFloat(
                    initialValue = 1f, targetValue = if (recording) 0.35f else 1f,
                    animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha"
                )
                Box(
                    Modifier.size(84.dp).clip(CircleShape).border(4.dp, Color.White, CircleShape)
                        .clickable(enabled = ready && countdown == 0) { toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.size(if (recording) 34.dp else 64.dp)
                            .clip(if (recording) RoundedCornerShape(8.dp) else CircleShape)
                            .background(Color(0xFFFF3B5C).copy(alpha = if (recording) pulse else 1f))
                    )
                }
                // يعمل أثناء التسجيل أيضاً: يحفظ المقطع ويكمل بمقطع جديد بالكاميرا الأخرى
                Chip("🔄", ready && countdown == 0 && !starting) {
                    if (recording) { flipPending = true; stopClip() } else front = !front
                }
            }

            Row(
                Modifier.align(Alignment.BottomCenter).padding(12.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Chip("🎵 موسيقى", true) {
                    if (recording && h.engine == null) Toast.makeText(ctx, "فعّل محرك الصوت قبل التسجيل لإضافة الموسيقى أثناءه", Toast.LENGTH_LONG).show()
                    else showPicker = true
                }
                if (musicUri != null) Chip("⏹ إيقاف الموسيقى", true) { h.engine?.setMusic(null); musicUri = null }
                ChipS(if (engineOn) "🎛 محرك الصوت" else "🎤 عادي", engineOn, idle) { engineOn = !engineOn }
                if (engineOn) {
                    Chip(preset.label, idle) { preset = Preset.entries[(preset.ordinal + 1) % Preset.entries.size] }
                    ChipS(if (autoAudio) "🎧 تلقائي" else "🎧 يدوي", autoAudio, idle) { autoAudio = !autoAudio; st.autoAudio = autoAudio }
                    Chip(listOf("🔇 تنقية: إيقاف", "🔇 تنقية: خفيفة", "🔇 تنقية: متوسطة", "🔇 تنقية: قوية")[denoise], idle) {
                        denoise = (denoise + 1) % 4
                    }
                    if (preset.usesKey) {
                        Chip(if (voiceKey < 0) "🎼 مقام: تلقائي" else "🎼 مقام: ${NOTE_NAMES[voiceKey]}", idle) {
                            voiceKey = if (voiceKey >= 11) -1 else voiceKey + 1
                        }
                        Chip("سلّم: ${voiceScale.label}", idle) {
                            voiceScale = Scale.entries[(voiceScale.ordinal + 1) % Scale.entries.size]
                        }
                    }
                    Chip("🎵−", true) { h.engine?.let { it.musicGain = (it.musicGain - 0.1f).coerceAtLeast(0f) } }
                    Chip("🎵+", true) { h.engine?.let { it.musicGain = (it.musicGain + 0.1f).coerceAtMost(1.5f) } }
                    Chip("🎤−", true) { h.engine?.let { it.micGain = (it.micGain - 0.1f).coerceAtLeast(0f) } }
                    Chip("🎤+", true) { h.engine?.let { it.micGain = (it.micGain + 0.1f).coerceAtMost(2f) } }
                }
            }
        }
    }

    @Composable
    private fun Chip(text: String, enabled: Boolean, onClick: () -> Unit) =
        GlassChip(text, enabled = enabled, onClick = onClick)

    @Composable
    private fun ChipS(text: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) =
        GlassChip(text, selected = selected, enabled = enabled, onClick = onClick)

    companion object {
        const val EXTRA_AUTO_START = "auto_start"
        const val EXTRA_MUSIC_URI = "music_uri"
        const val EXTRA_MUSIC_START_MS = "music_start_ms"
    }
}
