package com.carcam.camera

import android.Manifest
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.carcam.audio.AudioMixEngine
import com.carcam.audio.AvMerger
import com.carcam.audio.EngineConfig
import com.carcam.audio.Preset
import java.io.File

private class Holder {
    var engine: AudioMixEngine? = null
    var videoStartNs = 0L
}

class CameraActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val auto = intent.getBooleanExtra(EXTRA_AUTO_START, false)
        setContent { MaterialTheme { Root(auto) } }
    }

    @Composable
    private fun Root(autoStart: Boolean) {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        var granted by remember { mutableStateOf(false) }
        val launcher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { r -> granted = r.values.all { it } }
        LaunchedEffect(Unit) { launcher.launch(needed) }
        if (granted) CameraScreen(autoStart) else Box(Modifier.fillMaxSize().background(Color.Black))
    }

    @Composable
    private fun CameraScreen(autoStart: Boolean) {
        val ctx = LocalContext.current
        val owner = LocalLifecycleOwner.current
        val controller = remember { VideoController(ctx, owner) }
        val previewView = remember { PreviewView(ctx) }
        val h = remember { Holder() }

        val musicUri = remember { intent.getStringExtra(EXTRA_MUSIC_URI) }
        val musicStart = remember { intent.getLongExtra(EXTRA_MUSIC_START_MS, 0L) }

        var front by remember { mutableStateOf(false) }
        var res by remember { mutableStateOf(Res.FHD) }
        var ready by remember { mutableStateOf(false) }
        var recording by remember { mutableStateOf(false) }
        var starting by remember { mutableStateOf(false) }
        var merging by remember { mutableStateOf(false) }
        var seconds by remember { mutableLongStateOf(0) }
        var engineOn by remember { mutableStateOf(musicUri != null) }
        var preset by remember { mutableStateOf(Preset.STUDIO) }

        fun beginVideo(withAudio: Boolean) {
            controller.start(withAudio) { e ->
                when (e) {
                    is VideoRecordEvent.Start -> {
                        h.videoStartNs = SystemClock.elapsedRealtimeNanos()
                        recording = true; starting = false
                    }
                    is VideoRecordEvent.Status ->
                        seconds = e.recordingStats.recordedDurationNanos / 1_000_000_000
                    is VideoRecordEvent.Finalize -> {
                        recording = false; starting = false; seconds = 0
                        val eng = h.engine; h.engine = null
                        when {
                            e.hasError() -> {
                                Thread { eng?.stop() }.start()
                                Toast.makeText(ctx, "فشل الحفظ (${e.error})", Toast.LENGTH_LONG).show()
                            }
                            eng != null -> {
                                merging = true
                                val vUri = e.outputResults.outputUri
                                val skipUs = (h.videoStartNs - eng.startElapsedNs) / 1000
                                Thread {
                                    val f = eng.stop()
                                    val out = AvMerger.merge(ctx, vUri, f, skipUs)
                                    f.delete()
                                    runOnUiThread {
                                        merging = false
                                        Toast.makeText(
                                            ctx,
                                            if (out != null) "تم الحفظ مع الصوت في Movies/CarCam" else "فشل دمج الصوت",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }.start()
                            }
                            else -> Toast.makeText(ctx, "تم الحفظ في Movies/CarCam", Toast.LENGTH_LONG).show()
                        }
                    }
                    else -> {}
                }
            }
        }

        fun toggle() {
            if (merging) return
            if (recording || starting) {
                h.engine?.signalStop(); controller.stop(); return
            }
            if (engineOn && musicUri != null) {
                starting = true
                val e = AudioMixEngine(
                    ctx, EngineConfig(Uri.parse(musicUri), musicStart, preset),
                    File(cacheDir, "mix_${System.currentTimeMillis()}.m4a")
                )
                h.engine = e
                // نبدأ الصوت أولاً، وعند جاهزيته نبدأ الفيديو؛ ثم نقتطع الفارق عند الدمج
                e.start { runOnUiThread { beginVideo(false) } }
            } else beginVideo(true)
        }

        LaunchedEffect(front, res) {
            ready = false
            controller.bind(previewView, front, res) { ready = true }
        }
        var autoDone by remember { mutableStateOf(false) }
        LaunchedEffect(ready) {
            if (ready && autoStart && !autoDone) { autoDone = true; toggle() }
        }
        DisposableEffect(Unit) { onDispose { controller.stop(); h.engine?.signalStop() } }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView({ previewView }, Modifier.fillMaxSize())

            if (recording) Text(
                "● %02d:%02d".format(seconds / 60, seconds % 60), color = Color.Red,
                modifier = Modifier.align(Alignment.TopCenter).padding(12.dp)
            )
            if (merging) Text(
                "جاري دمج الصوت مع الفيديو…", color = Color.White,
                modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp))
                    .background(Color(0xAA000000)).padding(16.dp)
            )

            Column(
                Modifier.align(Alignment.CenterEnd).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Chip(res.label, enabled = !recording && !starting) {
                    res = Res.entries[(res.ordinal + 1) % Res.entries.size]
                }
                Box(
                    Modifier.size(72.dp).clip(CircleShape).background(Color.White)
                        .clickable(enabled = ready && !merging) { toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.size(if (recording) 28.dp else 56.dp)
                            .clip(if (recording) RoundedCornerShape(4.dp) else CircleShape)
                            .background(Color.Red)
                    )
                }
                Chip("🔄", enabled = !recording && !starting) { front = !front }
            }

            if (musicUri != null) Row(
                Modifier.align(Alignment.BottomCenter).padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Chip(if (engineOn) "🎛 محرك الصوت" else "🎤 ميكروفون فقط", enabled = !recording && !starting) {
                    engineOn = !engineOn
                }
                if (engineOn) {
                    Chip(preset.label, enabled = !recording && !starting) {
                        preset = Preset.entries[(preset.ordinal + 1) % Preset.entries.size]
                    }
                    Chip("🎵−", enabled = true) { h.engine?.let { it.musicGain = (it.musicGain - 0.1f).coerceAtLeast(0f) } }
                    Chip("🎵+", enabled = true) { h.engine?.let { it.musicGain = (it.musicGain + 0.1f).coerceAtMost(1.5f) } }
                    Chip("🎤−", enabled = true) { h.engine?.let { it.micGain = (it.micGain - 0.1f).coerceAtLeast(0f) } }
                    Chip("🎤+", enabled = true) { h.engine?.let { it.micGain = (it.micGain + 0.1f).coerceAtMost(2f) } }
                }
            }
        }
    }

    @Composable
    private fun Chip(text: String, enabled: Boolean, onClick: () -> Unit) {
        Text(
            text, color = Color.White,
            modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0x99000000))
                .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }

    companion object {
        const val EXTRA_AUTO_START = "auto_start"
        const val EXTRA_MUSIC_URI = "music_uri"
        const val EXTRA_MUSIC_START_MS = "music_start_ms"
    }
}
