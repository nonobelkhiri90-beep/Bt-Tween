package com.carcam.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.graphics.Brush

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

object CcColors {
    val Bg = Color(0xFF0B0816)
    val Surface = Color(0xFF17122B)
    val SurfaceHi = Color(0xFF241C3F)
    val Primary = Color(0xFFB388FF)
    val Accent = Color(0xFF4FC3F7)
    val Danger = Color(0xFFFF4D6D)
    val Ok = Color(0xFF3DDC97)
    val Muted = Color(0xFF9E94BF)
}

private val Scheme = darkColorScheme(
    primary = CcColors.Primary,
    onPrimary = Color(0xFF1B1038),
    secondary = CcColors.Accent,
    background = CcColors.Bg,
    onBackground = Color.White,
    surface = CcColors.Surface,
    onSurface = Color.White,
    surfaceVariant = CcColors.SurfaceHi,
    onSurfaceVariant = Color(0xFFCFC7E8),
    error = CcColors.Danger,
)

/** السمة الموحدة للتطبيق. rtl=true للواجهات العربية، وfalse للكاميرا ومشغّل الفيديو */
@Composable
fun CarCamTheme(rtl: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme) {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
        ) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0xFF1A0F3D), CcColors.Bg, Color(0xFF06040C)))
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Color.Transparent, contentColor = Color.White) { content() }
            }
        }
    }
}

/** يثبّت اتجاه اليسار لليمين (لأزرار التحكم بالوسائط التي لا تنعكس) */
@Composable
fun Ltr(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { content() }
}
