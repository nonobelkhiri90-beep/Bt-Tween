package com.carcam.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** زر زجاجي شفاف فوق الكاميرا والفيديو، يتلوّن عند التفعيل */
@Composable
fun GlassChip(
    text: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val bg = if (selected) CcColors.Primary.copy(alpha = 0.9f) else Color(0x99000000)
    val fg = when {
        selected -> Color(0xFF1B1038)
        enabled -> Color.White
        else -> Color(0x66FFFFFF)
    }
    Text(
        text, color = fg, fontSize = 13.sp,
        modifier = modifier.clip(RoundedCornerShape(18.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    )
}

/** بطاقة إجراء رئيسية بأيقونة إيموجي داخل دائرة متدرجة */
@Composable
fun ActionCard(emoji: String, title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CcColors.SurfaceHi),
    ) {
        Column(Modifier.padding(16.dp)) {
            Box(
                Modifier.size(46.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(CcColors.Primary, CcColors.Accent))),
                contentAlignment = Alignment.Center
            ) { Text(emoji, fontSize = 22.sp) }
            Spacer(Modifier.height(12.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = CcColors.Muted)
        }
    }
}

/** سطر حالة بنقطة ملوّنة */
@Composable
fun StatusRow(label: String, value: String, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Start) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (on) CcColors.Ok else CcColors.Muted))
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(value, color = if (on) CcColors.Ok else CcColors.Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

/** خيار ضمن صف اختيارات (للإعدادات) */
@Composable
fun OptionChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text, color = if (selected) Color(0xFF1B1038) else Color.White, fontSize = 13.sp,
        modifier = Modifier.clip(RoundedCornerShape(18.dp))
            .background(if (selected) CcColors.Primary else CcColors.SurfaceHi)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp)
    )
}

/** توقيع المطوّر */
@Composable
fun DevCredit(modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            "Developed by Belkhiri Abdenour", color = CcColors.Muted, fontSize = 12.sp,
            fontWeight = FontWeight.Medium, letterSpacing = 1.sp
        )
        Text("CarCam 🎬", color = Color(0x669E94BF), fontSize = 10.sp)
    }
}
