package com.carcam.ui

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** مشاركة الفيديو مباشرة إلى تيك توك ويوتيوب وغيرها */
object Share {
    class Target(val name: String, val emoji: String, val pkg: String)

    val TARGETS = listOf(
        Target("TikTok", "🎵", "com.zhiliaoapp.musically"),
        Target("TikTok", "🎵", "com.ss.android.ugc.trill"),
        Target("YouTube", "▶️", "com.google.android.youtube"),
        Target("Instagram", "📸", "com.instagram.android"),
        Target("WhatsApp", "💬", "com.whatsapp"),
        Target("Facebook", "👍", "com.facebook.katana"),
        Target("Snapchat", "👻", "com.snapchat.android"),
        Target("Telegram", "✈️", "org.telegram.messenger"),
    )

    fun isInstalled(ctx: Context, pkg: String): Boolean =
        try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    /** pkg=null يفتح قائمة اختيار التطبيقات */
    fun send(ctx: Context, uri: Uri, pkg: String?) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (pkg != null) setPackage(pkg)
        }
        val launch = if (pkg == null) Intent.createChooser(i, "مشاركة الفيديو") else i
        try { ctx.startActivity(launch) }
        catch (e: Exception) { Toast.makeText(ctx, "تعذّر فتح التطبيق", Toast.LENGTH_SHORT).show() }
    }
}

@Composable
fun ShareDialog(uri: Uri, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val targets = remember { Share.TARGETS.filter { Share.isInstalled(ctx, it.pkg) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onDismiss) { Text("إغلاق") } },
        title = { Text("مشاركة الفيديو") },
        text = {
            Column {
                targets.forEach { t ->
                    Text(
                        "${t.emoji}  ${t.name}",
                        Modifier.fillMaxWidth().clickable { Share.send(ctx, uri, t.pkg); onDismiss() }.padding(14.dp)
                    )
                }
                Text(
                    "📤  تطبيقات أخرى…",
                    Modifier.fillMaxWidth().clickable { Share.send(ctx, uri, null); onDismiss() }.padding(14.dp)
                )
            }
        }
    )
}
