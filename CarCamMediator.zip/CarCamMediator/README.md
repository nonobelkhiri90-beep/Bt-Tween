# CarCam Mediator
الوحدات: app (الرئيسية) · core (مراقبة البلوتوث والموسيقى + تشغيل تلقائي) · camera (CameraX) ·
library (مشغّل صوت + وضع البث + لوحة عائمة) · video (مشغّل فيديو) · audio-engine (ميكسر ومؤثرات ودمج) · ui (التصميم المشترك).
البناء السحابي: .github/workflows (GitHub Actions) ← ينتج CarCam-debug-apk.
التوقيع: carcam-debug.keystore ثابت، فتُثبَّت التحديثات فوق النسخة القديمة.

الجديد: Autotune وتغيير الصوت (audio-engine)، شاشة الإعدادات (app)، المشاركة المباشرة (ui).
الأحدث: كاميرا لايف (Camera2+OpenGL: قلب بلا انقطاع وفلاتر)، تنقية ضوضاء طيفية، مركز البث المباشر (library/LiveHubActivity).

الأحدث: إضافة الموسيقى أثناء التسجيل، جودة فيديو قصوى (60fps/HEVC/تثبيت/ISP)، صوت تلقائي (AutoMix) + معايرة المقصورة، واجهة متدرجة. Developed by Belkhiri Abdenour.
